#include "../include/vga.h"
#include "../include/io.h"
#include "../include/string.h"
#include "../include/font8x8.h"
#include "../include/font8x8_ext.h"
#include <stdarg.h>

#define VGA_MEM ((uint16_t*)0xB8000)
static int cur_x=0, cur_y=0;
static vga_color_t cur_fg=VGA_LIGHT_GREY, cur_bg=VGA_BLACK;

/* ── Shadow buffer — anti-flicker double-buffering ──────────────────
   ARCHITECTURE:
   vga_write()  — write-through: shadow + real VGA together, skip if
                  cell unchanged.  Fast path for all normal drawing.

   vga_clear()  — shadow-only: blanks the shadow, does NOT touch real
                  VGA.  This eliminates the classic "white flash":
                  without this fix, clearing VGA then redrawing took
                  1-2 full 14ms VGA refresh cycles on PC hardware and
                  accelerated VM backends (VirtualBox, VMware, QEMU
                  KVM/HVF) — visible as obvious flicker.  On UTM SE
                  TCG the bug was invisible because the software
                  renderer committed every frame atomically.

   vga_flush()  — diffs shadow against real VGA and writes only cells
                  that differ.  Called at the END of full_draw() after
                  the entire new frame is in the shadow buffer.  This
                  means VGA is updated from old frame → new frame in
                  one pass; the user never sees a blank intermediate
                  state.  Also called from keyboard_waitchar() to push
                  any buffered content before blocking.

   vga_shadow_write() / vga_shadow_read() — cursor bypass: the mouse
                  cursor must read and write individual cells without
                  going through the normal path, so it uses these
                  direct accessors that update both shadow and VGA.   */
/* ── v0.7.11: runtime row count (80x25 / 80x50) ───────────────────────────
 * VGA_HEIGHT is now the MAXIMUM (50).  g_rows is the active row count, so the
 * shadow buffer is allocated once at full size and the extra rows simply go
 * unused in 25-row mode.  Everything that scrolls, clears or flushes iterates
 * g_rows rather than the compile-time constant. */
static int g_rows = 25;
static int g_cols = 80;
int  vga_rows(void){ return g_rows; }
int  vga_cols(void){ return g_cols; }

static uint16_t shadow[VGA_ROWS_MAX*VGA_COLS_MAX];

static uint16_t make_entry(char c, vga_color_t fg, vga_color_t bg);
static void     update_hw_cursor(void);

/* ── v0.7.11: full text-mode switching (80x25 / 80x50 / 90x30 / 90x60) ────
 *
 * v0.7.11 only changed the CRTC character height, which doubled the rows but
 * left the 720x400 timing and the 9-dot character clock alone.  The result was
 * 8x8 glyphs in cells that are still full width and only half height, so every
 * character came out visibly squashed - correct, but ugly.
 *
 * The fix is to move both axes together.  Dropping the character clock from 9
 * dots to 8 gives 720/8 = 90 columns, and retiming vertically to 480 lines
 * gives 480/8 = 60 rows.  90x60 over 720x480 is the classic maximal VGA text
 * mode and its cells have sane proportions again.
 *
 * Each mode is applied as a COMPLETE register set rather than a delta.  That
 * matters for recovery: if a mode ever fails to sync on real hardware, typing
 * `resolution 25` blind reprograms every register back to stock mode 3 instead
 * of trying to undo a half-applied change.  The keyboard path is completely
 * independent of the video mode, so blind recovery always works.
 *
 * v0.7.11 BUG, fixed here: vga_upload_font8x8() wrote the 8x8 glyphs into the
 * font plane AND ZEROED bytes 8..31 of every glyph slot - which is where the
 * BIOS 8x16 font lives.  Switching back to 25 rows therefore restored the cell
 * height but not the glyphs, leaving every character drawn in the top half of
 * its cell with a blank band underneath.  The original font plane is now saved
 * once, before the first overwrite, and restored whenever a 16-pixel cell
 * height is selected.
 * ───────────────────────────────────────────────────────────────────────── */
#define SEQ_IDX   0x3C4
#define SEQ_DAT   0x3C5
#define GC_IDX    0x3CE
#define GC_DAT    0x3CF
#define CRTC_IDX  0x3D4
#define CRTC_DAT  0x3D5
#define AC_IDX    0x3C0
#define AC_DAT    0x3C1
#define MISC_W    0x3C2
#define INSTAT_1  0x3DA

/* Stock mode 3 (80x25, 720x400, 9-dot chars) */
static const uint8_t M3_MISC = 0x67;
static const uint8_t M3_SEQ[5]  = {0x03,0x00,0x03,0x00,0x02};
static const uint8_t M3_CRTC[25]= {
    0x5F,0x4F,0x50,0x82,0x55,0x81,0xBF,0x1F,
    0x00,0x4F,0x0D,0x0E,0x00,0x00,0x00,0x00,
    0x9C,0x8E,0x8F,0x28,0x1F,0x96,0xB9,0xA3,0xFF };

/* 90x60 (720x480, 8-dot chars, 8-line cells) */
static const uint8_t M90_MISC = 0xE7;
static const uint8_t M90_SEQ[5]  = {0x03,0x01,0x03,0x00,0x02};
static const uint8_t M90_CRTC[25]= {
    0x6B,0x59,0x5A,0x82,0x60,0x8D,0x0B,0x3E,
    0x00,0x47,0x06,0x07,0x00,0x00,0x00,0x00,
    0xEA,0x0C,0xDF,0x2D,0x08,0xE8,0x05,0xA3,0xFF };

static const uint8_t GC_TEXT[9] = {0x00,0x00,0x00,0x00,0x00,0x10,0x0E,0x00,0xFF};
static const uint8_t AC_TEXT[21]= {
    0x00,0x01,0x02,0x03,0x04,0x05,0x14,0x07,
    0x38,0x39,0x3A,0x3B,0x3C,0x3D,0x3E,0x3F,
    0x0C,0x00,0x0F,0x08,0x00 };

static uint8_t  font_backup[256*32];
static int      font_saved = 0;

/* Open the font plane for linear CPU access at A0000 */
static void font_plane_open(void){
    outb(SEQ_IDX,0x00); outb(SEQ_DAT,0x01);
    outb(SEQ_IDX,0x02); outb(SEQ_DAT,0x04);   /* write plane 2 only    */
    outb(SEQ_IDX,0x04); outb(SEQ_DAT,0x07);   /* extended, no odd/even */
    outb(SEQ_IDX,0x00); outb(SEQ_DAT,0x03);
    outb(GC_IDX,0x04);  outb(GC_DAT,0x02);    /* read plane 2          */
    outb(GC_IDX,0x05);  outb(GC_DAT,0x00);
    outb(GC_IDX,0x06);  outb(GC_DAT,0x04);    /* map at A0000          */
}
static void font_plane_close(void){
    outb(SEQ_IDX,0x00); outb(SEQ_DAT,0x01);
    outb(SEQ_IDX,0x02); outb(SEQ_DAT,0x03);
    outb(SEQ_IDX,0x04); outb(SEQ_DAT,0x03);
    outb(SEQ_IDX,0x00); outb(SEQ_DAT,0x03);
    outb(GC_IDX,0x04);  outb(GC_DAT,0x00);
    outb(GC_IDX,0x05);  outb(GC_DAT,0x10);
    outb(GC_IDX,0x06);  outb(GC_DAT,0x0E);
}

/* ══ v0.7.15: CP437 symbol glyphs for the 8x8 font ════════════════════════
 *
 * font8x8.h leaves glyphs 0x01-0x1F blank — its header says HavenDOS "only
 * ever draws 7-bit ASCII".  BOOT Chat's emoji layer maps incoming emoji onto
 * exactly those slots (☺ ♥ ♪ ☼ and the arrows), which the BIOS font provides
 * in 80x25 but the 8x8 font does not.  Without this the emoji would appear in
 * 80x25 and vanish into blank cells in 80x50 / 90x30 / 90x60.
 *
 * Rows are MSB-first (bit 7 = leftmost pixel), matching the pre-reversed
 * convention font8x8.h already uses, so these go straight into the plane.
 * ═══════════════════════════════════════════════════════════════════════ */
typedef struct { uint8_t idx; uint8_t rows[8]; } cp437_glyph_t;

static const cp437_glyph_t g_cp437_syms[] = {
 {0x01,{0x3C,0x42,0xA5,0x81,0xA5,0x99,0x42,0x3C}}, /* ☺ */
 {0x02,{0x3C,0x7E,0xDB,0xFF,0xDB,0xE7,0x7E,0x3C}}, /* ☻ */
 {0x03,{0x6C,0xFE,0xFE,0xFE,0x7C,0x38,0x10,0x00}}, /* ♥ */
 {0x04,{0x10,0x38,0x7C,0xFE,0x7C,0x38,0x10,0x00}}, /* ♦ */
 {0x05,{0x38,0x38,0xD6,0xFE,0xD6,0x10,0x38,0x00}}, /* ♣ */
 {0x06,{0x10,0x38,0x7C,0xFE,0x7C,0x10,0x38,0x00}}, /* ♠ */
 {0x0D,{0x0C,0x0E,0x0B,0x09,0x0B,0x3B,0x78,0x30}}, /* ♪ */
 {0x0E,{0x3F,0x33,0x3F,0x33,0x33,0xF3,0xE0,0x00}}, /* ♫ */
 {0x0F,{0x18,0xDB,0x3C,0xE7,0xE7,0x3C,0xDB,0x18}}, /* ☼ */
 {0x18,{0x18,0x3C,0x7E,0x18,0x18,0x18,0x18,0x00}}, /* ↑ */
 {0x19,{0x18,0x18,0x18,0x18,0x7E,0x3C,0x18,0x00}}, /* ↓ */
 {0x1A,{0x00,0x18,0x0C,0xFE,0x0C,0x18,0x00,0x00}}, /* → */
 {0x1B,{0x00,0x30,0x60,0xFE,0x60,0x30,0x00,0x00}}, /* ← */
 {0x1E,{0x00,0x10,0x38,0x7C,0xFE,0x00,0x00,0x00}}, /* ▲ */
 {0x1F,{0x00,0x00,0xFE,0x7C,0x38,0x10,0x00,0x00}}, /* ▼ */
};

/* Overwrite the blank slots in the already-uploaded 8x8 font. */
static void vga_font_patch_symbols(void){
    font_plane_open();
    volatile uint8_t *p2 = (volatile uint8_t*)0xA0000;
    int n = (int)(sizeof(g_cp437_syms)/sizeof(g_cp437_syms[0]));
    for(int g=0; g<n; g++){
        volatile uint8_t *dst = p2 + (uint32_t)g_cp437_syms[g].idx * 32;
        for(int r=0; r<8; r++)  dst[r] = g_cp437_syms[g].rows[r];
        for(int r=8; r<32; r++) dst[r] = 0x00;
    }
    /* v0.7.15: accented letters (128-255), generated by tools/make_font_ext.py
       from the base glyphs already in this font.  Without these, "café" would
       render correctly in 80x25 (BIOS font) and as blanks in 80x50/90x30/90x60
       — which looks like corruption rather than a missing glyph. */
    for(int g=0; g<FONT8X8_EXT_N; g++){
        volatile uint8_t *dst = p2 + (uint32_t)FONT8X8_EXT[g].idx * 32;
        for(int r=0; r<8; r++)  dst[r] = FONT8X8_EXT[g].rows[r];
        for(int r=8; r<32; r++) dst[r] = 0x00;
    }
    font_plane_close();
}

static void vga_font_save(void){
    if(font_saved) return;
    const uint8_t *p2=(const uint8_t*)0xA0000;
    font_plane_open();
    for(int i=0;i<256*32;i++) font_backup[i]=p2[i];
    font_plane_close();
    font_saved=1;
}
static void vga_font_restore(void){
    if(!font_saved) return;
    uint8_t *p2=(uint8_t*)0xA0000;
    font_plane_open();
    for(int i=0;i<256*32;i++) p2[i]=font_backup[i];
    font_plane_close();
}
static void vga_font_load8x8(void){
    vga_font_save();                       /* preserve the BIOS 8x16 font */
    uint8_t *p2=(uint8_t*)0xA0000;
    font_plane_open();
    for(int c=0;c<256;c++){
        for(int r=0;r<8;r++)  p2[c*32+r]=font8x8[c*8+r];
        for(int r=8;r<32;r++) p2[c*32+r]=0;
    }
    font_plane_close();
    vga_font_patch_symbols();   /* v0.7.15: fill the blank CP437 slots */
}

static void crtc_program(const uint8_t *tbl){
    /* unlock CRTC registers 0-7 (clear protect bit in index 0x11) */
    outb(CRTC_IDX,0x11);
    outb(CRTC_DAT,(uint8_t)(inb(CRTC_DAT)&0x7F));
    for(int i=0;i<25;i++){ outb(CRTC_IDX,(uint8_t)i); outb(CRTC_DAT,tbl[i]); }
}
/* ── v0.7.11: THIS IS WHAT CAUSED THE BLACK SCREEN ──────────────────────
 * The Attribute Controller is the one VGA block that uses a SINGLE port for
 * both index and data.  You write the index to 0x3C0 and then the data to
 * 0x3C0 as well; an internal flip-flop decides which one a write means, and it
 * toggles on every write.  Port 0x3C1 is READ-ONLY for AC data.
 *
 * v0.7.11 wrote the data to 0x3C1.  Those writes went nowhere, and because they
 * never toggled the flip-flop, every subsequent write to 0x3C0 was interpreted
 * as DATA for the previous index instead of a new index.  The whole sequence
 * desynchronised, and the final `outb(0x3C0, 0x20)` - which sets the Palette
 * Address Source bit and is the thing that RE-ENABLES VIDEO OUTPUT - landed as
 * a data byte instead.
 *
 * PAS therefore stayed 0, which blanks the display. That is the black screen,
 * and it is why `resolution 25` could not recover: the recovery path ran the
 * exact same broken routine and blanked the screen again.
 *
 * Reading 0x3DA before starting forces the flip-flop to the index state.
 * ─────────────────────────────────────────────────────────────────────── */
static void ac_program(int eight_dot){
    (void)inb(INSTAT_1);                   /* force flip-flop to INDEX */
    for(int i=0;i<21;i++){
        uint8_t v = AC_TEXT[i];
        /* AC[0x13] is Horizontal Pixel Panning: 8 for 9-dot cells, 0 for
           8-dot cells.  Using the 9-dot value in a 90-column mode shifts the
           whole display sideways by a character. */
        if(i==0x13) v = eight_dot ? 0x00 : 0x08;
        outb(AC_IDX,(uint8_t)i);           /* index */
        outb(AC_IDX,v);                    /* data  - SAME PORT */
    }
    (void)inb(INSTAT_1);
    outb(AC_IDX,0x20);                     /* PAS=1: video output ON */
}

/* Unconditional video re-enable.  Cheap, and it means no future mistake in
   the block above can leave the user staring at a dark screen. */
static void ac_video_on(void){
    (void)inb(INSTAT_1);
    outb(AC_IDX,0x20);
}
static void seq_program(const uint8_t *tbl){
    outb(SEQ_IDX,0x00); outb(SEQ_DAT,0x01);        /* sync reset */
    for(int i=1;i<5;i++){ outb(SEQ_IDX,(uint8_t)i); outb(SEQ_DAT,tbl[i]); }
    outb(SEQ_IDX,0x00); outb(SEQ_DAT,0x03);        /* end reset  */
}
static void gc_program(void){
    for(int i=0;i<9;i++){ outb(GC_IDX,(uint8_t)i); outb(GC_DAT,GC_TEXT[i]); }
}
static void vga_set_char_height(int h){
    outb(CRTC_IDX,0x09);
    outb(CRTC_DAT,(uint8_t)((inb(CRTC_DAT)&0xE0)|((h-1)&0x1F)));
    outb(CRTC_IDX,0x0A); outb(CRTC_DAT,(uint8_t)(h-2));
    outb(CRTC_IDX,0x0B); outb(CRTC_DAT,(uint8_t)(h-1));
}

int vga_set_mode(int cols, int rows){
    int wide  = (cols==90);
    int small = (rows==50 || rows==60);
    if(cols!=80 && cols!=90) return 0;
    if(rows!=25 && rows!=50 && rows!=30 && rows!=60) return 0;
    if(!wide && (rows==30||rows==60)) return 0;    /* 480 lines needs 90 cols */
    if(wide  && (rows==25||rows==50)) return 0;
    if(cols==g_cols && rows==g_rows) return 1;

    if(small) vga_font_load8x8(); else vga_font_restore();

    /* Hold the sequencer in synchronous reset across the dot-clock change. */
    outb(SEQ_IDX,0x00); outb(SEQ_DAT,0x01);
    outb(MISC_W, wide ? M90_MISC : M3_MISC);
    seq_program(wide ? M90_SEQ : M3_SEQ);
    crtc_program(wide ? M90_CRTC : M3_CRTC);
    gc_program();
    ac_program(wide);
    vga_set_char_height(small ? 8 : 16);

    g_cols = cols;
    g_rows = rows;

    uint16_t blank = make_entry(' ',cur_fg,cur_bg);
    for(int i=0;i<VGA_ROWS_MAX*VGA_COLS_MAX;i++) shadow[i]=blank;
    for(int i=0;i<g_rows*g_cols;i++) VGA_MEM[i]=blank;
    if(cur_y>=g_rows) cur_y=g_rows-1;
    if(cur_x>=g_cols) cur_x=g_cols-1;
    update_hw_cursor();
    ac_video_on();          /* belt and braces - never leave PAS clear */
    return 1;
}

/* Reprogram the current mode from scratch even if nothing changed.  This is
   the blind-recovery path: it never short-circuits, so it works when the
   screen is already dark and vga_set_mode() would have returned early. */
void vga_force_text_mode(void){
    g_cols=0; g_rows=0;           /* defeat the no-op check */
    vga_set_mode(80,25);
}

/* Back-compat: rows only. 25/50 stay at 80 columns; 30/60 imply 90. */
int vga_set_rows(int rows){
    if(rows==30||rows==60) return vga_set_mode(90,rows);
    return vga_set_mode(80,rows);
}

static uint16_t make_entry(char c, vga_color_t fg, vga_color_t bg){
    return (uint16_t)(uint8_t)c | ((uint16_t)((bg<<4)|fg)<<8);
}

/* ── v0.7.6 FIX: two defects in the v0.7.4 anti-flicker design ────────────
 *
 * 1. THE DIRTY CHECK COMPARED AGAINST THE WRONG BUFFER.
 *    The old body was:
 *        if(shadow[idx]!=entry){ shadow[idx]=entry; VGA_MEM[idx]=entry; }
 *    i.e. "skip the write if the SHADOW already holds this value".  That is
 *    only safe while shadow and VGA are identical — but vga_clear() is
 *    deliberately shadow-only, so the two diverge by design on every screen
 *    change.  Once diverged, any cell whose new value happened to match the
 *    stale shadow was skipped and NEVER REACHED THE SCREEN.  Unchanged UI
 *    elements — the "HavenDOS v0.7.11" label, the two-character icon glyphs,
 *    the taskbar username / NOTIF / clock — are exactly the cells most likely
 *    to match, which is why those and not the surrounding dashes and labels
 *    were the parts that blinked out.  They stayed missing until something
 *    forced a full vga_flush().
 *
 *    The dirty check now tests VGA memory, which is the thing we are actually
 *    trying to avoid rewriting.  A skip can now only happen when the screen
 *    genuinely already shows the right cell.
 *
 * 2. THERE WAS NO ACTUAL DOUBLE BUFFERING.
 *    Because vga_write() wrote straight through to 0xB8000, a frame was
 *    composed live on screen element by element and vga_flush() at the end of
 *    full_draw() only ever mopped up cells that had gone blank.  The
 *    begin/end frame pair below gives real atomicity: between them writes land
 *    in the shadow only, and vga_end_frame() commits the finished frame in one
 *    pass.  Nesting is counted so an inner pair cannot commit early.
 *    Outside a frame, behaviour is unchanged write-through, so none of the
 *    ~40 app draw sites in desktop.c need to be touched.
 * ─────────────────────────────────────────────────────────────────────── */
static int defer_depth = 0;

static inline void vga_write(int x, int y, uint16_t entry){
    /* bounds check — out-of-bounds y (e.g. from long theme lists in Settings)
       wrote past shadow[] into kernel heap/stack, hanging the system. */
    if((int)x >= g_cols || (int)x < 0 || (int)y >= g_rows || (int)y < 0) return;
    int idx=y*g_cols+x;
    shadow[idx]=entry;
    if(!defer_depth && VGA_MEM[idx]!=entry) VGA_MEM[idx]=entry;
}

/* Cursor bypass — same rules as vga_write, minus the dirty check semantics
   the cursor does not want (it always rewrites the cell it owns). */
void vga_shadow_write(int x, int y, uint16_t val){
    if((int)x >= g_cols || (int)x < 0 || (int)y >= g_rows || (int)y < 0) return;
    int idx=y*g_cols+x;
    shadow[idx]=val;
    if(!defer_depth) VGA_MEM[idx]=val;
}

/* Begin an atomic frame: writes go to the shadow only until the matching
   vga_end_frame().  Safe to nest. */
void vga_begin_frame(void){ defer_depth++; }
void vga_end_frame(void){
    if(defer_depth > 0) defer_depth--;
    if(defer_depth == 0) vga_flush();
}
uint16_t vga_shadow_read(int x, int y){
    if((unsigned)x>=(unsigned)g_cols||(unsigned)y>=(unsigned)g_rows) return 0x0720;
    return shadow[y*g_cols+x];
}

/* Sync shadow → VGA.  Called at the end of full_draw() after all UI
   elements have been drawn into the shadow buffer.  Any cell that
   differs between shadow and real VGA (including background cells
   left blank by the shadow-only vga_clear()) gets written here in
   one pass, so the screen updates atomically from the user's
   perspective — no intermediate blank frame is ever visible.       */
void vga_flush(void){
    uint16_t *vmem=VGA_MEM;
    for(int i=0;i<g_rows*g_cols;i++)
        if(vmem[i]!=shadow[i]) vmem[i]=shadow[i];
}

static void update_hw_cursor(void){
    uint16_t pos=(uint16_t)(cur_y*g_cols+cur_x);
    outb(0x3D4,14); outb(0x3D5,(uint8_t)(pos>>8));
    outb(0x3D4,15); outb(0x3D5,(uint8_t)(pos&0xFF));
}

void vga_init(void){
    cur_x=0;cur_y=0;cur_fg=VGA_LIGHT_GREY;cur_bg=VGA_BLACK;
    for(int i=0;i<VGA_ROWS_MAX*VGA_COLS_MAX;i++) shadow[i]=0xFFFF;
    vga_clear(); vga_flush(); update_hw_cursor();
}

/* Shadow-only clear: writes to shadow buffer ONLY, never touches real VGA.
   This is the key anti-flicker fix for PC VM environments (VirtualBox,
   VMware, QEMU with hardware-accelerated VGA):
     - Old behaviour: clear → VGA blank (visible white flash) → redraw
     - New behaviour: clear → shadow blank → redraw → vga_flush() diffs
       only the cells that are STILL blank after the new frame is drawn.
   On UTM SE TCG the difference was invisible (TCG renders every frame
   in one shot), but on accelerated PC VGA the blank frame was visible
   for 1-2 full VGA refresh cycles (~14ms each) = obvious flicker.
   vga_flush() at the end of full_draw() handles any cells that stayed
   blank (background areas not covered by UI elements). */
void vga_clear(void){
    uint16_t blank=make_entry(' ',cur_fg,cur_bg);
    for(int i=0;i<g_rows*g_cols;i++) shadow[i]=blank;
    cur_x=0;cur_y=0;update_hw_cursor();
}

/* v0.7.12 FIX — the shadow stride is g_cols, not the compile-time VGA_WIDTH.
   In any 90-column mode the old `(y+1)*VGA_WIDTH+x` read from 10 cells before
   the start of the source row, so scrolling smeared the screen diagonally.
   Same root cause as the VGA_WIDTH uses in vga_putchar() and vga_puts_at()
   below: v0.7.11 made the column count dynamic but left five call sites
   pinned to 80.  Those modes have never been exercised, so this was never
   seen. */
void vga_scroll(void){
    for(int y=0;y<g_rows-1;y++)
        for(int x=0;x<g_cols;x++)
            vga_write(x,y,shadow[(y+1)*g_cols+x]);
    for(int x=0;x<g_cols;x++)
        vga_write(x,g_rows-1,make_entry(' ',cur_fg,cur_bg));
    cur_y=g_rows-1;
}
void vga_putchar(char c){
    if(c=='\n'){cur_x=0;cur_y++;if(cur_y>=g_rows)vga_scroll();update_hw_cursor();return;}
    if(c=='\r'){cur_x=0;update_hw_cursor();return;}
    if(c=='\b'){if(cur_x>0){cur_x--;vga_write(cur_x,cur_y,make_entry(' ',cur_fg,cur_bg));}update_hw_cursor();return;}
    if(c=='\t'){int ns=(cur_x+8)&~7;while(cur_x<ns&&cur_x<g_cols)vga_write(cur_x++,cur_y,make_entry(' ',cur_fg,cur_bg));update_hw_cursor();return;}
    vga_write(cur_x,cur_y,make_entry(c,cur_fg,cur_bg));
    if(++cur_x>=g_cols){cur_x=0;cur_y++;}
    if(cur_y>=g_rows)vga_scroll();
    update_hw_cursor();
}
void vga_puts(const char *s){ while(*s)vga_putchar(*s++); }
void vga_set_color(vga_color_t fg, vga_color_t bg){ cur_fg=fg; cur_bg=bg; }
void vga_set_cursor(int x, int y){ cur_x=x;cur_y=y;update_hw_cursor(); }
void vga_get_cursor(int *x, int *y){ *x=cur_x;*y=cur_y; }
void vga_putchar_at(char c, int x, int y, vga_color_t fg, vga_color_t bg){
    vga_write(x,y,make_entry(c,fg,bg));
}
void vga_puts_at(const char *s, int x, int y, vga_color_t fg, vga_color_t bg){
    while(*s&&x<g_cols)vga_putchar_at(*s++,x++,y,fg,bg);
}
void vga_fill_row(int y, char c, vga_color_t fg, vga_color_t bg){
    for(int x=0;x<g_cols;x++)vga_putchar_at(c,x,y,fg,bg);
}
void vga_printf(const char *fmt,...){
    va_list args; va_start(args,fmt); char buf[32];
    while(*fmt){
        if(*fmt=='%'){fmt++;
            switch(*fmt){
                case 'd':{ int v=va_arg(args,int); itoa(v,buf,10); vga_puts(buf); break;}
                case 'u':{ uint32_t v=va_arg(args,uint32_t); utoa(v,buf,10); vga_puts(buf); break;}
                case 'x':{ uint32_t v=va_arg(args,uint32_t); utoa(v,buf,16); vga_puts(buf); break;}
                case 's':{ char *s=va_arg(args,char*); vga_puts(s?s:"(null)"); break;}
                case 'c':{ vga_putchar((char)va_arg(args,int)); break;}
                case '%': vga_putchar('%'); break;
            }
        } else vga_putchar(*fmt);
        fmt++;
    }
    va_end(args);
}
void vga_getchar_at(int x, int y, uint8_t *ch, uint8_t *attr){
    /* v0.7.12: was the only shadow accessor with no bounds check.  Callers in
       desktop.c read the cell under the mouse, which can be off-screen for a
       frame after a mode change shrinks the grid. */
    if((unsigned)x>=(unsigned)g_cols||(unsigned)y>=(unsigned)g_rows){
        if(ch)   *ch=' ';
        if(attr) *attr=0x07;
        return;
    }
    uint16_t v=shadow[y*g_cols+x];
    *ch=(uint8_t)(v&0xFF); *attr=(uint8_t)(v>>8);
}
void vga_putraw_at(uint8_t ch, uint8_t attr, int x, int y){
    vga_write(x,y,(uint16_t)((attr<<8)|ch));
}
