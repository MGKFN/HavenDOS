#pragma once
/* IO_H is a real include guard as well as the #pragma, and it exists so a
   test can define it and supply its own inb/outb.  Every driver in this tree
   talks to hardware through these six functions and nothing else, so with
   them replaceable a driver can be compiled natively against a simulated
   device and actually tested -- which is how the PCI enumeration, and the
   USB controller after it, are checked without booting anything. */
#ifndef IO_H
#define IO_H
#include "types.h"
static inline void outb(uint16_t port, uint8_t val){ __asm__ volatile("outb %0,%1"::"a"(val),"Nd"(port)); }
static inline void outw(uint16_t port, uint16_t val){ __asm__ volatile("outw %0,%1"::"a"(val),"Nd"(port)); }
static inline void outl(uint16_t port, uint32_t val){ __asm__ volatile("outl %0,%1"::"a"(val),"Nd"(port)); }
static inline uint8_t  inb(uint16_t port){ uint8_t v; __asm__ volatile("inb %1,%0":"=a"(v):"Nd"(port)); return v; }
static inline uint16_t inw(uint16_t port){ uint16_t v; __asm__ volatile("inw %1,%0":"=a"(v):"Nd"(port)); return v; }
static inline uint32_t inl(uint16_t port){ uint32_t v; __asm__ volatile("inl %1,%0":"=a"(v):"Nd"(port)); return v; }
static inline void io_wait(void){ __asm__ volatile("outb %%al,$0x80"::"a"(0)); }
#endif
