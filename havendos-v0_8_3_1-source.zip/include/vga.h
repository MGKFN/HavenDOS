#pragma once
#include "types.h"
#define VGA_WIDTH  80
#define VGA_COLS_MAX 90
#define VGA_HEIGHT 60   /* v0.7.9: MAXIMUM rows. Active = vga_rows() */
#define VGA_ROWS_MAX 60
typedef enum {
    VGA_BLACK=0, VGA_BLUE, VGA_GREEN, VGA_CYAN, VGA_RED, VGA_MAGENTA,
    VGA_BROWN, VGA_LIGHT_GREY, VGA_DARK_GREY, VGA_LIGHT_BLUE,
    VGA_LIGHT_GREEN, VGA_LIGHT_CYAN, VGA_LIGHT_RED, VGA_LIGHT_MAGENTA,
    VGA_YELLOW, VGA_WHITE
} vga_color_t;
/* ── the framebuffer console ───────────────────────────────────────────
   Call vga_fb_init() with a linear 32bpp framebuffer BEFORE vga_init() and
   every character the OS draws is rendered as pixels instead of being poked
   into VGA text memory.  Nothing above this driver changes: the desktop,
   the apps, the shell and the boot log all come along, because they all go
   through the same shadow buffer either way.  Returns 1 if it took. */
int      vga_fb_init(uint32_t addr, uint32_t w, uint32_t h,
                     uint32_t pitch_bytes, uint32_t bpp);
int      vga_fb_active(void);
uint32_t vga_fb_width(void);
uint32_t vga_fb_height(void);

void vga_init(void);
void vga_clear(void);
void vga_flush(void);
/* Commit a pending frame before stopping to wait; no-op inside a frame. */
void vga_present(void);
int  vga_rows(void);          /* v0.7.8: active row count (25 or 50) */
int  vga_cols(void);
int  vga_set_rows(int rows);
int  vga_set_mode(int cols, int rows);   /* 80x25 80x50 90x30 90x60 */
void vga_force_text_mode(void);          /* blind recovery to stock 80x25 */
void vga_begin_frame(void);   /* v0.7.6: atomic frame — see drivers/vga.c */
void vga_end_frame(void);
void vga_scroll(void);
void vga_putchar(char c);
void vga_puts(const char *s);
void vga_printf(const char *fmt, ...);
void vga_set_color(vga_color_t fg, vga_color_t bg);
void vga_set_cursor(int x, int y);
void vga_get_cursor(int *x, int *y);
void vga_putchar_at(char c, int x, int y, vga_color_t fg, vga_color_t bg);
void vga_puts_at(const char *s, int x, int y, vga_color_t fg, vga_color_t bg);
void vga_fill_row(int y, char c, vga_color_t fg, vga_color_t bg);
void vga_getchar_at(int x, int y, uint8_t *ch, uint8_t *attr);
void vga_putraw_at(uint8_t ch, uint8_t attr, int x, int y);
void vga_shadow_write(int x, int y, uint16_t val);
uint16_t vga_shadow_read(int x, int y);
