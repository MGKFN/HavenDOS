"""
Read text back off a HavenDOS framebuffer screenshot.

The framebuffer console draws the same 8x8 glyphs the text mode uses, scaled
by an integer factor in each axis, so a screenshot can be decoded back to the
exact characters rather than guessed at with OCR: each cell is sampled at one
pixel per glyph pixel and matched against the font table the kernel compiled in.

Ambiguity is resolved by nearest Hamming distance, which costs nothing at this
size and keeps a single stray pixel from turning a glyph into "unknown".
"""
import re, os, functools
from PIL import Image

FONT_H = 8
SRC = "include/font8x8.h"


@functools.lru_cache(maxsize=1)
def _font():
    body = open(SRC).read().split("FONT8X8_HEIGHT] = {", 1)[1].split("};", 1)[0]
    vals = [int(v, 16) for v in re.findall(r"0x([0-9A-Fa-f]{2})", body)]
    # bit 7 is the leftmost pixel (the table is stored MSB-first for the VGA
    # character generator), so a glyph is 8 rows of 8 bits in reading order.
    glyphs = {}
    for g in range(256):
        rows = tuple(vals[g * FONT_H:(g + 1) * FONT_H])
        glyphs.setdefault(rows, []).append(g)
    return vals, glyphs


def _printable(cands):
    for c in cands:
        if 32 <= c < 127:
            return c
    return cands[0]


def decode(path, cols=80, rows=25):
    """Return the screen as a list of `rows` strings, `cols` wide."""
    im = Image.open(path).convert("RGB")
    W, H = im.size
    cw, ch = W // cols, H // rows
    sx, sy = cw // FONT_H, ch // FONT_H
    if sx < 1 or sy < 1:
        raise ValueError("%dx%d does not hold %dx%d cells of 8x8" % (W, H, cols, rows))
    px = im.load()
    vals, glyphs = _font()

    # A cell holds at most two colours.  Which is the background cannot be
    # decided by counting pixels - a dense glyph like '#' or 'W' lights more
    # than half the cell and would read inverted - so both readings are tried
    # and the one that actually matches a glyph wins.
    out = []
    for r in range(rows):
        line = []
        for c in range(cols):
            x0, y0 = c * cw, r * ch
            samp = [[px[x0 + i * sx, y0 + j * sy] for i in range(FONT_H)]
                    for j in range(FONT_H)]
            seen = []
            for row in samp:
                for p_ in row:
                    if p_ not in seen:
                        seen.append(p_)
            if len(seen) == 1:
                line.append(" ")
                continue
            best, bestd = 32, 999
            for bg in seen[:4]:
                bits = tuple(sum((1 << (7 - i)) for i in range(FONT_H)
                                 if samp[j][i] != bg) for j in range(FONT_H))
                if bits in glyphs:
                    g, d = _printable(glyphs[bits]), 0
                else:
                    g, d = 32, 999
                    for cand in range(32, 127):
                        dd = sum(bin(bits[j] ^ vals[cand * FONT_H + j]).count("1")
                                 for j in range(FONT_H))
                        if dd < d:
                            g, d = cand, dd
                if d < bestd:
                    best, bestd = g, d
            line.append(chr(best) if bestd <= 8 else "?")
        out.append("".join(line).rstrip())
    return out


def text(path, cols=80, rows=25):
    return "\n".join(decode(path, cols, rows))


if __name__ == "__main__":
    import sys
    print(text(sys.argv[1]))
