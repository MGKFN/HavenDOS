/*
 * usb.c — what the USB controllers and bus are actually doing
 *
 * `lspci` answers "is a controller there".  This answers the next three
 * questions, which are the ones you need when a USB stick does not show up:
 * is the controller RUNNING, is anything plugged in, and did the device
 * answer when we spoke to it.
 *
 * It also names a controller this kernel cannot drive, and says when the
 * ports were taken back from an EHCI.  A machine newer than about 2009 has
 * EHCI or xHCI, and a USB 2.0 controller is normally an EHCI with UHCI
 * companions sharing its sockets -- on either of those, a bare "no USB"
 * would be a lie that sends you looking at the driver instead of the
 * hardware.
 *
 *   usb        controllers, ports in use, and the devices that answered
 *   usb -v     the raw registers as well
 *   usb -vv    and a line for every port, including the empty ones
 */
#include "../include/types.h"
#include "../include/string.h"
#include "../include/vga.h"
#include "../include/pci.h"
#include "../include/uhci.h"

extern void utoa(uint32_t v, char *buf, int base);

static void put_hex(uint32_t v, int digits)
{
    const char *hex = "0123456789ABCDEF";
    char buf[9];
    int i = 0;
    for (int shift = (digits - 1) * 4; shift >= 0; shift -= 4)
        buf[i++] = hex[(v >> shift) & 0xF];
    buf[i] = 0;
    vga_puts(buf);
}

static void put_dec(uint32_t v)
{
    char b[12];
    utoa(v, b, 10);
    vga_puts(b);
}

/* The device class byte.  A USB flash drive reports class 0 here and
   declares itself mass storage in its INTERFACE descriptor, which this
   kernel does not read yet -- so say that, rather than print "00" and leave
   it looking like the device failed to identify itself. */
static const char *class_name(uint8_t c)
{
    switch (c) {
    case 0x00: return "in the interface descriptor";
    case 0x01: return "audio";
    case 0x02: return "communications";
    case 0x03: return "human interface";
    case 0x07: return "printer";
    case 0x08: return "mass storage";
    case 0x09: return "hub";
    case 0x0E: return "video";
    case 0xE0: return "wireless";
    case 0xFF: return "vendor specific";
    default:   return "unknown";
    }
}

static void no_controller(int verbose)
{
    uint8_t progif = 0;
    if (uhci_other_controller(&progif)) {
        vga_puts("No UHCI controller on this machine.\n\n");
        vga_puts("There IS a USB controller, programming interface 0x");
        put_hex(progif, 2);
        vga_puts(progif == 0x20 ? " (EHCI)\n" :
                 progif == 0x10 ? " (OHCI)\n" :
                 progif == 0x30 ? " (xHCI)\n" : "\n");
        vga_puts("which this kernel cannot drive yet.\n\n");
        if (progif == 0x30) {
            vga_puts("An xHCI on its own has no UHCI companion to fall back\n");
            vga_puts("to. In UTM, set USB Support to 2.0 instead of 3.0 and\n");
            vga_puts("this kernel can use the bus.\n");
        } else {
            vga_puts("UHCI is USB 1.1 and stopped shipping around 2009, so a\n");
            vga_puts("machine newer than that has one of the above instead.\n");
        }
        vga_puts("The transfer and enumeration layers above the controller\n");
        vga_puts("are the same either way.\n");
    } else {
        vga_puts("No USB controller found.\n");
        vga_puts("Run 'lspci' to see what is on the bus.\n");
    }
}

void cmd_usb(const char *arg1)
{
    /* -v is the registers and the init log; -vv also lists every empty
       port.  They are separate because a companion set has six ports and a
       line each pushes the init log -- the part you actually came for --
       off the top of an 80x25 screen. */
    int vv      = arg1 && !strcmp(arg1, "-vv");
    int verbose = vv || (arg1 && !strcmp(arg1, "-v"));

    if (!uhci_present()) { no_controller(verbose); return; }

    int nhc = uhci_hc_count(), nports = 0, running = 0;
    for (int c = 0; c < nhc; c++) {
        nports += uhci_port_count(c);
        if (uhci_usbcmd(c) & 1) running++;
    }

    vga_puts("UHCI: ");
    put_dec((uint32_t)nhc);
    vga_puts(nhc == 1 ? " controller  " : " controllers  ");
    put_dec((uint32_t)nports);
    vga_puts(" ports  ");
    if (running == nhc) vga_puts("all running\n");
    else { put_dec((uint32_t)running); vga_puts(" running\n"); }

    if (uhci_ehci_released()) {
        vga_puts("EHCI at 0x"); put_hex(uhci_ehci_base(), 8);
        vga_puts(" - its ports were handed to these\n");
        vga_puts("companions, so devices run at full speed, 12 Mbit.\n");
    }

    if (verbose) {
        for (int c = 0; c < nhc; c++) {
            vga_puts("  hc"); put_dec((uint32_t)c);
            vga_puts(" 0x");  put_hex(uhci_io_base(c), 4);
            vga_puts(" IRQ "); put_dec(uhci_hc_irq(c));
            vga_puts("  CMD 0x"); put_hex(uhci_usbcmd(c), 4);
            vga_puts(" STS 0x");  put_hex(uhci_usbsts(c), 4);
            vga_puts(" FRNUM ");  put_dec(uhci_frnum(c));
            vga_puts("\n");
        }
    }
    vga_puts("\n");

    /* Ports with something on them, then a count of the empty ones.  Six
       ports is normal on a companion set and one line each would fill the
       screen with "nothing attached". */
    int empty = 0;
    for (int c = 0; c < nhc; c++) {
        for (int p = 0; p < uhci_port_count(c); p++) {
            uint16_t ps = uhci_portsc(c, p);
            if (!(ps & 0x0001)) {
                empty++;
                if (vv) {
                    vga_puts("hc"); put_dec((uint32_t)c);
                    vga_puts(" port "); put_dec((uint32_t)p);
                    vga_puts("  empty          PORTSC 0x");
                    put_hex(ps, 4); vga_puts("\n");
                }
                continue;
            }

            vga_puts("hc"); put_dec((uint32_t)c);
            vga_puts(" port "); put_dec((uint32_t)p);
            vga_puts((ps & 0x0100) ? "  low-speed " : "  full-speed");
            vga_puts((ps & 0x0004) ? "  enabled" : "  NOT enabled");
            if (verbose) { vga_puts("  PORTSC 0x"); put_hex(ps, 4); }
            vga_puts("\n");

            const uhci_dev_t *d = 0;
            for (int i = 0; i < uhci_device_count(); i++)
                if (uhci_device(i)->hc == c && uhci_device(i)->port == p) {
                    d = uhci_device(i); break;
                }
            if (!d) {
                vga_puts("        attached, but it did not answer.\n");
                vga_puts("        'usb -v' shows what the scan saw.\n");
                continue;
            }

            vga_puts("        addr ");  put_dec(d->addr);
            vga_puts("  ");            put_hex(d->vendor, 4);
            vga_puts(":");             put_hex(d->product, 4);
            vga_puts("  rev ");        put_hex(d->release, 4);
            vga_puts("\n        class ");
            put_hex(d->dev_class, 2);    vga_puts("/");
            put_hex(d->dev_subclass, 2); vga_puts("/");
            put_hex(d->dev_protocol, 2);
            vga_puts("  "); vga_puts(class_name(d->dev_class));
            vga_puts("\n        endpoint 0 packet size ");
            put_dec(d->maxpacket0);
            vga_puts("  configurations ");
            put_dec(d->nconfigs);
            vga_puts("\n");
        }
    }

    if (!vv && empty) {
        put_dec((uint32_t)empty);
        vga_puts(empty == 1 ? " other port is empty.\n" : " ports are empty.\n");
    }

    if (uhci_device_count() == 0) {
        vga_puts("\nNo devices answered.\n");
        if (uhci_ehci_released()) {
            /* The sockets were taken back, so a device on one of them should
               be here.  If it is not, it is a device that cannot do full
               speed -- not a controller that was never asked. */
            vga_puts("The EHCI's ports were handed over, so anything plugged\n");
            vga_puts("in should appear here. If it does not, that device\n");
            vga_puts("cannot run at full speed and needs an EHCI driver.\n");
        } else {
            vga_puts("In QEMU a USB stick needs asking for:\n");
            vga_puts("  -usb -drive if=none,id=stick,file=usb.img,format=raw \\\n");
            vga_puts("      -device usb-storage,drive=stick,bus=usb-bus.0\n");
        }
    } else {
        vga_puts("\nThe bus talks to ");
        put_dec((uint32_t)uhci_device_count());
        vga_puts(uhci_device_count() == 1 ? " device.\n" : " devices.\n");
        vga_puts("Reading files from it needs the mass-storage layer, which\n");
        vga_puts("is the next piece of work -- this release is the controller.\n");
    }

    if (verbose)
        vga_puts("\nWhat happened during init is in the kernel log: 'dmesg'.\n");
}
