/*
 * bootanim.c — the splash, and honouring the saved verbose setting
 *
 * This file used to be 260 lines of theatre.  It drew a POST screen that
 * announced "TechHaven BIOS v2.1" and performed a power-on self test --
 * except HavenDOS is not firmware.  SeaBIOS POSTs the machine before GRUB
 * has even loaded the kernel, so this was a second POST for a test that had
 * already happened, and it ended in a blocking keyboard_waitchar().  Then a
 * "boot log" scrolled 24 lines of which twenty were string literals, four of
 * them untrue on any given machine, and waited for a second keypress.
 *
 * Two mandatory keypresses and half a second of sleep_ms padding, to tell
 * you things nobody had measured.
 *
 * What is left: a splash that makes no claims about hardware, and one place
 * that honours the saved "verbose boot" setting.  The actual boot log is
 * printed live by kernel/klog.c as each subsystem initialises, which is the
 * only arrangement that survives a kernel dying halfway through init.
 */
#include "../include/vga.h"
#include "version.h"
#include "../include/string.h"
#include "../include/types.h"
#include "../include/klog.h"

extern int      keyboard_getchar(void);
extern void     sleep_ms(uint32_t ms);

static void cls(void){
    for(int y=0;y<vga_rows();y++)
        for(int x=0;x<vga_cols();x++)
            vga_putchar_at(' ',x,y,VGA_BLACK,VGA_BLACK);
}

static void centre(const char *s, int y, vga_color_t fg){
    int len=0; while(s[len]) len++;
    int x=(vga_cols()-len)/2; if(x<0) x=0;
    vga_puts_at(s,x,y,fg,VGA_BLACK);
}

/* ── the splash ───────────────────────────────────────────────────────
 * Name, version, vendor.  It does not say what hardware is present, what
 * passed a test, or what it is pretending to be -- the log does all of
 * that, from the drivers, a few milliseconds later.
 *
 * It holds briefly so there is a brand moment rather than a flicker, and
 * any keypress cuts it short.  Nothing here blocks: a boot nobody is
 * watching still reaches the system.
 */
void boot_splash(void){
    cls();
    int mid = vga_rows()/2;
    centre("------------------------------------------", mid-3, VGA_DARK_GREY);
    centre(HAVENDOS_NAME,   mid-1, VGA_LIGHT_CYAN);
    centre(HAVENDOS_VER " " HAVENDOS_CHANNEL, mid, VGA_WHITE);
    centre("\"" HAVENDOS_CODENAME "\"", mid+1, VGA_DARK_GREY);
    centre(HAVENDOS_VENDOR, mid+2, VGA_DARK_GREY);
    centre("------------------------------------------", mid+4, VGA_DARK_GREY);
    vga_flush();

    /* 600 ms, in 20 ms steps so a keypress cuts it short.  The old screens
       cost two keypresses and would wait forever for them. */
    for(int i=0;i<30;i++){
        if(keyboard_getchar()>0) break;
        sleep_ms(20);
    }
    cls();
    vga_set_cursor(0,0);
    vga_set_color(VGA_LIGHT_GREY,VGA_BLACK);
}

/* ── the saved setting ────────────────────────────────────────────────
 * Reading the config needs the filesystem, which needs the drivers this log
 * has already described -- so by the time the saved preference is readable,
 * the log has been on screen for most of a second.  That is the right way
 * round: the setting cannot be allowed to decide whether a failing boot gets
 * to say anything.  If verbose is off, the screen is cleared here and the
 * lines stay in the buffer for `dmesg`.
 */
void boot_animation(void){
    extern int cfg_verbose_boot(void);
    if(!cfg_verbose_boot()){
        klog_set_echo(0);
        cls();
        vga_set_cursor(0,0);
    }
}
