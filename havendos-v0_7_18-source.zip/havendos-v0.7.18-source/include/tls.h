#pragma once
#include "types.h"
#define TLS_ERR_HANDSHAKE -1
#define TLS_ERR_ALERT     -2
#define TLS_ERR_CERT      -3
/* v0.7.6: split out of the generic handshake error so wget/curl can say
   something actionable.  A modern server that has disabled static-RSA key
   exchange lands on TLS_ERR_CIPHER or sends alert 40; either way the user
   now sees why rather than "TLS handshake failed". */
#define TLS_ERR_CIPHER    -4
#define TLS_ERR_FINISHED  -5

/* v0.7.5 FIX: these were 1 and 2 — wrong.  TLS ContentType values are
   defined by RFC 5246 A.1 and net/tls.c had to shadow them with local
   #defines (producing "redefined" warnings) to work at all.  Any other
   translation unit that included this header got the bogus values. */
#define TLS_CHANGE_CIPHER_SPEC 20
#define TLS_ALERT              21
#define TLS_HANDSHAKE          22
#define TLS_APPLICATION_DATA   23

int  tls_connect(int tcp_fd, const char *hostname, uint32_t seed);
int  tls_send(int fd, const uint8_t *data, uint16_t len);
int  tls_recv(int fd, uint8_t *buf, uint16_t maxlen, uint32_t timeout_ms);
int  tls_eof(int fd);
void tls_close(int fd);

/* v0.7.6 diagnostics, read by the `tlsinfo` shell command. */
extern int g_tls_last_alert_level;
extern int g_tls_last_alert_desc;
extern int g_tls_last_stage;
extern int g_tls_peer_cipher;
