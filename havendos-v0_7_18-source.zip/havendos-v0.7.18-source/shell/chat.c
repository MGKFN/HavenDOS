/*
 * chat.c — BOOT Chat v2 client   (HavenDOS v0.7.17)
 *
 *   chat <user>@<host>[:<port>]      default port 6700
 *   chat                             reconnect to the last server
 *
 * v0.7.17: a real sidebar, and the mouse works.
 *
 * v0.7.16 shipped the v2 protocol but kept v1's single scrolling pane, so
 * servers, channels and DMs existed on the wire and were invisible on screen
 * — you navigated a tree you could not see by typing /join and hoping. The
 * web and desktop clients both had a sidebar; this one did not, and it was
 * the worst of the three to use.
 *
 * Layout now matches the other two clients:
 *
 *   +----------------+-------------------------------------+
 *   | BOOT Chat      | kyan  techhaven/#dev         ONLINE |
 *   | kyan           |-------------------------------------|
 *   | SERVERS        | messages                            |
 *   |  techhaven     |                                     |
 *   |   # general    |                                     |
 *   |   # dev      * |   <- * marks unread                 |
 *   | DIRECT         |                                     |
 *   |   @ bob        |                                     |
 *   +----------------+-------------------------------------+
 *   | > type here                                          |
 *   +------------------------------------------------------+
 *
 * NAVIGATION
 *   TAB          move focus between the sidebar and the message line
 *   UP/DOWN      move the sidebar selection (when the sidebar has focus)
 *   ENTER        open the selected channel or DM
 *   CLICK        the same, with the mouse, anywhere in the sidebar
 *   PGUP/PGDN    scroll the message pane;  END returns to the bottom
 *   ESC          leave
 *
 * The slash commands from v0.7.16 all still work — /create, /mkchan, /dm and
 * the rest — because creating things still needs a name typed in. The
 * sidebar covers getting around, which is what was actually painful.
 *
 * MOUSE
 * IRQ12 does not fire on UTM SE TCG, so the mouse is polled here exactly as
 * the desktop does: read the position every pass, take the click edge with
 * mouse_get_clicks(), and bracket each frame with ui_erase_cursor() /
 * ui_draw_cursor() so the pointer is never baked into the frame it sits on.
 *
 * Everything else is polled too — a short tcp_recv() timeout alternating
 * with a non-blocking keyboard read. No IRQ dependency anywhere.
 */

#include "../include/types.h"
#include "../include/string.h"
#include "../include/vga.h"
#include "../include/net.h"
#include "../include/tcp.h"
#include "../include/dns.h"
#include "../include/toast.h"

extern int      keyboard_getchar(void);
extern void     sleep_ms(uint32_t ms);
extern void     net_poll(void);
extern uint32_t get_ticks(void);
extern int      net_ready(void);
extern void     notif_push(const char *msg);

/* mouse — same polling API the desktop uses */
extern void     mouse_get(int *x, int *y, int *btn);
extern int      mouse_is_ready(void);
extern int      mouse_get_clicks(void);
extern void     ui_draw_cursor(void);
extern void     ui_erase_cursor(void);
extern void     ui_force_cursor_redraw(void);

#define CHAT_PORT_DEFAULT 6700
#define CHAT_SCROLL       200
#define CHAT_LINE         96
#define CHAT_INPUT        160
/* v0.7.18 FIX — CHAT_LINE is the DISPLAY width of one scrollback row.  It was
   also being used to size the receive assembler, which silently threw away
   every byte past 95 in any server line.  A `MSG <srv> <chan> <user> <ts> `
   prefix costs ~40 of those, so messages were cut to roughly 55 characters,
   and a CHANLIST/DMLIST/ONLINE line with several entries lost the tail —
   channels simply vanished from the sidebar.  The wire needs its own size. */
#define CHAT_WIRE         1024
#define NAME_MAX          24
#define SIDE_W            18      /* sidebar columns, including its border */

/* sidebar model */
#define MAX_SRV      8
#define MAX_CHAN    12
#define MAX_DM      12
#define MAX_ITEMS   64

#define SB_HDR   0
#define SB_SRV   1
#define SB_CHAN  2
#define SB_DM    3

typedef struct {
    uint8_t kind;
    uint8_t unread;
    char    a[NAME_MAX];     /* server name, or DM peer */
    char    b[NAME_MAX];     /* channel name (SB_CHAN only) */
} sbitem_t;

typedef struct {
    char    text[CHAT_LINE];
    uint8_t fg;
} chat_line_t;

static chat_line_t g_scroll[CHAT_SCROLL];
static int  g_count, g_head, g_view;

static char g_last_target[80];
static char g_nick[NAME_MAX];
static char g_server[NAME_MAX];
static char g_channel[NAME_MAX];
static char g_dmwith[NAME_MAX];
static int  g_authed;

static char g_srv[MAX_SRV][NAME_MAX];            static int g_nsrv;
static char g_chan[MAX_SRV][MAX_CHAN][NAME_MAX]; static int g_nchan[MAX_SRV];
static char g_dm[MAX_DM][NAME_MAX];              static int g_ndm;

static sbitem_t g_items[MAX_ITEMS];
static int g_nitems, g_sel, g_sbtop;
static int g_focus_side;          /* 0 = message line, 1 = sidebar */

/* ══ v0.7.15: emoji ═══════════════════════════════════════════════════════
 *
 * The wire is UTF-8 now, so a phone can send 😀 and a HavenDOS client will
 * receive four bytes for it.  VGA text mode has one byte per cell and 256
 * glyphs (code page 437), so real emoji cannot be drawn — but CP437 already
 * ships ☺ ☻ ♥ ♦ ♣ ♠ ♪ ♫ ☼ and the arrows, which covers the common ones
 * surprisingly well and looks right for a DOS-style OS.
 *
 * Incoming UTF-8 is decoded to codepoints and mapped to those glyphs.
 * Accented Latin-1 letters fold to their base ASCII letter (é -> e) rather
 * than to CP437's high range, because the 8x8 font used by the wide text
 * modes has glyphs 128-255 blank — folding renders everywhere, CP437 would
 * render only in 80x25.
 *
 * Anything with no sensible glyph becomes '?'.  That is honest: it says
 * "something was here that I cannot draw" instead of silently dropping it or
 * emitting four bytes of garbage.
 *
 * Outgoing, a HavenDOS user types :shortcodes: — the client sends the real
 * UTF-8 emoji so phones see 😀, and shows the CP437 glyph locally.
 * ═══════════════════════════════════════════════════════════════════════ */

/* Latin-1 / Latin-Ext -> CP437.  These glyphs exist in the BIOS font and, as
   of v0.7.15, in the 8x8 font too (see tools/make_font_ext.py), so accented
   text renders the same in every text mode. */
typedef struct { uint32_t cp; uint8_t g; } cp437_map_t;
static const cp437_map_t g_cp437[] = {
    {0x00C7,0x80},{0x00FC,0x81},{0x00E9,0x82},{0x00E2,0x83},{0x00E4,0x84},
    {0x00E0,0x85},{0x00E5,0x86},{0x00E7,0x87},{0x00EA,0x88},{0x00EB,0x89},
    {0x00E8,0x8A},{0x00EF,0x8B},{0x00EE,0x8C},{0x00EC,0x8D},{0x00C4,0x8E},
    {0x00C5,0x8F},{0x00C9,0x90},{0x00F4,0x93},{0x00F6,0x94},{0x00F2,0x95},
    {0x00FB,0x96},{0x00F9,0x97},{0x00FF,0x98},{0x00D6,0x99},{0x00DC,0x9A},
    {0x00E1,0xA0},{0x00ED,0xA1},{0x00F3,0xA2},{0x00FA,0xA3},{0x00F1,0xA4},
    {0x00D1,0xA5},{0x00DF,0xE1},
};
#define CP437_N ((int)(sizeof(g_cp437)/sizeof(g_cp437[0])))

/* Emoji have no glyph and never will — one byte per cell, 256 of them.  They
   are spelled out instead: a name reads correctly in every mode, survives
   being copied into a file, and never leaves the user guessing what the
   square was.  Unnamed emoji become [emoji] rather than a wrong picture. */
typedef struct { uint32_t cp; const char *name; } emoji_name_t;
static const emoji_name_t g_emoji[] = {
    {0x1F600,"[grin]"},    {0x1F603,"[smile]"},   {0x1F604,"[smile]"},
    {0x1F601,"[grin]"},    {0x1F642,"[smile]"},   {0x1F60A,"[happy]"},
    {0x1F609,"[wink]"},    {0x263A,"[smile]"},    {0x1F602,"[laugh]"},
    {0x1F923,"[laugh]"},   {0x1F605,"[sweat]"},   {0x1F60D,"[love]"},
    {0x1F618,"[kiss]"},    {0x1F61B,"[tongue]"},  {0x1F60E,"[cool]"},
    {0x1F914,"[thinking]"},{0x1F644,"[eyeroll]"}, {0x1F62D,"[crying]"},
    {0x1F622,"[sad]"},     {0x1F61E,"[sad]"},     {0x1F620,"[angry]"},
    {0x1F621,"[angry]"},   {0x1F631,"[shock]"},   {0x1F62E,"[surprised]"},
    {0x1F634,"[sleepy]"},  {0x1F480,"[skull]"},   {0x1F608,"[devil]"},
    {0x1F921,"[clown]"},   {0x1F916,"[robot]"},   {0x1F47B,"[ghost]"},
    /* hearts + symbols */
    {0x2764,"[heart]"},    {0x2665,"[heart]"},    {0x1F496,"[heart]"},
    {0x1F495,"[hearts]"},  {0x1F497,"[heart]"},   {0x1F494,"[broken heart]"},
    {0x2666,"[diamond]"},  {0x2663,"[club]"},     {0x2660,"[spade]"},
    {0x2B50,"[star]"},     {0x1F31F,"[star]"},    {0x2728,"[sparkles]"},
    {0x1F525,"[fire]"},    {0x1F4A5,"[boom]"},    {0x26A1,"[lightning]"},
    {0x2705,"[check]"},    {0x274C,"[cross]"},    {0x2757,"[!]"},
    {0x2753,"[?]"},        {0x1F4AF,"[100]"},
    /* hands */
    {0x1F44D,"[thumbs up]"},  {0x1F44E,"[thumbs down]"},
    {0x1F44F,"[clap]"},       {0x1F64C,"[praise]"},
    {0x1F64F,"[please]"},     {0x270C,"[peace]"},
    {0x1F44B,"[wave]"},       {0x1F91D,"[handshake]"},
    {0x1F4AA,"[strong]"},
    /* things */
    {0x1F3B5,"[music]"},   {0x266A,"[music]"},    {0x1F3B6,"[music]"},
    {0x266B,"[music]"},    {0x2600,"[sun]"},      {0x1F31E,"[sun]"},
    {0x1F319,"[moon]"},    {0x2601,"[cloud]"},    {0x2614,"[rain]"},
    {0x2744,"[snow]"},     {0x1F355,"[pizza]"},   {0x1F354,"[burger]"},
    {0x2615,"[coffee]"},   {0x1F37A,"[beer]"},    {0x1F382,"[cake]"},
    {0x1F389,"[party]"},   {0x1F381,"[gift]"},    {0x1F4BB,"[laptop]"},
    {0x1F4BE,"[floppy]"},  {0x1F4F1,"[phone]"},   {0x1F527,"[wrench]"},
    {0x1F41B,"[bug]"},     {0x1F680,"[rocket]"},  {0x1F697,"[car]"},
    {0x26BD,"[ball]"},     {0x1F3AE,"[game]"},    {0x1F4D6,"[book]"},
    /* arrows */
    {0x2B06,"[up]"},       {0x2191,"[up]"},       {0x2B07,"[down]"},
    {0x2193,"[down]"},     {0x27A1,"[right]"},    {0x2192,"[right]"},
    {0x2B05,"[left]"},     {0x2190,"[left]"},
};
#define EMOJI_N ((int)(sizeof(g_emoji)/sizeof(g_emoji[0])))

/* :shortcode: -> the UTF-8 a phone should see. Ordered LONGEST FIRST: the
   scanner takes the first match at a given ':', so a short code that prefixes
   a longer one would shadow it. */
typedef struct { const char *code; const char *utf8; } shortcode_t;
static const shortcode_t g_shortcodes[] = {
    {":thumbsup:","\xF0\x9F\x91\x8D"},
    {":smile:",   "\xF0\x9F\x98\x80"},
    {":heart:",   "\xE2\x9D\xA4"},
    {":music:",   "\xF0\x9F\x8E\xB5"},
    {":party:",   "\xF0\x9F\x8E\x89"},
    {":star:",    "\xE2\xAD\x90"},
    {":fire:",    "\xF0\x9F\x94\xA5"},
    {":cool:",    "\xF0\x9F\x98\x8E"},
    {":thumb:",   "\xF0\x9F\x91\x8D"},
    {":down:",    "\xF0\x9F\x91\x8E"},
    {":wave:",    "\xF0\x9F\x91\x8B"},
    {":cry:",     "\xF0\x9F\x98\xAD"},
    {":<3:",      "\xE2\x9D\xA4"},
    {":+1:",      "\xF0\x9F\x91\x8D"},
    {":-1:",      "\xF0\x9F\x91\x8E"},
    {":)",        "\xF0\x9F\x99\x82"},
    {":(",        "\xF0\x9F\x98\x9E"},
};
#define SHORTCODE_N ((int)(sizeof(g_shortcodes)/sizeof(g_shortcodes[0])))

/* Fallback for accented letters with no CP437 glyph (Ê, Ï, Ô, Á ...). */
static char fold_latin1(uint32_t cp)
{
    if(cp>=0xC0&&cp<=0xC5) return 'A';
    if(cp==0xC7)           return 'C';
    if(cp>=0xC8&&cp<=0xCB) return 'E';
    if(cp>=0xCC&&cp<=0xCF) return 'I';
    if(cp==0xD1)           return 'N';
    if(cp>=0xD2&&cp<=0xD6) return 'O';
    if(cp>=0xD9&&cp<=0xDC) return 'U';
    if(cp==0xDD)           return 'Y';
    if(cp>=0xE0&&cp<=0xE5) return 'a';
    if(cp==0xE7)           return 'c';
    if(cp>=0xE8&&cp<=0xEB) return 'e';
    if(cp>=0xEC&&cp<=0xEF) return 'i';
    if(cp==0xF1)           return 'n';
    if(cp>=0xF2&&cp<=0xF6) return 'o';
    if(cp>=0xF9&&cp<=0xFC) return 'u';
    if(cp==0xFD||cp==0xFF) return 'y';
    return 0;
}

/* Decode one UTF-8 sequence. Returns bytes consumed, 0 if malformed. */
static int utf8_next(const char *s, uint32_t *cp)
{
    const uint8_t *u = (const uint8_t*)s;
    if(u[0] < 0x80){ *cp = u[0]; return 1; }
    if((u[0]&0xE0)==0xC0 && (u[1]&0xC0)==0x80){
        *cp = ((uint32_t)(u[0]&0x1F)<<6) | (u[1]&0x3F); return 2; }
    if((u[0]&0xF0)==0xE0 && (u[1]&0xC0)==0x80 && (u[2]&0xC0)==0x80){
        *cp = ((uint32_t)(u[0]&0x0F)<<12) | ((uint32_t)(u[1]&0x3F)<<6) | (u[2]&0x3F);
        return 3; }
    if((u[0]&0xF8)==0xF0 && (u[1]&0xC0)==0x80 && (u[2]&0xC0)==0x80 && (u[3]&0xC0)==0x80){
        *cp = ((uint32_t)(u[0]&0x07)<<18) | ((uint32_t)(u[1]&0x3F)<<12) |
              ((uint32_t)(u[2]&0x3F)<<6)  | (u[3]&0x3F);
        return 4; }
    return 0;
}

/* Rewrite a UTF-8 line in place as something the text mode can draw. */
static void utf8_to_cp437(char *buf, int bufsz)
{
    /* Spelling an emoji out makes the line LONGER than its UTF-8 source
       ("[thumbs up]" from four bytes), so the scratch buffer carries 3x
       headroom.  static, not stack: this is sized for the wire now and
       chat.c is single-threaded. */
    static char out[CHAT_WIRE*3];
    int o = 0, i = 0;
    while(buf[i] && o < (int)sizeof(out)-1){
        uint32_t cp; int n = utf8_next(buf + i, &cp);
        if(n == 0){ i++; out[o++] = '?'; continue; }
        i += n;
        if(cp < 0x80){ out[o++] = (char)cp; continue; }

        /* accented letter with a real glyph */
        int hit = 0;
        for(int m = 0; m < CP437_N; m++)
            if(g_cp437[m].cp == cp){ out[o++] = (char)g_cp437[m].g; hit = 1; break; }
        if(hit) continue;

        /* accented letter without one — fold to the base letter */
        char f = fold_latin1(cp);
        if(f){ out[o++] = f; continue; }

        /* zero-width joiners and variation selectors carry no glyph of their
           own; drop them silently or one heart becomes "[heart]?" */
        if(cp == 0xFE0F || cp == 0xFE0E || cp == 0x200D) continue;
        if(cp >= 0x1F3FB && cp <= 0x1F3FF) continue;   /* skin-tone modifiers */

        /* emoji: spell it out */
        const char *name = 0;
        for(int e = 0; e < EMOJI_N; e++)
            if(g_emoji[e].cp == cp){ name = g_emoji[e].name; break; }
        if(!name){
            int is_emoji = (cp >= 0x1F300 && cp <= 0x1FAFF) ||
                           (cp >= 0x2600  && cp <= 0x27BF);
            name = is_emoji ? "[emoji]" : 0;
        }
        if(name){
            for(int k = 0; name[k] && o < (int)sizeof(out)-1; k++) out[o++] = name[k];
        } else {
            out[o++] = '?';
        }
    }
    out[o] = 0;
    int k = 0;
    while(out[k] && k < bufsz-1){ buf[k] = out[k]; k++; }
    buf[k] = 0;
}

/* Expand :shortcodes: to UTF-8 on the way out. */
static void expand_shortcodes(const char *in, char *out, int outsz)
{
    int o = 0, i = 0;
    while(in[i] && o < outsz-1){
        int matched = 0;
        if(in[i] == ':'){
            for(int c = 0; c < SHORTCODE_N; c++){
                int L = (int)strlen(g_shortcodes[c].code);
                if(!strncmp(in + i, g_shortcodes[c].code, (size_t)L)){
                    const char *u = g_shortcodes[c].utf8;
                    for(int k = 0; u[k] && o < outsz-1; k++) out[o++] = u[k];
                    i += L; matched = 1; break;
                }
            }
        }
        if(!matched) out[o++] = in[i++];
    }
    out[o] = 0;
}

/* ── scrollback ──────────────────────────────────────────────────── */

static void sb_reset(void){ g_count = 0; g_head = 0; g_view = 0; }

static void sb_add(const char *s, uint8_t fg)
{
    chat_line_t *l = &g_scroll[g_head];
    int i = 0;
    while(s[i] && i < CHAT_LINE-1){ l->text[i] = s[i]; i++; }
    l->text[i] = 0;
    l->fg = fg;
    g_head = (g_head + 1) % CHAT_SCROLL;
    if(g_count < CHAT_SCROLL) g_count++;
    /* Only auto-follow when already pinned to the bottom — otherwise a busy
       channel would yank the view away while the user is reading back. */
    if(g_view > 0 && g_view < CHAT_SCROLL) g_view++;
}

/* Wrap a long line across the message pane instead of truncating it. */
static void sb_add_wrapped(const char *s, uint8_t fg)
{
    int w = vga_cols() - SIDE_W - 2;
    if(w < 16) w = 16;
    if(w > CHAT_LINE-1) w = CHAT_LINE-1;
    int len = (int)strlen(s);
    if(len <= w){ sb_add(s, fg); return; }

    char part[CHAT_LINE];
    int pos = 0;
    while(pos < len){
        int n = len - pos; if(n > w) n = w;
        if(pos + n < len){                 /* break on the last space */
            int br = n;
            while(br > 8 && s[pos+br] != ' ') br--;
            if(br > 8) n = br;
        }
        for(int i=0;i<n;i++) part[i] = s[pos+i];
        part[n] = 0;
        sb_add(part, fg);
        pos += n;
        while(pos < len && s[pos] == ' ') pos++;
    }
}

/* ── sidebar model ───────────────────────────────────────────────── */

static int srv_index(const char *name)
{
    for(int i=0;i<g_nsrv;i++) if(!strcmp(g_srv[i], name)) return i;
    return -1;
}

static int srv_add(const char *name)
{
    int i = srv_index(name);
    if(i >= 0) return i;
    if(g_nsrv >= MAX_SRV) return -1;
    strncpy(g_srv[g_nsrv], name, NAME_MAX-1); g_srv[g_nsrv][NAME_MAX-1] = 0;
    g_nchan[g_nsrv] = 0;
    return g_nsrv++;
}

static void dm_add(const char *user)
{
    if(!user[0]) return;
    for(int i=0;i<g_ndm;i++) if(!strcmp(g_dm[i], user)) return;
    if(g_ndm >= MAX_DM) return;
    strncpy(g_dm[g_ndm], user, NAME_MAX-1); g_dm[g_ndm][NAME_MAX-1] = 0;
    g_ndm++;
}

/* Rebuild the flat display list from the model, preserving unread flags. */
static void items_rebuild(void)
{
    sbitem_t old[MAX_ITEMS];
    int nold = g_nitems;
    for(int i=0;i<nold;i++) old[i] = g_items[i];

    g_nitems = 0;
    if(g_nsrv){
        if(g_nitems < MAX_ITEMS){
            g_items[g_nitems].kind = SB_HDR; g_items[g_nitems].unread = 0;
            strcpy(g_items[g_nitems].a, "SERVERS"); g_items[g_nitems].b[0] = 0;
            g_nitems++;
        }
        for(int s=0; s<g_nsrv && g_nitems<MAX_ITEMS; s++){
            g_items[g_nitems].kind = SB_SRV; g_items[g_nitems].unread = 0;
            strcpy(g_items[g_nitems].a, g_srv[s]); g_items[g_nitems].b[0] = 0;
            g_nitems++;
            for(int c=0; c<g_nchan[s] && g_nitems<MAX_ITEMS; c++){
                g_items[g_nitems].kind = SB_CHAN; g_items[g_nitems].unread = 0;
                strcpy(g_items[g_nitems].a, g_srv[s]);
                strcpy(g_items[g_nitems].b, g_chan[s][c]);
                g_nitems++;
            }
        }
    }
    if(g_ndm){
        if(g_nitems < MAX_ITEMS){
            g_items[g_nitems].kind = SB_HDR; g_items[g_nitems].unread = 0;
            strcpy(g_items[g_nitems].a, "DIRECT"); g_items[g_nitems].b[0] = 0;
            g_nitems++;
        }
        for(int d=0; d<g_ndm && g_nitems<MAX_ITEMS; d++){
            g_items[g_nitems].kind = SB_DM; g_items[g_nitems].unread = 0;
            strcpy(g_items[g_nitems].a, g_dm[d]); g_items[g_nitems].b[0] = 0;
            g_nitems++;
        }
    }
    /* carry unread flags across a rebuild — a CHANLIST refresh must not
       silently clear the marks that tell you where new traffic landed */
    for(int i=0;i<g_nitems;i++){
        for(int j=0;j<nold;j++){
            if(old[j].kind == g_items[i].kind &&
               !strcmp(old[j].a, g_items[i].a) &&
               !strcmp(old[j].b, g_items[i].b)){
                g_items[i].unread = old[j].unread; break;
            }
        }
    }
    if(g_sel >= g_nitems) g_sel = g_nitems ? g_nitems-1 : 0;
}

static void mark_unread(uint8_t kind, const char *a, const char *b)
{
    for(int i=0;i<g_nitems;i++){
        if(g_items[i].kind != kind) continue;
        if(strcmp(g_items[i].a, a)) continue;
        if(b && strcmp(g_items[i].b, b)) continue;
        g_items[i].unread = 1;
        return;
    }
}

static void clear_unread_here(void)
{
    for(int i=0;i<g_nitems;i++){
        if(g_dmwith[0]){
            if(g_items[i].kind == SB_DM && !strcmp(g_items[i].a, g_dmwith))
                g_items[i].unread = 0;
        } else if(g_items[i].kind == SB_CHAN &&
                  !strcmp(g_items[i].a, g_server) &&
                  !strcmp(g_items[i].b, g_channel)){
            g_items[i].unread = 0;
        }
    }
}

static int item_selectable(int i)
{
    return i >= 0 && i < g_nitems && g_items[i].kind != SB_HDR;
}

static void sel_step(int dir)
{
    if(!g_nitems) return;
    int i = g_sel;
    for(int guard=0; guard<MAX_ITEMS; guard++){
        i += dir;
        if(i < 0) i = 0;
        if(i >= g_nitems) i = g_nitems-1;
        if(item_selectable(i)){ g_sel = i; return; }
        if(i == 0 && dir < 0) return;
        if(i == g_nitems-1 && dir > 0) return;
    }
}

/* ── drawing ─────────────────────────────────────────────────────── */

/* Write a string into a fixed-width field, clipped and space-padded. */
static void put_field(const char *s, int x, int y, int w,
                      vga_color_t fg, vga_color_t bg)
{
    int i = 0;
    for(; s[i] && i < w; i++) vga_putchar_at(s[i], x+i, y, fg, bg);
    for(; i < w; i++)         vga_putchar_at(' ',  x+i, y, fg, bg);
}

static void draw_sidebar(int top, int bottom)
{
    int rows = bottom - top + 1;
    if(rows < 1) return;

    /* keep the selection on screen */
    if(g_sel < g_sbtop)            g_sbtop = g_sel;
    if(g_sel >= g_sbtop + rows)    g_sbtop = g_sel - rows + 1;
    if(g_sbtop < 0)                g_sbtop = 0;

    for(int r=0; r<rows; r++){
        int y = top + r;
        int i = g_sbtop + r;
        vga_color_t bg = VGA_BLACK, fg = VGA_LIGHT_GREY;
        char line[SIDE_W + 2];
        line[0] = 0;

        if(i < g_nitems){
            const sbitem_t *it = &g_items[i];
            int sel = (i == g_sel);
            if(it->kind == SB_HDR){
                strcpy(line, " ");
                strncat(line, it->a, sizeof(line)-strlen(line)-1);
                fg = VGA_DARK_GREY;
            } else if(it->kind == SB_SRV){
                strcpy(line, " ");
                strncat(line, it->a, sizeof(line)-strlen(line)-1);
                fg = VGA_LIGHT_CYAN;
            } else if(it->kind == SB_CHAN){
                strcpy(line, "  #");
                strncat(line, it->b, sizeof(line)-strlen(line)-1);
                int here = !g_dmwith[0] && !strcmp(it->a, g_server)
                                        && !strcmp(it->b, g_channel);
                fg = here ? VGA_WHITE : VGA_LIGHT_GREY;
            } else {
                strcpy(line, "  @");
                strncat(line, it->a, sizeof(line)-strlen(line)-1);
                int here = g_dmwith[0] && !strcmp(it->a, g_dmwith);
                fg = here ? VGA_WHITE : VGA_LIGHT_GREY;
            }
            if(sel && g_focus_side){ bg = VGA_BLUE; fg = VGA_WHITE; }
            put_field(line, 0, y, SIDE_W-1, fg, bg);
            /* unread marker in the last column of the sidebar */
            vga_putchar_at(it->unread ? '*' : ' ', SIDE_W-2, y,
                           VGA_YELLOW, bg);
        } else {
            put_field("", 0, y, SIDE_W-1, fg, bg);
        }
        vga_putchar_at('|', SIDE_W-1, y, VGA_DARK_GREY, VGA_BLACK);
    }
}

static void draw(const char *host, const char *input, int connected)
{
    int rows = vga_rows(), cols = vga_cols();
    int top = 1, bottom = rows - 3;
    int body = bottom - top + 1;
    if(body < 1) return;

    int mx = SIDE_W;                 /* first column of the message pane */
    int mw = cols - mx;              /* its width */
    if(mw < 10) return;

    vga_begin_frame();

    /* ── title bar ── */
    vga_fill_row(0, ' ', VGA_WHITE, VGA_BLUE);
    {
        /* Show WHERE you are. With servers, channels and DMs there are now
           several places a message could go, and a title that only names the
           host makes it easy to type into the wrong one. */
        char t[128];
        strcpy(t, " BOOT Chat  ");
        strncat(t, g_nick, sizeof(t)-strlen(t)-1);
        if(g_dmwith[0]){
            strncat(t, "  @", sizeof(t)-strlen(t)-1);
            strncat(t, g_dmwith, sizeof(t)-strlen(t)-1);
        } else if(g_channel[0]){
            strncat(t, "  ", sizeof(t)-strlen(t)-1);
            strncat(t, g_server, sizeof(t)-strlen(t)-1);
            strncat(t, "/#", sizeof(t)-strlen(t)-1);
            strncat(t, g_channel, sizeof(t)-strlen(t)-1);
        } else {
            strncat(t, "  (no channel)", sizeof(t)-strlen(t)-1);
        }
        (void)host;
        vga_puts_at(t, 0, 0, VGA_WHITE, VGA_BLUE);
        const char *st = connected ? "ONLINE" : "OFFLINE";
        int x = cols - (int)strlen(st) - 1;
        if(x > 0) vga_puts_at(st, x, 0,
                              connected ? VGA_LIGHT_GREEN : VGA_LIGHT_RED, VGA_BLUE);
    }

    draw_sidebar(top, bottom);

    /* ── message pane — oldest visible line first ── */
    int shown = g_count < body ? g_count : body;
    int first = g_count - shown - g_view;
    if(first < 0) first = 0;
    for(int r = 0; r < body; r++){
        int y = top + r;
        for(int x = mx; x < cols; x++)
            vga_putchar_at(' ', x, y, VGA_LIGHT_GREY, VGA_BLACK);
        int idx = first + r;
        if(r < shown && idx < g_count){
            int slot = (g_head - g_count + idx + CHAT_SCROLL*2) % CHAT_SCROLL;
            put_field(g_scroll[slot].text, mx+1, y, mw-1,
                      (vga_color_t)g_scroll[slot].fg, VGA_BLACK);
        }
    }

    /* ── separator + input ── */
    vga_fill_row(rows-2, '-', VGA_DARK_GREY, VGA_BLACK);
    vga_fill_row(rows-1, ' ', VGA_WHITE, VGA_BLACK);
    vga_puts_at(g_focus_side ? "  " : "> ", 0, rows-1,
                VGA_LIGHT_GREEN, VGA_BLACK);
    {
        int avail = cols - 3;
        int len = (int)strlen(input);
        const char *show = (len > avail) ? input + (len - avail) : input;
        vga_puts_at(show, 2, rows-1, VGA_WHITE, VGA_BLACK);
        int cx = 2 + (len > avail ? avail : len);
        if(cx >= cols) cx = cols-1;
        vga_set_cursor(cx, rows-1);
    }

    if(g_focus_side){
        const char *m = " TAB back to typing  ENTER open ";
        int x = cols - (int)strlen(m) - 1;
        if(x > SIDE_W) vga_puts_at(m, x, rows-2, VGA_BLACK, VGA_LIGHT_GREY);
    } else if(g_view > 0){
        const char *m = " SCROLLBACK - End to return ";
        int x = cols - (int)strlen(m) - 1;
        if(x > SIDE_W) vga_puts_at(m, x, rows-2, VGA_BLACK, VGA_LIGHT_GREY);
    }

    vga_end_frame();
}

/* ── protocol ────────────────────────────────────────────────────── */

static int send_line(int fd, const char *s)
{
    /* Shortcode expansion turns 2 typed bytes into up to 4 UTF-8 bytes, so
       the outgoing buffer is sized for the worst case, not the typed length. */
    char buf[CHAT_INPUT * 4 + 8];
    int n = 0;
    while(s[n] && n < (int)sizeof(buf) - 2){ buf[n] = s[n]; n++; }
    buf[n++] = '\n';
    return tcp_send(fd, buf, (uint16_t)n);
}

/* Split off the next space-delimited field. Returns a pointer past it. */
static char *field(char *p, char *out, int outsz)
{
    int i = 0;
    while(*p == ' ') p++;
    while(*p && *p != ' ' && i < outsz-1) out[i++] = *p++;
    out[i] = 0;
    /* v0.7.18 FIX — a token longer than `out` used to leave p sitting INSIDE
       it, so the tail was then parsed as the next field and every field after
       it shifted by one.  Discard the remainder of the token instead. */
    while(*p && *p != ' ') p++;
    while(*p == ' ') p++;
    return p;
}

static int in_view_channel(const char *srv, const char *chan)
{
    return !g_dmwith[0] && !strcmp(srv, g_server) && !strcmp(chan, g_channel);
}

static void handle_line(int fd, char *line)
{
    if(!line[0]) return;

    char verb[16];
    char *rest = field(line, verb, sizeof(verb));

    if(!strcmp(verb, "TOKEN")) return;
    if(!strcmp(verb, "HISTEND")) return;

    if(!strcmp(verb, "OK")){
        char what[16];
        char *d = field(rest, what, sizeof(what));
        if(!strcmp(what, "LOGIN")){
            g_authed = 1;
            char m[CHAT_LINE];
            strcpy(m, "-- signed in as ");
            strncat(m, d, sizeof(m)-strlen(m)-1);
            sb_add(m, VGA_LIGHT_GREEN);
        } else if(!strcmp(what, "JOIN")){
            char srv[NAME_MAX], chan[NAME_MAX];
            char *q = field(d, srv, sizeof(srv));
            field(q, chan, sizeof(chan));
            strncpy(g_server, srv, NAME_MAX-1);   g_server[NAME_MAX-1] = 0;
            strncpy(g_channel, chan, NAME_MAX-1); g_channel[NAME_MAX-1] = 0;
            g_dmwith[0] = 0;
            sb_reset();
            clear_unread_here();
        } else if(!strcmp(what, "CREATE") || !strcmp(what, "JOINSRV")){
            srv_add(d); items_rebuild();
            char c[96];
            strcpy(c, "CHANNELS ");
            strncat(c, d, sizeof(c)-strlen(c)-1);
            send_line(fd, c);
        } else if(!strcmp(what, "MKCHAN")){
            if(g_server[0]){
                char c[96];
                strcpy(c, "CHANNELS ");
                strncat(c, g_server, sizeof(c)-strlen(c)-1);
                send_line(fd, c);
            }
        } else {
            char m[CHAT_LINE];
            strcpy(m, "-- ok: ");
            strncat(m, what, sizeof(m)-strlen(m)-1);
            if(d[0]){ strncat(m, " ", sizeof(m)-strlen(m)-1);
                      strncat(m, d, sizeof(m)-strlen(m)-1); }
            sb_add(m, VGA_LIGHT_CYAN);
        }
        return;
    }

    if(!strcmp(verb, "ERR")){ sb_add_wrapped(rest, VGA_LIGHT_RED); return; }

    if(!strcmp(verb, "SERVERLIST")){
        char name[NAME_MAX];
        char *q = rest;
        g_nsrv = 0;
        while(*q){
            q = field(q, name, sizeof(name));
            if(name[0]) srv_add(name);
        }
        items_rebuild();
        if(!g_nsrv) sb_add("-- no servers yet; try /create <name>", VGA_LIGHT_CYAN);
        /* ask for each server's channels so the tree fills itself in */
        for(int i=0;i<g_nsrv;i++){
            char c[96];
            strcpy(c, "CHANNELS ");
            strncat(c, g_srv[i], sizeof(c)-strlen(c)-1);
            send_line(fd, c);
        }
        send_line(fd, "DMLIST");
        return;
    }

    if(!strcmp(verb, "CHANLIST")){
        char srv[NAME_MAX], chan[NAME_MAX];
        char *q = field(rest, srv, sizeof(srv));
        int si = srv_add(srv);
        if(si < 0) return;
        g_nchan[si] = 0;
        while(*q && g_nchan[si] < MAX_CHAN){
            q = field(q, chan, sizeof(chan));
            if(!chan[0]) break;
            strncpy(g_chan[si][g_nchan[si]], chan, NAME_MAX-1);
            g_chan[si][g_nchan[si]][NAME_MAX-1] = 0;
            g_nchan[si]++;
        }
        items_rebuild();
        return;
    }

    if(!strcmp(verb, "DMLIST")){
        char name[NAME_MAX];
        char *q = rest;
        g_ndm = 0;
        while(*q){
            q = field(q, name, sizeof(name));
            if(name[0]) dm_add(name);
        }
        items_rebuild();
        return;
    }

    if(!strcmp(verb, "ONLINE")){
        char m[CHAT_WIRE];
        strcpy(m, "-- online: ");
        strncat(m, rest, sizeof(m)-strlen(m)-1);
        sb_add_wrapped(m, VGA_LIGHT_CYAN);
        return;
    }

    /* MSG <server> <channel> <user> <ts> <text> */
    if(!strcmp(verb, "MSG")){
        char srv[NAME_MAX], chan[NAME_MAX], who[NAME_MAX], ts[16];
        char *q = field(rest, srv, sizeof(srv));
        q = field(q, chan, sizeof(chan));
        q = field(q, who, sizeof(who));
        q = field(q, ts, sizeof(ts));
        if(!in_view_channel(srv, chan)){
            mark_unread(SB_CHAN, srv, chan);   /* show it in the sidebar */
            return;
        }
        char out[CHAT_WIRE];
        strcpy(out, "<");
        strncat(out, who, sizeof(out)-strlen(out)-1);
        strncat(out, "> ", sizeof(out)-strlen(out)-1);
        strncat(out, q, sizeof(out)-strlen(out)-1);
        sb_add_wrapped(out, strcmp(who, g_nick) == 0 ? VGA_LIGHT_GREEN : VGA_WHITE);
        return;
    }

    /* DMMSG <from> <to> <ts> <text> */
    if(!strcmp(verb, "DMMSG")){
        char frm[NAME_MAX], to[NAME_MAX], ts[16];
        char *q = field(rest, frm, sizeof(frm));
        q = field(q, to, sizeof(to));
        q = field(q, ts, sizeof(ts));
        const char *other = strcmp(frm, g_nick) ? frm : to;
        dm_add(other);
        items_rebuild();
        if(!g_dmwith[0] || strcmp(other, g_dmwith)){
            mark_unread(SB_DM, other, 0);
            return;
        }
        char out[CHAT_WIRE];
        strcpy(out, "<");
        strncat(out, frm, sizeof(out)-strlen(out)-1);
        strncat(out, "> ", sizeof(out)-strlen(out)-1);
        strncat(out, q, sizeof(out)-strlen(out)-1);
        sb_add_wrapped(out, strcmp(frm, g_nick) == 0 ? VGA_LIGHT_GREEN : VGA_WHITE);
        return;
    }

    if(!strcmp(verb, "JOINED")){
        char who[NAME_MAX];
        field(rest, who, sizeof(who));
        char m[CHAT_LINE];
        strcpy(m, "-- "); strncat(m, who, sizeof(m)-strlen(m)-1);
        strncat(m, " joined", sizeof(m)-strlen(m)-1);
        sb_add(m, VGA_LIGHT_CYAN);
        return;
    }
    if(!strcmp(verb, "LEFT")){
        char m[CHAT_LINE];
        strcpy(m, "-- "); strncat(m, rest, sizeof(m)-strlen(m)-1);
        strncat(m, " left", sizeof(m)-strlen(m)-1);
        sb_add(m, VGA_LIGHT_CYAN);
        return;
    }

    sb_add_wrapped(line, VGA_DARK_GREY);   /* unknown verb — show, don't drop */
}

/* Open whatever the sidebar selection points at. */
static void activate(int fd, int idx)
{
    if(!item_selectable(idx)) return;
    sbitem_t *it = &g_items[idx];
    char c[96];
    if(it->kind == SB_CHAN){
        strcpy(c, "JOIN ");
        strncat(c, it->a, sizeof(c)-strlen(c)-1);
        strncat(c, " ", sizeof(c)-strlen(c)-1);
        strncat(c, it->b, sizeof(c)-strlen(c)-1);
        send_line(fd, c);
        it->unread = 0;
    } else if(it->kind == SB_DM){
        strncpy(g_dmwith, it->a, NAME_MAX-1); g_dmwith[NAME_MAX-1] = 0;
        g_channel[0] = 0;
        sb_reset();
        it->unread = 0;
        strcpy(c, "DMHIST ");
        strncat(c, g_dmwith, sizeof(c)-strlen(c)-1);
        send_line(fd, c);
    } else if(it->kind == SB_SRV){
        strcpy(c, "CHANNELS ");
        strncat(c, it->a, sizeof(c)-strlen(c)-1);
        send_line(fd, c);
    }
}

/* ── target parsing:  user@host[:port] ───────────────────────────── */

static int parse_target(const char *arg, char *user, char *host, uint16_t *port)
{
    int i = 0;
    while(arg[i] && arg[i] != '@' && i < NAME_MAX-1){ user[i] = arg[i]; i++; }
    user[i] = 0;
    if(arg[i] != '@' || !user[0]) return 0;

    const char *h = arg + i + 1;
    int j = 0;
    while(h[j] && h[j] != ':' && j < 63){ host[j] = h[j]; j++; }
    host[j] = 0;
    if(!host[0]) return 0;

    *port = CHAT_PORT_DEFAULT;
    if(h[j] == ':'){
        uint32_t p = 0; const char *q = h + j + 1;
        if(!(*q >= '0' && *q <= '9')) return 0;
        while(*q >= '0' && *q <= '9'){ p = p*10 + (uint32_t)(*q - '0'); q++; }
        if(p == 0 || p > 65535) return 0;
        *port = (uint16_t)p;
    }
    return 1;
}

/* Read a line at the current cursor. echo=0 masks it for passwords. */
static int read_field(char *out, int outsz, int echo)
{
    int n = 0; out[0] = 0;
    for(;;){
        int k = keyboard_getchar();
        if(k < 0){ net_poll(); sleep_ms(5); continue; }
        if(k == 0x1B) return 0;                       /* ESC = cancel */
        if(k > 0xFF) continue;
        if(k == '\b'){
            if(n > 0){ out[--n] = 0; vga_puts("\b \b"); }
            continue;
        }
        if(k == '\n' || k == '\r'){ vga_putchar('\n'); return n > 0; }
        if(k >= 32 && k < 127 && n < outsz-1){
            out[n++] = (char)k; out[n] = 0;
            vga_putchar(echo ? (char)k : '*');
        }
    }
}

/* ── the client ──────────────────────────────────────────────────── */

void cmd_bootchat(const char *arg1)
{
    char user[NAME_MAX], host[64];
    uint16_t port = CHAT_PORT_DEFAULT;

    if(!net_ready()){
        vga_set_color(VGA_LIGHT_RED, VGA_BLACK);
        vga_puts("  Network is not up. Try: ifconfig dhcp\n");
        vga_set_color(VGA_WHITE, VGA_BLACK);
        return;
    }

    const char *target = (arg1 && arg1[0]) ? arg1 : g_last_target;
    if(!target || !target[0]){
        vga_puts("  Usage: chat <user>@<host>[:<port>]   (default port 6700)\n");
        vga_puts("  In chat: TAB for the sidebar, /help for commands\n");
        return;
    }
    if(!parse_target(target, user, host, &port)){
        vga_set_color(VGA_LIGHT_RED, VGA_BLACK);
        vga_puts("  Bad target. Expected <user>@<host>[:<port>]\n");
        vga_set_color(VGA_WHITE, VGA_BLACK);
        return;
    }
    strncpy(g_last_target, target, sizeof(g_last_target)-1);
    g_last_target[sizeof(g_last_target)-1] = 0;
    strncpy(g_nick, user, NAME_MAX-1); g_nick[NAME_MAX-1] = 0;

    char pass[64];
    vga_puts("  Password for "); vga_puts(user); vga_puts(": ");
    if(!read_field(pass, sizeof(pass), 0)){ vga_puts("  Cancelled.\n"); return; }
    vga_puts("  [L]ogin or [R]egister a new account? ");
    int mode = 0;
    for(;;){
        int k = keyboard_getchar();
        if(k < 0){ sleep_ms(5); continue; }
        if(k == 'l' || k == 'L'){ mode = 0; vga_puts("login\n");    break; }
        if(k == 'r' || k == 'R'){ mode = 1; vga_puts("register\n"); break; }
        if(k == 0x1B){ vga_puts("cancelled\n"); return; }
    }

    vga_puts("  Resolving "); vga_puts(host); vga_puts(" ...\n");
    uint32_t ip = dns_resolve(host);
    if(!ip){
        vga_set_color(VGA_LIGHT_RED, VGA_BLACK);
        /* dns_resolve() returns 0 both for "lookup failed" and for the
           address 0.0.0.0, so say what was tried rather than blaming DNS. */
        vga_puts("  Could not reach that address.\n");
        vga_puts("  From a QEMU guest the host machine is 10.0.2.2\n");
        vga_puts("  Names from /hosts.txt also work - see 'man chat'\n");
        vga_set_color(VGA_WHITE, VGA_BLACK);
        return;
    }

    vga_puts("  Connecting ...\n");
    int fd = tcp_connect(ip, port);
    if(fd < 0){
        vga_set_color(VGA_LIGHT_RED, VGA_BLACK);
        vga_puts(fd == -2 ? "  No free sockets.\n" : "  Connect failed.\n");
        vga_set_color(VGA_WHITE, VGA_BLACK);
        return;
    }

    sb_reset();
    g_authed = 0; g_server[0] = 0; g_channel[0] = 0; g_dmwith[0] = 0;
    g_nsrv = 0; g_ndm = 0; g_nitems = 0; g_sel = 0; g_sbtop = 0;
    g_focus_side = 0;
    items_rebuild();
    sb_add("-- connected, authenticating", VGA_LIGHT_CYAN);
    {
        char auth[160];
        strcpy(auth, mode ? "REGISTER " : "LOGIN ");
        strncat(auth, user, sizeof(auth)-strlen(auth)-1);
        strncat(auth, " ",  sizeof(auth)-strlen(auth)-1);
        strncat(auth, pass, sizeof(auth)-strlen(auth)-1);
        send_line(fd, auth);
        memset(pass, 0, sizeof(pass));   /* don't leave it on the stack */
    }

    char input[CHAT_INPUT]; int ilen = 0; input[0] = 0;
    static char rxline[CHAT_WIRE]; int rlen = 0;
    int running = 1, connected = 1;
    uint32_t last_draw = 0;

    vga_clear();
    ui_force_cursor_redraw();
    mouse_get_clicks();               /* flush any stale click edge */

    while(running){
        uint8_t rb[512];
        int n = tcp_recv(fd, rb, sizeof(rb), 15);
        if(n < 0 || (n == 0 && tcp_eof(fd))){
            connected = 0;
            sb_add("-- disconnected by server", VGA_LIGHT_RED);
            draw(host, input, connected);
            break;
        }
        for(int i = 0; i < n; i++){
            char c = (char)rb[i];
            if(c == '\n'){
                rxline[rlen] = 0;
                if(!strcmp(rxline, "PING")) send_line(fd, "PONG");
                else { utf8_to_cp437(rxline, CHAT_WIRE); handle_line(fd, rxline); }
                rlen = 0;
            } else if(c != '\r' && rlen < CHAT_WIRE-1){
                rxline[rlen++] = c;
            }
        }

        /* ── mouse: click anywhere in the sidebar to open that row ── */
        if(mouse_is_ready() && mouse_get_clicks()){
            int px, py, pb;
            mouse_get(&px, &py, &pb);
            if(px < SIDE_W-1 && py >= 1 && py <= vga_rows()-3){
                int idx = g_sbtop + (py - 1);
                if(item_selectable(idx)){
                    g_sel = idx;
                    activate(fd, idx);
                    g_focus_side = 0;     /* carry on typing after a click */
                }
            } else if(py == vga_rows()-1){
                g_focus_side = 0;         /* click the input line to type */
            }
        }

        /* ── keyboard ── */
        int k;
        while((k = keyboard_getchar()) >= 0){
            if(k == 0x1B){ running = 0; break; }
            if(k == '\t'){ g_focus_side = !g_focus_side; continue; }

            if(k > 0xFF){
                int ext = k & 0xFF;
                if(g_focus_side){
                    if(ext == 0x48) sel_step(-1);            /* up   */
                    else if(ext == 0x50) sel_step(+1);       /* down */
                    else if(ext == 0x49) for(int z=0;z<5;z++) sel_step(-1);
                    else if(ext == 0x51) for(int z=0;z<5;z++) sel_step(+1);
                } else {
                    if(ext == 0x49){ if(g_view < g_count) g_view += 5; }
                    else if(ext == 0x51){ g_view -= 5; if(g_view < 0) g_view = 0; }
                    else if(ext == 0x4F){ g_view = 0; }
                }
                continue;
            }

            if(g_focus_side){
                if(k == '\n' || k == '\r'){ activate(fd, g_sel); g_focus_side = 0; }
                continue;                 /* the sidebar eats plain keys */
            }

            if(k == '\b'){ if(ilen > 0) input[--ilen] = 0; continue; }
            if(k == '\n' || k == '\r'){
                if(!ilen) continue;
                if(!strcmp(input, "/quit")){ running = 0; break; }
                else if(!strcmp(input, "/help")){
                    sb_add("-- TAB sidebar, arrows move, ENTER opens", VGA_DARK_GREY);
                    sb_add("-- click the sidebar with the mouse too", VGA_DARK_GREY);
                    sb_add("-- /create <s> /joinsrv <s> /mkchan <c>", VGA_DARK_GREY);
                    sb_add("-- /dm <user> /who /quit", VGA_DARK_GREY);
                }
                else if(!strcmp(input, "/servers")) send_line(fd, "SERVERS");
                else if(!strcmp(input, "/dms"))     send_line(fd, "DMLIST");
                else if(!strcmp(input, "/who"))     send_line(fd, "WHO");
                else if(!strncmp(input, "/create ", 8)){
                    char c[96]; strcpy(c, "CREATE ");
                    strncat(c, input+8, sizeof(c)-strlen(c)-1); send_line(fd, c);
                }
                else if(!strncmp(input, "/joinsrv ", 9)){
                    char c[96]; strcpy(c, "JOINSRV ");
                    strncat(c, input+9, sizeof(c)-strlen(c)-1); send_line(fd, c);
                }
                else if(!strncmp(input, "/channels", 9)){
                    char c[96]; strcpy(c, "CHANNELS ");
                    const char *a = input[9] == ' ' ? input+10 : g_server;
                    strncat(c, a, sizeof(c)-strlen(c)-1); send_line(fd, c);
                }
                else if(!strncmp(input, "/mkchan ", 8)){
                    if(!g_server[0]) sb_add("-- join a server first", VGA_LIGHT_RED);
                    else {
                        char c[96]; strcpy(c, "MKCHAN ");
                        strncat(c, g_server, sizeof(c)-strlen(c)-1);
                        strncat(c, " ", sizeof(c)-strlen(c)-1);
                        strncat(c, input+8, sizeof(c)-strlen(c)-1);
                        send_line(fd, c);
                    }
                }
                else if(!strncmp(input, "/join ", 6)){
                    char c[96]; strcpy(c, "JOIN ");
                    strncat(c, input+6, sizeof(c)-strlen(c)-1); send_line(fd, c);
                }
                else if(!strncmp(input, "/j ", 3)){
                    if(!g_server[0]) sb_add("-- join a server first", VGA_LIGHT_RED);
                    else {
                        char c[96]; strcpy(c, "JOIN ");
                        strncat(c, g_server, sizeof(c)-strlen(c)-1);
                        strncat(c, " ", sizeof(c)-strlen(c)-1);
                        strncat(c, input+3, sizeof(c)-strlen(c)-1);
                        send_line(fd, c);
                    }
                }
                else if(!strncmp(input, "/dm ", 4)){
                    char who[NAME_MAX];
                    field((char*)input+4, who, sizeof(who));
                    strncpy(g_dmwith, who, NAME_MAX-1); g_dmwith[NAME_MAX-1] = 0;
                    g_channel[0] = 0;
                    dm_add(g_dmwith); items_rebuild(); clear_unread_here();
                    sb_reset();
                    char c[96]; strcpy(c, "DMHIST ");
                    strncat(c, g_dmwith, sizeof(c)-strlen(c)-1); send_line(fd, c);
                }
                else if(input[0] == '/'){
                    sb_add("-- unknown command; /help lists them", VGA_DARK_GREY);
                }
                else {
                    if(!g_authed){ sb_add("-- not signed in yet", VGA_LIGHT_RED); }
                    else if(!g_dmwith[0] && !g_channel[0]){
                        sb_add("-- pick a channel in the sidebar (TAB)", VGA_LIGHT_RED);
                    } else {
                        char wire[CHAT_INPUT * 4];
                        expand_shortcodes(input, wire, sizeof(wire));
                        char out[CHAT_INPUT * 4 + 32];
                        if(g_dmwith[0]){
                            strcpy(out, "DM ");
                            strncat(out, g_dmwith, sizeof(out)-strlen(out)-1);
                            strncat(out, " ", sizeof(out)-strlen(out)-1);
                        } else {
                            strcpy(out, "SAY ");
                        }
                        strncat(out, wire, sizeof(out)-strlen(out)-1);
                        if(send_line(fd, out) < 0){
                            connected = 0;
                            sb_add("-- send failed", VGA_LIGHT_RED);
                            running = 0;
                        }
                    }
                }
                ilen = 0; input[0] = 0; g_view = 0;
                continue;
            }
            if(k >= 32 && k < 127 && ilen < CHAT_INPUT-1){
                input[ilen++] = (char)k; input[ilen] = 0;
            }
        }

        /* Redraw at ~20 Hz rather than per keystroke — a full frame is a
           screen of VGA writes and doing that per key makes typing feel
           heavy on TCG.  The pointer is lifted off the frame first and put
           back after, so it is never baked into the cells underneath it. */
        uint32_t now = get_ticks();
        if((uint32_t)(now - last_draw) >= 5){
            ui_erase_cursor();
            draw(host, input, connected);
            if(mouse_is_ready()) ui_draw_cursor();
            last_draw = now;
        }
        net_poll();
    }

    if(connected) send_line(fd, "QUIT");
    tcp_close(fd);

    ui_erase_cursor();
    vga_clear();
    vga_flush();
    vga_set_cursor(0, 0);
    vga_set_color(VGA_WHITE, VGA_BLACK);
    vga_puts("  Left BOOT Chat.\n");
    notif_push("BOOT Chat session ended");
    toast_info("Disconnected from BOOT Chat");
}
