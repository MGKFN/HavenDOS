#pragma once
/* ============================================================
   HavenDOS version — SINGLE SOURCE OF TRUTH
   ============================================================

   Before v0.7.18 the version was typed out by hand in ~50 places and they
   had drifted apart: a v0.7.17 build shipped screens reading v0.7.0, v0.7.4
   and v0.7.11, the ISO's GRUB menu said v0.7.11, isodir/version.txt said
   v0.7.11, and the installer wrote a grub.cfg whose menu entries said
   v0.7.4.

   That was not only cosmetic.  fs/update.c carried

       #define HAVENDOS_VERSION "0.5.9.14"

   and fed it to ver_cmp() against the version read off the update ISO.  So
   "same version already installed" could never fire, and an OLDER ISO
   compared as NEWER and was applied as an upgrade with no warning.

   Everything now derives from the three numbers below.  tools/make_version.py
   regenerates isodir/version.txt and the ISO grub.cfg from this file at build
   time, so a release is a one-line change here.

   HAVENDOS_VER_NUM  — bare, for comparison (update.c, manifests)
   HAVENDOS_VER      — display form with a leading v, what the user sees
   HAVENDOS_FULL     — name and display version together

   No version literal is written anywhere in this comment on purpose: the
   Makefile banner used to scrape HAVENDOS_VER_NUM with an unanchored sed
   and printed EVERY match, so a literal here made the banner report the
   previous release beside the new one.  tools/make_version.py --check now
   fails the build if a version literal reappears outside this file.
*/

#define HAVENDOS_VER_MAJOR  0
#define HAVENDOS_VER_MINOR  8
#define HAVENDOS_VER_PATCH  3

/* VER_NUM stays plain dotted numbers because fs/update.c compares it with
   ver_cmp() to decide whether an ISO is newer.  The channel and codename are
   separate macros so they can appear on screen without ever reaching that
   comparison -- a version string with a word in it would make every update
   check unpredictable. */
#define HAVENDOS_VER_NUM    "0.8.3.1"
#define HAVENDOS_VER        "v" HAVENDOS_VER_NUM
#define HAVENDOS_NAME       "HavenDOS"
#define HAVENDOS_CHANNEL    "Beta"
#define HAVENDOS_CODENAME   "Lodger"
#define HAVENDOS_FULL       HAVENDOS_NAME " " HAVENDOS_VER " " HAVENDOS_CHANNEL \
                            " \"" HAVENDOS_CODENAME "\""
#define HAVENDOS_VENDOR     "TechHaven Studios"
