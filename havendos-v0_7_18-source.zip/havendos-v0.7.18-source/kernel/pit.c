#include "../include/io.h"
#include "../include/types.h"

/* ================================================================
   PIT - Programmable Interval Timer
   BOOT OS uses two timing sources:
   1. IRQ0-based ticks (when interrupts work)
   2. Direct PIT counter polling (always works, even on UTM TCG)
   ================================================================ */

static uint16_t last_pit_val = 0;

/* PIT runs at 1193182 Hz always */
#define PIT_BASE_HZ  1193182UL
#define PIT_HZ       100
#define PIT_DIVISOR  (PIT_BASE_HZ / PIT_HZ)  /* ~11932 */

/* v0.7.5: pit_us() below reconstructs elapsed time from the counter's
   wrap point, so it MUST know the divisor that was actually programmed.
   It previously hardcoded PIT_DIVISOR while pit_init() accepted any hz —
   any call other than pit_init(100) silently corrupted every timing
   calculation in the OS. */
static uint32_t g_pit_divisor = PIT_DIVISOR;

void pit_init(uint32_t hz){
    uint32_t div = PIT_BASE_HZ / hz;
    if(div == 0 || div > 65535) div = 65536;   /* 0 means full 16-bit range */
    g_pit_divisor = div;
    outb(0x43, 0x36);           /* channel 0, lo/hi, mode 3, binary */
    outb(0x40, (uint8_t)(div & 0xFF));
    outb(0x40, (uint8_t)((div >> 8) & 0xFF));
    last_pit_val = (uint16_t)(div & 0xFFFF);
}

/* ----------------------------------------------------------------
   Read current PIT channel 0 counter (counts DOWN from divisor)
   Returns a value 0..PIT_DIVISOR
   ---------------------------------------------------------------- */
static uint16_t pit_read_counter(void){
    outb(0x43, 0x00);           /* latch channel 0 */
    uint16_t lo = inb(0x40);
    uint16_t hi = inb(0x40);
    return (hi << 8) | lo;
}

/* ----------------------------------------------------------------
   Monotonic microsecond counter using PIT polling
   Works even when IRQ0 never fires (UTM TCG mode)
   ---------------------------------------------------------------- */
static volatile uint32_t pit_overflows = 0;  /* incremented by IRQ0 */
static uint32_t us_accumulator = 0;
static uint32_t us_frac        = 0;   /* 16.16 carry — see pit_us() */

/* Called by IRQ0 when it fires (bonus accuracy if IRQs work) */
void pit_tick(void){ pit_overflows++; }

/* Get microseconds elapsed since boot - pure polling, no IRQ needed */
static uint32_t pit_us(void){
    uint16_t cur = pit_read_counter();
    /* PIT counts down - if cur > last, it wrapped */
    uint16_t elapsed;
    if(cur <= last_pit_val){
        elapsed = last_pit_val - cur;
    } else {
        elapsed = (uint16_t)((g_pit_divisor - cur) + last_pit_val);
    }
    last_pit_val = cur;

    /* v0.7.12 FIX — the old line was:
     *     us_accumulator += (uint32_t)elapsed * 1000000UL / PIT_BASE_HZ;
     *
     * Two separate defects.
     *
     * 1. TRUNCATION THAT DESTROYED TIME.  One PIT tick is 0.838 us, so for
     *    elapsed == 1 the expression evaluates to 1000000/1193182 == 0.  The
     *    tick was consumed (last_pit_val had already advanced) but contributed
     *    nothing.  pit_read_counter() costs three port accesses, which is on
     *    the order of one to four PIT ticks, so in the tight sleep_ms() poll
     *    loop this threw away a large fraction of every interval.  sleep_ms()
     *    therefore slept LONGER than asked — unboundedly so on a fast host —
     *    and get_ticks() ran slow, which drags every network timeout, the TCP
     *    retransmission timer and the DNS cache with it.
     *
     * 2. OVERFLOW.  elapsed can be as large as g_pit_divisor (11932 at 100 Hz)
     *    after a wrap, and 11932 * 1000000 is 1.19e10 — it does not fit in the
     *    uint32_t the multiplication is performed in.
     *
     * Both are fixed by carrying the remainder in 16.16 fixed point.
     * 1000000/1193182 * 65536 = 54927 (relative error ~1e-6), and the largest
     * possible product 65536 * 54927 = 3.60e9 still fits in a uint32_t. */
    {
        uint32_t acc = (uint32_t)elapsed * 54927u + us_frac;
        us_accumulator += acc >> 16;
        us_frac         = acc & 0xFFFFu;
    }
    return us_accumulator;
}

/* ----------------------------------------------------------------
   get_ticks() - returns 10ms ticks (100Hz equivalent)
   Uses PIT polling so it works regardless of IRQ state
   ---------------------------------------------------------------- */
uint32_t get_ticks(void){
    return pit_us() / 10000;   /* 10000 us = 10ms = one 100Hz tick */
}

/* ----------------------------------------------------------------
   sleep_ms() - accurate busy-wait using PIT polling
   ---------------------------------------------------------------- */
void sleep_ms(uint32_t ms){
    if(ms == 0) return;
    uint32_t start = pit_us();
    uint32_t target = ms * 1000;   /* convert to microseconds */
    while((pit_us() - start) < target){
        __asm__ volatile("pause");
    }
}
