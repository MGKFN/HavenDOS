#!/usr/bin/env python3
"""make_version.py — propagate include/version.h into the ISO tree.

    python3 tools/make_version.py include/version.h isodir

Rewrites isodir/version.txt and the menu-entry titles in
isodir/boot/grub/grub.cfg so the boot menu, the version file the updater
reads off the ISO, and the running kernel can never disagree again.

Before v0.7.18 all three were typed by hand and had drifted: a v0.7.17 build
shipped a GRUB menu reading v0.7.11 and a version.txt reading v0.7.11, while
fs/update.c believed it was running 0.5.9.14.
"""
import re
import sys
import os


def read_version(header):
    src = open(header, encoding="utf-8").read()
    m = re.search(r'#define\s+HAVENDOS_VER_NUM\s+"([^"]+)"', src)
    if not m:
        sys.exit("make_version.py: HAVENDOS_VER_NUM not found in %s" % header)
    return m.group(1)


def main():
    if len(sys.argv) != 3:
        sys.exit("usage: make_version.py <include/version.h> <isodir>")
    header, isodir = sys.argv[1], sys.argv[2]
    num = read_version(header)
    disp = "v" + num

    vt = os.path.join(isodir, "version.txt")
    with open(vt, "w", encoding="utf-8") as f:
        f.write(disp + "\n")
    print("make_version: %s -> %s" % (vt, disp))

    cfg = os.path.join(isodir, "boot", "grub", "grub.cfg")
    if os.path.exists(cfg):
        src = open(cfg, encoding="utf-8").read()
        # Only rewrite the version token inside menuentry titles.
        new, n = re.subn(r'v0\.[0-9]+\.[0-9]+(?:\.[0-9]+)*', disp, src)
        if new != src:
            open(cfg, "w", encoding="utf-8").write(new)
        print("make_version: %s -> %s (%d titles)" % (cfg, disp, n))


if __name__ == "__main__":
    main()
