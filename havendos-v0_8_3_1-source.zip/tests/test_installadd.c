/* ================================================================
   tests/test_installadd.c -- "will I lose Windows?", as a test
   ================================================================
   The whole additive install, run against a disk shaped like a 512 GB
   Windows 11 laptop with a shrunk partition, with one claim checked
   above all others:

       EVERY SECTOR on the disk that is not inside the new partition
       and not on the EFI System Partition is BYTE-IDENTICAL after the
       install, except four, whose LBAs the installer printed BEFORE
       it wrote anything.

   Not "the partitions still look right". Byte-identical, every sector
   the disk model has ever been given, compared one at a time.

   The dry run is checked the same way and more strictly: zero writes.
   Not "no writes we care about" -- the disk model counts every call.

   Headers: -Iinclude makes <string.h> resolve to the kernel's own, so
   this file includes the kernel one (via the fs/*.c it pulls in) and
   declares nothing from the host's. tests/test_gptwrite.c does the
   opposite and both say why.
   ================================================================ */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

/* The kernel image the installer would copy. Supplied here so the suite
   does not need a GRUB build; 300 KB is enough to span many clusters and
   exercise the chaining, and it starts with a real ELF magic because
   havendos_install_image_available() checks for one. */
#define FAKE_KERNEL_SZ  307200u
static uint8_t  g_kernel[FAKE_KERNEL_SZ];
static uint32_t kernel_elf_size = FAKE_KERNEL_SZ;
#define kernel_elf_data g_kernel
#define INSTALL_KERNEL_PROVIDED 1

/* The UEFI loader esp.c would write. Same reasoning; it has to be
   PE32+-shaped because fs/esp.c refuses anything that is not. */
#define FAKE_LOADER_SZ  811008u
static uint8_t  g_loader[FAKE_LOADER_SZ];
static uint32_t g_loader_sz = FAKE_LOADER_SZ;
#define ESP_LOADER_PROVIDED 1
#define grub_efi_img       g_loader
#define grub_efi_img_size  g_loader_sz

/* The disk model's sizes. A whole install touches far more sectors than
   adding one partition does: two copies of an 811 KB loader onto the ESP,
   a 256-sector FAT written twice, a 300 KB kernel, plus the FAT32 ESP that
   mkfs.vfat built. */
#define MAXSEC   98304
#define MAXWLOG  65536

#include "types.h"
#include "gpt.h"
#include "gpt_write.h"
#include "fat16fmt.h"

/* ── scoreboard ─────────────────────────────────────────────────────── */
static int total=0, fails=0;
static void head(const char *s){ printf("\n  %s\n", s); }
static void ck(const char *what, int ok, long got){
    total++;
    if(!ok){ fails++; printf("    FAIL %-58s got %ld\n", what, got); }
}

#include "../fs/gpt.c"
#include "../fs/gpt_write.c"
#include "gptdisk.inc"
#include "../fs/fat16fmt.c"

/* ── the installer's disk API, onto the model above ─────────────────── */
static int g_ro = 0;            /* pretend there is no write path       */
static int g_live = 0;          /* pretend this is a live session       */
/* Two fault modes, because they catch different bugs.

   g_wfail_at: every write from the Nth onward refuses -- a disk that has
   stopped accepting writes. Good for "does the installer stop", bad at
   pinpointing WHICH unchecked write let it carry on, because the next
   checked write fails too and reports the same error.

   g_wfail_once: exactly one write refuses and everything after it works --
   a single bad sector. This is the mode that catches an ignored return
   value, because the install then runs to the end, reports success, and
   has a truncated kernel on the disk. */
static int g_wfail_at   = -1;
static int g_wfail_once = -1;
static int g_wcount = 0;

/* THE MODEL DISK IS INDEX 1, NOT 0, on purpose.

   Disk 0 exists in the table and every access to it fails. Anything in the
   installer that reaches for disk 0 instead of the disk it was handed --
   and there was such a thing: esp_install() used to take the disk out of
   the report struct, which a caller that zeroed the struct left as 0 --
   fails here instead of silently working because the only disk happened to
   be the right one. */
#define MODEL_DISK 1

int inst_disk_count(void){ return 2; }
uint64_t inst_disk_sectors(int i){
    return i == MODEL_DISK ? g_disk_sectors : 0;
}
int inst_disk_read(int i, uint64_t lba, uint8_t *b){
    if(i != MODEL_DISK) return 0;
    return d_read(0, lba, b) == 0;
}
int inst_disk_write(int i, uint64_t lba, const uint8_t *b){
    if(i != MODEL_DISK) return 0;
    if(g_ro) return 0;
    if(g_wfail_at >= 0 && g_wcount >= g_wfail_at){ g_wcount++; return 0; }
    if(g_wfail_once >= 0 && g_wcount == g_wfail_once){ g_wcount++; return 0; }
    g_wcount++;
    return d_write(0, lba, b) == 0;
}
int inst_disk_is_readonly(int i){ return i == MODEL_DISK ? g_ro : 1; }
int boot_is_live(void){ return g_live; }
int vfs_exists(const char *p){ (void)p; return 0; }

/* 0 on success, like fs/gpt.c wants; d_read already uses that convention,
   so this passes it through rather than inverting it. */
static int gptrd(void *ctx, uint64_t lba, void *buf){
    (void)ctx; return d_read(0, lba, buf);
}
int inst_disk_has_gpt(int i){
    return i == MODEL_DISK && gpt_present(gptrd, 0);
}
int inst_disk_gpt_parts(int i, gpt_part_t *out, int max){
    if(i != MODEL_DISK) return 0;
    return gpt_scan(gptrd, 0, out, max);
}

/* fs/fat32.c's own device back ends. It can mount through a supplied
   read/write pair -- which is what everything here uses -- but it still
   references the two built-in ones, so they have to resolve. They are
   never called: every mount in this suite passes functions explicitly. */
int virtio_blk_read (uint64_t l, uint8_t *b){ (void)l;(void)b; return 0; }
int virtio_blk_write(uint64_t l, const uint8_t *b){ (void)l;(void)b; return 0; }
int virtio_blk_ready(void){ return 0; }
int ata_detected(void){ return 0; }
int ata_lba48(void){ return 0; }
int ata_read_sector   (uint32_t l, uint8_t *b){ (void)l;(void)b; return 0; }
int ata_write_sector  (uint32_t l, const uint8_t *b){ (void)l;(void)b; return 0; }
int ata_read_sector48 (uint32_t l, uint8_t *b){ (void)l;(void)b; return 0; }
int ata_write_sector48(uint32_t l, const uint8_t *b){ (void)l;(void)b; return 0; }
void ata_init(void){}
uint32_t ata_sectors(void){ return 0; }
int virtio_scan_drives(void){ return 0; }
uint64_t virtio_drive_sectors(int i){ (void)i; return 0; }
uint8_t virtio_drive_bus(int i){ (void)i; return 0; }
uint8_t virtio_drive_dev(int i){ (void)i; return 0; }
int virtio_drive_read(int i, uint64_t l, uint8_t *b){ (void)i;(void)l;(void)b; return 0; }
int virtio_drive_write(int i, uint64_t l, const uint8_t *b){ (void)i;(void)l;(void)b; return 0; }

/* the PMM, for esp.c's backup buffer */
void *pmm_alloc_contig(uint32_t n){ return malloc((size_t)n * 4096); }
void  pmm_free_contig(void *p, uint32_t n){ (void)n; free(p); }

#include "../fs/fat32.c"
#define ESP_NO_KERNEL_GLUE 1
#include "../fs/esp.c"

/* esp.c's kernel glue is excluded above because it mounts through the
   installer's disk table; these are the two entry points install.c calls,
   wired to the model instead. Mirrors fs/esp.c's own mount_esp(). */
static int g_espdisk = 0;
static int esp_rd2(void *ctx, uint64_t lba, uint8_t *b){
    (void)ctx; return d_read(0, lba, b) == 0;
}
static int esp_wr2(void *ctx, uint64_t lba, const uint8_t *b){
    (void)ctx; return inst_disk_write(g_espdisk, lba, b);
}
static int mount_the_esp(int disk, esp_report_t *rep, int want_write)
{
    gpt_part_t p[GPT_MAX_PARTS];
    int n, i;
    if(!rep) return ESP_E_PARAM;
    memset(rep, 0, sizeof *rep);
    rep->disk = disk;
    g_espdisk = disk;
    if(!inst_disk_has_gpt(disk)) return ESP_E_NOGPT;
    n = inst_disk_gpt_parts(disk, p, GPT_MAX_PARTS);
    if(n <= 0) return ESP_E_NOGPT;
    for(i = 0; i < n; i++){
        if(!p[i].is_esp) continue;
        if(!fat32_mount_dev(esp_rd2, want_write ? esp_wr2 : 0, 0, p[i].first_lba))
            return ESP_E_MOUNT;
        rep->found = 1;
        rep->lba = p[i].first_lba;
        rep->sectors = p[i].last_lba - p[i].first_lba + 1;
        return ESP_OK;
    }
    return ESP_E_NOESP;
}
int esp_find(int disk, esp_report_t *rep){
    int r = mount_the_esp(disk, rep, 0);
    if(r != ESP_OK) return r;
    r = survey(rep);
    fat32_unmount();
    return r;
}
int esp_install(int disk, esp_report_t *rep, int part, int dry){
    int r;
    if(!rep) return ESP_E_PARAM;
    if(!dry && g_ro) return ESP_E_READONLY;
    r = mount_the_esp(disk, rep, dry ? 0 : 1);
    if(r != ESP_OK) return r;
    r = esp_install_mounted(rep, part, dry);
    fat32_unmount();
    return r;
}

#include "install_add.h"
#include "../fs/install.c"

/* ── a real FAT32 ESP inside the model disk ─────────────────────────── */
/* The gptdisk fixture declares where the ESP is but puts no filesystem in
   it. esp.c needs a mountable FAT32 with Windows' files on it, so one is
   formatted here, with mkfs.vfat and mcopy -- outside tools, so the thing
   under test is not also the thing that built the fixture. */
static int build_esp_into_model(uint64_t first_lba, uint64_t sectors)
{
    char cmd[640];
    FILE *f;
    uint64_t i;
    static uint8_t sec[512];
    uint64_t n = sectors > 204800u ? 204800u : sectors;   /* cap at 100 MB */

    snprintf(cmd, sizeof cmd,
             "rm -f /tmp/hd_ia_esp.img && "
             "dd if=/dev/zero of=/tmp/hd_ia_esp.img bs=512 count=%llu "
             "status=none && mkfs.vfat -F 32 -n EFI /tmp/hd_ia_esp.img "
             "> /dev/null 2>&1",
             (unsigned long long)n);
    if(system(cmd)) return 0;

    /* Windows' own files, so there is something to not break. */
    if(system("mmd -i /tmp/hd_ia_esp.img ::/EFI > /dev/null 2>&1")) return 0;
    if(system("mmd -i /tmp/hd_ia_esp.img ::/EFI/Microsoft > /dev/null 2>&1")) return 0;
    if(system("mmd -i /tmp/hd_ia_esp.img ::/EFI/Microsoft/Boot > /dev/null 2>&1")) return 0;
    if(system("mmd -i /tmp/hd_ia_esp.img ::/EFI/BOOT > /dev/null 2>&1")) return 0;
    if(system("head -c 1800000 /dev/urandom > /tmp/hd_ia_bootmgfw.bin")) return 0;
    if(system("head -c 262144 /dev/urandom > /tmp/hd_ia_bcd.bin")) return 0;
    if(system("mcopy -i /tmp/hd_ia_esp.img /tmp/hd_ia_bootmgfw.bin "
              "::/EFI/Microsoft/Boot/bootmgfw.efi > /dev/null 2>&1")) return 0;
    if(system("mcopy -i /tmp/hd_ia_esp.img /tmp/hd_ia_bcd.bin "
              "::/EFI/Microsoft/Boot/BCD > /dev/null 2>&1")) return 0;

    f = fopen("/tmp/hd_ia_esp.img", "rb");
    if(!f) return 0;
    for(i = 0; i < n; i++){
        if(fread(sec, 1, 512, f) != 512) break;
        {   /* only non-zero sectors, to keep the sparse model small */
            int nz = 0, k;
            for(k = 0; k < 512; k++) if(sec[k]){ nz = 1; break; }
            if(!nz) continue;
        }
        if(d_write(0, first_lba + i, sec) != 0){ fclose(f); return 0; }
    }
    fclose(f);
    return 1;
}

/* mtools' opinion of a file inside the ESP, read back out of the model. */
static int esp_file_matches(uint64_t first_lba, const char *path,
                            const char *hostfile)
{
    char cmd[640];
    FILE *f;
    uint64_t i;
    static uint8_t sec[512];
    uint64_t n = 204800u;

    f = fopen("/tmp/hd_ia_check.img", "wb");
    if(!f) return 0;
    for(i = 0; i < n; i++){
        if(d_read(0, first_lba + i, sec) != 0) memset(sec, 0, 512);
        if(fwrite(sec, 1, 512, f) != 512){ fclose(f); return 0; }
    }
    fclose(f);

    snprintf(cmd, sizeof cmd,
             "mcopy -n -i /tmp/hd_ia_check.img %s /tmp/hd_ia_out.bin "
             "> /dev/null 2>&1 && cmp -s /tmp/hd_ia_out.bin %s",
             path, hostfile);
    return system(cmd) == 0;
}
/* esp_file_matches() above leaves /tmp/hd_ia_check.img holding the ESP as
   it currently stands on the model disk, so this runs straight after one
   of those and checks the filesystem the install just wrote into. */
static int esp_fsck_clean(void)
{
    return system("fsck.vfat -n /tmp/hd_ia_check.img > /dev/null 2>&1") == 0;
}

/* Rebuild the model's ESP filesystem after a build_disk*. The fixture puts
   a partition table on the disk but no filesystem inside the EFI System
   Partition, and fs/esp.c needs a mountable FAT32 with Windows' files on
   it. Returns the ESP's extent as well, which several sections need. */
static int reset_esp(uint64_t *lo, uint64_t *hi)
{
    gpt_part_t p[GPT_MAX_PARTS];
    int n = inst_disk_gpt_parts(MODEL_DISK, p, GPT_MAX_PARTS), k;
    if(lo) *lo = 0;
    if(hi) *hi = 0;
    for(k = 0; k < (n < 0 ? 0 : n); k++) if(p[k].is_esp){
        if(lo) *lo = p[k].first_lba;
        if(hi) *hi = p[k].last_lba;
        return build_esp_into_model(p[k].first_lba,
                                    p[k].last_lba - p[k].first_lba + 1);
    }
    return 0;
}

/* ── the comparison that matters ────────────────────────────────────── */
/* Every sector the model holds, excluding a range and an allowed list. */
static int identical_outside(uint64_t lo, uint64_t hi,
                             uint64_t esp_lo, uint64_t esp_hi,
                             const uint64_t *allowed, int n_allowed,
                             uint64_t *first_bad)
{
    int bad = 0, i, j;
    for(i = 0; i < g_ndsec; i++){
        uint64_t lba = g_dsec[i].lba;
        int skip = 0;
        if(lba >= lo && lba <= hi) continue;
        if(lba >= esp_lo && lba <= esp_hi) continue;
        for(j = 0; j < n_allowed; j++) if(allowed[j] == lba){ skip = 1; break; }
        if(skip) continue;
        /* find it in the snapshot */
        {
            int found = -1;
            for(j = 0; j < g_nsnap; j++)
                if(g_snap[j].lba == lba){ found = j; break; }
            if(found < 0){
                if(!bad && first_bad) *first_bad = lba;
                bad++;                      /* a sector that did not exist */
                continue;
            }
            if(memcmp(g_snap[found].b, g_dsec[i].b, 512) != 0){
                if(!bad && first_bad) *first_bad = lba;
                bad++;
            }
        }
    }
    return bad;
}

int main(void)
{
    inst_add_t rep;
    unsigned i;

    printf("The additive install, against a Windows-shaped 512 GB disk\n");
    printf("==========================================================\n");

    for(i = 0; i < FAKE_KERNEL_SZ; i++)
        g_kernel[i] = (uint8_t)((i * 11u + (i >> 8) * 7u) & 0xFF);
    g_kernel[0] = 0x7F; g_kernel[1] = 'E'; g_kernel[2] = 'L'; g_kernel[3] = 'F';

    for(i = 0; i < FAKE_LOADER_SZ; i++)
        g_loader[i] = (uint8_t)((i * 7u + (i >> 9) * 13u) & 0xFF);
    g_loader[0] = 'M'; g_loader[1] = 'Z';
    g_loader[0x3C] = 0x80; g_loader[0x3D] = 0; g_loader[0x3E] = 0; g_loader[0x3F] = 0;
    g_loader[0x80] = 'P'; g_loader[0x81] = 'E'; g_loader[0x82] = 0; g_loader[0x83] = 0;
    g_loader[0x84] = 0x64; g_loader[0x85] = 0x86;

    if(system("which mkfs.vfat mcopy mmd fsck.vfat > /dev/null 2>&1") != 0){
        printf("\n  mkfs.vfat/mtools/fsck.vfat are not installed. This suite\n"
               "  needs them: they are the outside opinion, and without one\n"
               "  the test is our own code agreeing with itself.\n");
        printf("\n0/0 passed\n");
        return 1;
    }

    head("the disk: 512 GB, Windows 11 layout, 1 GB shrunk free");
    build_disk(1024ull * 1024 * 1024 * 1024 / 512 / 2);   /* 512 GB */
    ck("the table verifies the way firmware checks it", table_verifies(), 0);
    ck("gpt_present agrees", inst_disk_has_gpt(MODEL_DISK), 0);
    ck("and there is free space in it",
       WIN_FREE_LAST > WIN_FREE_FIRST, 0);
    printf("      free space: LBA %llu..%llu (%llu MB)\n",
           (unsigned long long)WIN_FREE_FIRST,
           (unsigned long long)WIN_FREE_LAST,
           (unsigned long long)((WIN_FREE_LAST - WIN_FREE_FIRST + 1) / 2048));

    head("a real FAT32 EFI System Partition, built by mkfs.vfat");
    {
        gpt_part_t p[GPT_MAX_PARTS];
        int n = inst_disk_gpt_parts(MODEL_DISK, p, GPT_MAX_PARTS), k, found = 0;
        uint64_t elo = 0, esec = 0;
        n = n < 0 ? 0 : n;
        for(k = 0; k < n; k++) if(p[k].is_esp){
            elo = p[k].first_lba; esec = p[k].last_lba - p[k].first_lba + 1;
            found = 1; break;
        }
        ck("the layout has an ESP", found, 0);
        ck("mkfs.vfat and mtools populate it",
           found && build_esp_into_model(elo, esec), 0);
        ck("and Windows' boot manager is readable from it",
           esp_file_matches(elo, "::/EFI/Microsoft/Boot/bootmgfw.efi",
                            "/tmp/hd_ia_bootmgfw.bin"), 0);
    }

    head("THE DRY RUN WRITES NOTHING AT ALL");
    {
        int r;
        g_wcount = 0;
        g_logging = 1; g_nwlog = 0;
        g_live = 1;              /* a live session may still preview */
        r = havendos_install_additive(MODEL_DISK, 1, &rep, 0);
        g_logging = 0;
        g_live = 0;

        ck("the preview succeeds", r == INSTADD_OK, r);
        ck("ZERO sectors were written", g_nwlog == 0, g_nwlog);
        ck("and the disk API was never asked to write",
           g_wcount == 0, g_wcount);
        ck("a plan was formed", rep.plan_ok, 0);

        ck("it names four sectors outside the new partition",
           rep.n_outside == 4, rep.n_outside);
        printf("      would write, outside the partition: ");
        for(i = 0; i < (unsigned)rep.n_outside; i++)
            printf("%llu%s", (unsigned long long)rep.outside[i],
                   i + 1 < (unsigned)rep.n_outside ? ", " : "\n");

        ck("the partition starts on a 1 MB boundary",
           rep.part_first % INSTADD_ALIGN == 0,
           (long)(rep.part_first % INSTADD_ALIGN));
        ck("it sits inside the free space",
           rep.part_first >= WIN_FREE_FIRST
           && rep.part_last <= WIN_FREE_LAST, 0);
        /* last - first + 1 == sectors. Trivial, and it was missing: an
           off-by-one here gives the GPT entry a partition one sector
           longer than the volume formatted inside it, which overlaps
           whatever begins where the gap ends. */
        ck("first, last and the count agree with each other",
           rep.part_last - rep.part_first + 1 == rep.part_sectors,
           (long)(rep.part_last - rep.part_first + 1));
        ck("and the count is a whole number of megabytes",
           rep.part_sectors % INSTADD_ALIGN == 0,
           (long)(rep.part_sectors % INSTADD_ALIGN));
        ck("the geometry is a valid FAT16",
           rep.geom.clusters >= FAT16_MIN_CLUSTERS
           && rep.geom.clusters <= FAT16_MAX_CLUSTERS,
           (long)rep.geom.clusters);
        ck("and the volume can hold the kernel",
           rep.vol_need_bytes <= rep.vol_free_bytes, 0);
        ck("the ESP survey succeeded", rep.esp_rc == ESP_OK, rep.esp_rc);
        ck("it found Windows there",  rep.esp.has_microsoft, 0);
        printf("      partition: LBA %llu..%llu (%llu MB), "
               "%u sectors/cluster, %u clusters\n",
               (unsigned long long)rep.part_first,
               (unsigned long long)rep.part_last,
               (unsigned long long)(rep.part_sectors / 2048),
               rep.geom.sects_per_clust, rep.geom.clusters);
    }

    head("a live session may preview but may not write");
    {
        inst_add_t r2;
        int r;
        g_live = 1;
        g_wcount = 0; g_logging = 1; g_nwlog = 0;
        r = havendos_install_additive(MODEL_DISK, 0, &r2, 0);
        g_logging = 0;
        g_live = 0;
        ck("the real install is refused", r == INSTADD_E_LIVE, r);
        ck("and nothing was written", g_nwlog == 0, g_nwlog);
    }

    head("a disk with no write path is refused, not attempted");
    {
        inst_add_t r2;
        int r;
        g_ro = 1;
        g_wcount = 0; g_logging = 1; g_nwlog = 0;
        r = havendos_install_additive(MODEL_DISK, 0, &r2, 0);
        g_logging = 0;
        g_ro = 0;
        ck("refused", r == INSTADD_E_READONLY, r);
        ck("and nothing was written", g_nwlog == 0, g_nwlog);
    }

    head("THE CLAIM: the install, then every other sector byte for byte");
    {
        uint64_t allowed[4], first_bad = 0;
        uint64_t plo, phi, elo = rep.esp.lba, ehi;
        int r, n_out;
        gpt_part_t p[GPT_MAX_PARTS];
        int n, k;

        /* the ESP's extent, from the table rather than from the report */
        n = inst_disk_gpt_parts(MODEL_DISK, p, GPT_MAX_PARTS);
        ehi = elo;
        for(k = 0; k < (n < 0 ? 0 : n); k++) if(p[k].is_esp){
            elo = p[k].first_lba; ehi = p[k].last_lba; break;
        }

        snapshot();
        ck("snapshot taken of every sector the disk holds", g_nsnap > 0, g_nsnap);

        g_wcount = 0;
        g_logging = 1; g_nwlog = 0;     /* the log is how order is checked */
        r = havendos_install_additive(MODEL_DISK, 0, &rep, 0);
        g_logging = 0;
        ck("the install succeeds", r == INSTADD_OK, r);
        printf("      %d sectors written in all\n", g_nwlog);
        if(r != INSTADD_OK)
            printf("      %s\n", havendos_install_add_strerror(r));

        plo = rep.part_first; phi = rep.part_last;
        n_out = rep.n_outside;
        for(i = 0; i < (unsigned)n_out && i < 4; i++) allowed[i] = rep.outside[i];

        ck("exactly four sectors outside the partition were permitted",
           n_out == 4, n_out);

        {
            int bad = identical_outside(plo, phi, elo, ehi,
                                        allowed, n_out, &first_bad);
            ck("EVERY OTHER SECTOR ON THE DISK IS BYTE-IDENTICAL",
               bad == 0, bad);
            if(bad)
                printf("      first differing sector: LBA %llu\n",
                       (unsigned long long)first_bad);
        }

        ck("the table still verifies end to end", table_verifies(), 0);

        /* The type GUID is load-bearing, not decoration. Microsoft Basic
           Data would make Windows enumerate this partition, give it a
           drive letter, and -- on a filesystem it half-recognises -- offer
           to repair or reformat it. An unknown type GUID is left alone. */
        {
            uint8_t ent[512];
            uint64_t elba;
            uint32_t esz;
            uint8_t h[512];
            int k, same = 1;
            ck("read the primary header", d_read(0, 1, h) == 0, 0);
            elba = g64(h + 72);
            esz  = g32(h + 84);
            ck("read the entry sector holding the new partition",
               d_read(0, elba + (uint64_t)(rep.gpt_entry * esz) / 512, ent) == 0,
               0);
            {
                uint32_t off = (uint32_t)(rep.gpt_entry * esz) % 512u;
                /* Written out, not compared against ADD_TYPE_GUID: the
                   first version of this check referenced the constant it
                   was checking, so changing that constant changed the
                   expectation with it and the check could not fail. */
                static const char want_guid[17] = "HAVENDOS-PART-01";
                for(k = 0; k < 16; k++)
                    if(ent[off + k] != (uint8_t)want_guid[k]) same = 0;
                ck("its type GUID is the ASCII HAVENDOS-PART-01",
                   same, 0);
                {
                    /* and specifically NOT Microsoft Basic Data, which is
                       what makes Windows claim a partition */
                    static const uint8_t MSDATA[16] = {
                        0xA2,0xA0,0xD0,0xEB,0xE5,0xB9,0x33,0x44,
                        0x87,0xC0,0x68,0xB6,0xB7,0x26,0x99,0xC7 };
                    int msd = 1;
                    for(k = 0; k < 16; k++)
                        if(ent[off + k] != MSDATA[k]) msd = 0;
                    ck("which is not Microsoft Basic Data", !msd, 0);
                }
                ck("and its first LBA is the one that was reported",
                   g64(ent + off + 32) == rep.part_first, 0);
                ck("and its last LBA likewise",
                   g64(ent + off + 40) == rep.part_last, 0);
            }
        }

        /* and the four really are the four it said they would be */
        {
            int in_log = 0;
            /* bounded by the array as well as by the count: g_nwlog keeps
               counting after g_wlog stops recording */
            unsigned lim = (unsigned)g_nwlog;
            long last_part = -1, first_esp = -1;
            if(lim > MAXWLOG) lim = MAXWLOG;
            for(i = 0; i < lim; i++){
                uint64_t l = g_wlog[i];
                if(l >= plo && l <= phi){ last_part = (long)i; continue; }
                if(l >= elo && l <= ehi){
                    if(first_esp < 0) first_esp = (long)i;
                    continue;
                }
                in_log++;
            }
            ck("the write log holds nothing but the partition, the ESP "
               "and the four", in_log == 4, in_log);

            /* THE ORDER MATTERS AND IS NOT VISIBLE IN THE END STATE.
               The boot files go on the ESP last, so that until they do the
               machine boots exactly as it did before: there is a new
               partition with an operating system in it that nothing points
               at yet. Installed the other way round, a power cut between
               the two leaves the firmware chainloading an empty volume.
               Only the write log can tell the two apart. */
            ck("the partition is filled before the ESP is touched",
               last_part >= 0 && first_esp >= 0 && first_esp > last_part,
               first_esp);
        }
    }

    head("Windows is still bootable: its files, per mtools");
    {
        uint64_t elo = rep.esp.lba;
        ck("bootmgfw.efi is byte-identical",
           esp_file_matches(elo, "::/EFI/Microsoft/Boot/bootmgfw.efi",
                            "/tmp/hd_ia_bootmgfw.bin"), 0);
        ck("the BCD is byte-identical",
           esp_file_matches(elo, "::/EFI/Microsoft/Boot/BCD",
                            "/tmp/hd_ia_bcd.bin"), 0);
        ck("the EFI partition still fsck's clean", esp_fsck_clean(), 0);

        /* The first version of this was `... == 0 || 1`, which is true
           whatever happens -- a check that cannot fail, in the suite whose
           whole purpose is checks that can. Written out properly: the
           loader has to be there, at the right length, byte for byte. */
        {
            FILE *w = fopen("/tmp/hd_ia_loader.bin", "wb");
            if(w){ fwrite(g_loader, 1, FAKE_LOADER_SZ, w); fclose(w); }
        }
        ck("HavenDOS' loader is on it, byte-identical",
           esp_file_matches(elo, "::/EFI/HAVENDOS/grubx64.efi",
                            "/tmp/hd_ia_loader.bin"), 0);
        ck("and so is the removable-media fallback it also writes",
           esp_file_matches(elo, "::/EFI/BOOT/BOOTX64.EFI",
                            "/tmp/hd_ia_loader.bin"), 0);
        ck("the menu on the ESP offers Windows back",
           system("mcopy -n -i /tmp/hd_ia_check.img ::/EFI/HAVENDOS/grub.cfg "
                  "/tmp/hd_ia_espcfg.txt > /dev/null 2>&1") == 0
           && system("grep -q bootmgfw /tmp/hd_ia_espcfg.txt") == 0, 0);
        ck("and it is not the only entry",
           system("grep -q HavenDOS /tmp/hd_ia_espcfg.txt") == 0, 0);
    }

    head("the new partition holds a mountable volume with the kernel in it");
    {
        char cmd[512];
        FILE *f;
        uint64_t i2;
        static uint8_t sec[512];

        f = fopen("/tmp/hd_ia_part.img", "wb");
        ck("extract the new partition", f != NULL, 0);
        if(f){
            for(i2 = 0; i2 < rep.part_sectors; i2++){
                if(d_read(0, rep.part_first + i2, sec) != 0)
                    memset(sec, 0, 512);
                if(fwrite(sec, 1, 512, f) != 512) break;
            }
            fclose(f);
        }
        ck("fsck.vfat accepts the volume we created",
           system("fsck.vfat -n /tmp/hd_ia_part.img > /dev/null 2>&1") == 0, 0);
        ck("its label is HAVENDOS, which is what GRUB searches for",
           system("mlabel -i /tmp/hd_ia_part.img -s :: 2>/dev/null "
                  "| grep -q HAVENDOS") == 0, 0);
        snprintf(cmd, sizeof cmd,
                 "mcopy -n -i /tmp/hd_ia_part.img ::/boot/havendos.elf "
                 "/tmp/hd_ia_kout.bin > /dev/null 2>&1");
        ck("the kernel is there, readable by mtools", system(cmd) == 0, 0);
        {
            FILE *k = fopen("/tmp/hd_ia_kout.bin", "rb");
            long sz = 0;
            if(k){ fseek(k, 0, SEEK_END); sz = ftell(k); fclose(k); }
            ck("at the right length", sz == (long)FAKE_KERNEL_SZ, sz);
        }
        if(system("head -c 307200 /tmp/hd_ia_kernel.bin > /dev/null 2>&1")){}
        {
            FILE *w = fopen("/tmp/hd_ia_kernel.bin", "wb");
            if(w){ fwrite(g_kernel, 1, FAKE_KERNEL_SZ, w); fclose(w); }
        }
        ck("and byte-identical to what was asked for",
           system("cmp -s /tmp/hd_ia_kout.bin /tmp/hd_ia_kernel.bin") == 0, 0);
        ck("the menu is there too",
           system("mcopy -n -i /tmp/hd_ia_part.img ::/boot/grub/grub.cfg "
                  "/tmp/hd_ia_cfg.txt > /dev/null 2>&1") == 0, 0);
    }

    head("a second install finds no room and refuses without writing");
    {
        inst_add_t r2;
        int r;
        g_wcount = 0; g_logging = 1; g_nwlog = 0;
        r = havendos_install_additive(MODEL_DISK, 1, &r2, 0);
        g_logging = 0;
        /* The gap is gone -- it became the HavenDOS partition. So "no free
           space" is a TRUE answer, and it is the wrong one: it reads as
           though the disk has been damaged, and it sent someone looking
           for a fault in a machine that had just worked. The specific
           answer is the useful one. */
        ck("the preview says HavenDOS is already there",
           r == INSTADD_E_ALREADY, r);
        ck("not that the disk is full",
           r != INSTADD_E_NOSPACE && r != INSTADD_E_TOOSMALL, r);
        ck("and wrote nothing finding out", g_nwlog == 0, g_nwlog);
        ck("the existing partition is found by type GUID",
           havendos_find_existing(MODEL_DISK) >= 0,
           havendos_find_existing(MODEL_DISK));
        ck("a real install refuses for the same reason",
           havendos_install_additive(MODEL_DISK, 0, &r2, 0)
           == INSTADD_E_ALREADY, 0);
        ck("the message names the disk's state, not its capacity",
           havendos_install_add_strerror(INSTADD_E_ALREADY) != 0
           && havendos_install_add_shortstr(INSTADD_E_ALREADY) != 0, 0);
    }

    head("a disk with HavenDOS on it and room to spare is still refused");
    {
        /* Not a space question at all. Two partitions labelled HAVENDOS
           would make the boot menu's `search --label` pick whichever it
           found first, which is a machine that boots a different release
           depending on partition order. */
        inst_add_t r2;
        int r;
        uint64_t elo, ehi;
        build_disk_gap(1024ull * 1024 * 1024 * 1024 / 512 / 2, 128,
                       8ull * 1024 * 1024 * 1024 / 512);   /* 8 GB free */
        ck("rebuild with plenty of free space", reset_esp(&elo, &ehi), 0);
        ck("the first install succeeds",
           havendos_install_additive(MODEL_DISK, 0, &r2, 0) == INSTADD_OK, 0);
        ck("there is still free space afterwards",
           r2.gap_sectors > r2.part_sectors * 2, 0);
        g_logging = 1; g_nwlog = 0;
        r = havendos_install_additive(MODEL_DISK, 1, &r2, 0);
        g_logging = 0;
        ck("and the second is refused as already installed",
           r == INSTADD_E_ALREADY, r);
        ck("not for want of room", r != INSTADD_E_NOSPACE, r);
        ck("having written nothing", g_nwlog == 0, g_nwlog);
    }

    head("an install that fails halfway still does not touch Windows");
    {
        /* The disk stops accepting writes partway through the kernel copy.
           Two things have to be true afterwards: the installer says so
           rather than reporting success, and everything outside the new
           partition is still byte-identical -- because a failure is when
           a half-finished installer is most likely to flail. */
        inst_add_t r2;
        int r, bad;
        uint64_t allowed[4], first_bad = 0, elo, ehi;
        gpt_part_t p2[GPT_MAX_PARTS];
        int n, k;

        (void)p2; (void)n; (void)k;
        build_disk(1024ull * 1024 * 1024 * 1024 / 512 / 2);
        ck("rebuild the disk and its ESP", reset_esp(&elo, &ehi), 0);
        snapshot();

        /* 4 for the table, 545 for the format, ~70 for the directories and
           the menu: failing from 700 lands inside the kernel copy. */
        g_wcount = 0; g_wfail_at = 700;
        g_logging = 1; g_nwlog = 0;
        r = havendos_install_additive(MODEL_DISK, 0, &r2, 0);
        g_logging = 0; g_wfail_at = -1;

        ck("the install reports the failure", r == INSTADD_E_FILES, r);
        ck("rather than claiming success", r != INSTADD_OK, r);

        for(k = 0; k < r2.n_outside && k < 4; k++) allowed[k] = r2.outside[k];
        bad = identical_outside(r2.part_first, r2.part_last, elo, ehi,
                                allowed, r2.n_outside, &first_bad);
        ck("and EVERY SECTOR OUTSIDE THE NEW PARTITION IS STILL IDENTICAL",
           bad == 0, bad);
        if(bad)
            printf("      first differing sector: LBA %llu\n",
                   (unsigned long long)first_bad);
        ck("the partition table still verifies", table_verifies(), 0);
    }

    head("one bad sector in the kernel is not reported as a success");
    {
        /* A single refused write, deep in the kernel copy, with everything
           after it working. Nothing else fails, so if the kernel's write
           result were not checked the install would run to the end and say
           "complete" with a short kernel on the disk -- which boots to a
           GRUB error, on a machine whose owner has just been told the
           install worked. */
        inst_add_t r2;
        int r;
        uint64_t elo, ehi;

        build_disk(1024ull * 1024 * 1024 * 1024 / 512 / 2);
        ck("rebuild the disk and its ESP", reset_esp(&elo, &ehi), 0);

        g_wcount = 0; g_wfail_once = 700;      /* inside the kernel copy */
        r = havendos_install_additive(MODEL_DISK, 0, &r2, 0);
        g_wfail_once = -1;

        ck("the install reports a file write failure", r == INSTADD_E_FILES, r);
        ck("and does not report success", r != INSTADD_OK, r);

        /* If it ever did report success, the kernel on the disk would be
           short. Asserted so the claim is about the disk and not only
           about the return value. */
        if(r == INSTADD_OK){
            FILE *f = fopen("/tmp/hd_ia_badpart.img", "wb");
            uint64_t i3;
            static uint8_t sec[512];
            if(f){
                for(i3 = 0; i3 < r2.part_sectors; i3++){
                    if(d_read(0, r2.part_first + i3, sec) != 0)
                        memset(sec, 0, 512);
                    if(fwrite(sec, 1, 512, f) != 512) break;
                }
                fclose(f);
            }
            ck("the kernel on disk is NOT intact, proving the point",
               system("mcopy -n -i /tmp/hd_ia_badpart.img ::/boot/havendos.elf "
                      "/tmp/hd_ia_badk.bin > /dev/null 2>&1") != 0
               || system("cmp -s /tmp/hd_ia_badk.bin /tmp/hd_ia_kernel.bin")
                  != 0, 0);
        }
    }

    head("a disk with no GPT is refused, not guessed at");
    {
        inst_add_t r2;
        int r;
        build_disk(1024ull * 1024 * 1024 * 1024 / 512 / 2);
        memset(find(1)->b, 0, 512);                    /* no primary header */
        memset(find(g_disk_sectors - 1)->b, 0, 512);   /* nor a backup      */
        g_wcount = 0; g_logging = 1; g_nwlog = 0;
        r = havendos_install_additive(MODEL_DISK, 1, &r2, 0);
        g_logging = 0;
        ck("the preview refuses", r == INSTADD_E_NOGPT, r);
        ck("and read-only, so nothing was written", g_nwlog == 0, g_nwlog);
        ck("the message says what to do instead",
           havendos_install_add_strerror(r) != 0, 0);
    }

    head("a gap far larger than FAT16 can hold is capped, not refused");
    {
        inst_add_t r2;
        int r;
        /* 64 GB free. FAT16 at 32 KB clusters stops just under 2 GB, so a
           cap is the only way this is anything but an error message on a
           disk with plenty of room. The rest of the gap is left free. */
        build_disk_gap(1024ull * 1024 * 1024 * 1024 / 512 / 2, 128,
                       64ull * 1024 * 1024 * 1024 / 512);
        ck("an ESP with Windows on it, as before", reset_esp(0, 0), 0);
        r = havendos_install_additive(MODEL_DISK, 1, &r2, 0);
        ck("the preview succeeds", r == INSTADD_OK, r);
        ck("the partition is capped at the FAT16 limit",
           r2.part_sectors == INSTADD_MAX_SECTORS, (long)r2.part_sectors);
        ck("the gap it came from is much larger",
           r2.gap_sectors > r2.part_sectors * 8, (long)(r2.gap_sectors >> 20));
        ck("the geometry is still a valid FAT16",
           r2.geom.clusters >= FAT16_MIN_CLUSTERS
           && r2.geom.clusters <= FAT16_MAX_CLUSTERS, (long)r2.geom.clusters);
        ck("and the leftover is left alone",
           r2.part_last < r2.gap_last, 0);
        printf("      %llu MB gap -> a %llu MB partition, %llu MB left free\n",
               (unsigned long long)(r2.gap_sectors / 2048),
               (unsigned long long)(r2.part_sectors / 2048),
               (unsigned long long)((r2.gap_last - r2.part_last) / 2048));
    }

    head("a gap that alignment shrinks below the floor is refused");
    {
        /* gpt_find_free() only returns gaps of at least the minimum, so the
           floor looks unreachable -- until alignment. Aligning the start up
           to a megabyte and the length down to one can cost 4094 sectors
           between them, which is enough to take a gap just over 16 MB
           under it. Rather than assert which gap size does that -- that
           would mean recomputing the installer's own arithmetic here and
           asserting the two agree -- this searches the range and requires
           that at least one such size exists and is refused with the right
           code. */
        inst_add_t r2;
        uint64_t g2;
        int found_small = 0, wrote = 0, wrong_code = 0;
        for(g2 = INSTADD_MIN_SECTORS; g2 < INSTADD_MIN_SECTORS + 4096; g2 += 1){
            int r;
            build_disk_gap(1024ull * 1024 * 1024 * 1024 / 512 / 2, 128, g2);
            g_logging = 1; g_nwlog = 0;
            r = havendos_install_additive(MODEL_DISK, 1, &r2, 0);
            g_logging = 0;
            if(g_nwlog) wrote = 1;
            if(r == INSTADD_E_TOOSMALL){ found_small = 1; continue; }
            /* INSTADD_E_ESP is expected here and is not a failure: this
               loop rebuilds the disk four thousand times and does not
               format an EFI System Partition into each one, which would
               take minutes. The floor is checked long before the ESP is
               looked at, so a gap that should be refused as too small
               still is. */
            if(r != INSTADD_OK && r != INSTADD_E_VOLSPACE
               && r != INSTADD_E_GEOM && r != INSTADD_E_ESP) wrong_code = 1;
        }
        ck("some gap in that range is refused as too small", found_small, 0);
        ck("every other answer in the range is a plan or a known refusal",
           !wrong_code, 0);
        ck("and the preview never wrote while finding out", !wrote, g_nwlog);
    }

    head("a kernel too big for the partition is refused before formatting");
    {
        inst_add_t r2;
        int r;
        uint32_t save = kernel_elf_size;
        build_disk(1024ull * 1024 * 1024 * 1024 / 512 / 2);
        ck("an ESP, so a refusal here is about the volume", reset_esp(0, 0), 0);
        /* The check is on the SIZE, and it refuses before a byte is read
           from the image, so an inflated size is a safe way to ask. */
        kernel_elf_size = 1800u * 1024u * 1024u;       /* 1800 MB */
        g_logging = 1; g_nwlog = 0;
        r = havendos_install_additive(MODEL_DISK, 1, &r2, 0);
        g_logging = 0;
        kernel_elf_size = save;
        ck("the preview refuses for want of room in the volume",
           r == INSTADD_E_VOLSPACE, r);
        ck("and wrote nothing", g_nwlog == 0, g_nwlog);
        ck("the report says how much it needed and how much there was",
           r2.vol_need_bytes > r2.vol_free_bytes
           && r2.vol_free_bytes > 0, 0);
    }

    if(system("rm -f /tmp/hd_ia_*.img /tmp/hd_ia_*.bin /tmp/hd_ia_*.txt")){}
    printf("\n%d/%d passed\n", total - fails, total);
    return fails ? 1 : 0;
}
