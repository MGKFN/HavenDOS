/*
 * iso_installer.c — HavenDOS v0.7.4 ISO Install Wizard
 *
 * v0.7.4 changes:
 *  - Unified disk abstraction: probes VirtIO first, then ATA/SATA.
 *    On real PC hardware with a SATA SSD (Lenovo X140e etc.) the
 *    installer now correctly detects and installs to the ATA drive.
 *  - All version strings updated to v0.7.4.
 *  - Welcome screen no longer says "attach a VirtIO disk" on ATA systems.
 *  - Drive picker shows bus type (VirtIO / ATA) and actual disk size.
 *
 * Flow:
 *   Screen 1: Welcome
 *   Screen 2: Drive picker
 *   Screen 3b: Terms of Service
 *   Screen 3: Partition layout preview + YES confirm
 *   Screen 4: Progress bar
 *   Screen 5: Done → countdown → reboot
 */

#include "../include/vga.h"
#include "version.h"
#include "../include/string.h"
#include "../include/types.h"
#include "../include/install_add.h"
#include "../include/esp.h"

extern int      keyboard_waitchar(void);
extern void     sleep_ms(uint32_t);
extern void     utoa(uint32_t, char*, int);

/* ── VirtIO API ─────────────────────────────────────────────────── */
extern int      virtio_scan_drives(void);
extern int      virtio_drive_count(void);
extern uint64_t virtio_drive_sectors(int);
extern uint8_t  virtio_drive_bus(int);
extern uint8_t  virtio_drive_dev(int);
extern int      virtio_drive_read(int, uint64_t, uint8_t*);
extern int      virtio_drive_write(int, uint64_t, const uint8_t*);

/* ── ATA/SATA API ───────────────────────────────────────────────── */
extern void     ata_init(void);
extern int      ata_detected(void);
extern uint32_t ata_sectors(void);
extern int      ata_lba48(void);
extern int      ata_read_sector(uint32_t, uint8_t*);
extern int      ata_write_sector(uint32_t, const uint8_t*);
extern int      ata_read_sector48(uint64_t, uint8_t*);
extern int      ata_write_sector48(uint64_t, const uint8_t*);

/* ── Install API (install.c) ────────────────────────────────────── */
extern int havendos_install_to_drive(int, void(*)(int,int,const char*));

/* ── Unified disk abstraction ───────────────────────────────────── */
/* Drive types */
#define DTYPE_VIRTIO  0
#define DTYPE_ATA     1

typedef struct {
    int      type;        /* DTYPE_* */
    int      virtio_idx;  /* valid when type==DTYPE_VIRTIO */
    uint64_t sectors;
    uint8_t  bus;
    uint8_t  dev;
} disk_entry_t;

#define MAX_DISKS 8
static disk_entry_t g_disks[MAX_DISKS];
static int          g_ndisks = 0;

/* NVMe used to be enumerated so `disk` could SHOW it and then excluded
   from everything the installer can reach, because the only installer
   there was begins by zeroing LBA 0..63 and the last 33 sectors -- both
   GPT headers and the entry arrays -- and on an NVMe machine that is
   somebody's Windows install, not a spare disk.

   include/nvme.h stated the condition for lifting that: "the refusal is
   lifted when that condition is met and nvme_write() exists". Both are
   now true. The additive installer adds a partition instead of replacing
   the table, and nvme_write() is in drivers/nvme.c with a suite that runs
   it against a simulated controller -- including the case that makes it
   dangerous, a 4096-byte-block namespace where writing one 512-byte
   sector means reading the block first or destroying the other seven.

   So the blanket refusal is gone and a narrower one takes its place: a
   disk is read-only if there is no write function for its bus. What still
   protects an NVMe disk is not that it cannot be written, it is that the
   only installer allowed to write to a disk with a partition table is the
   one that adds to it. havendos_install_to_drive() still refuses a GPT
   disk outright (-14). */
#define DTYPE_NVME 2
#define DTYPE_AHCI 3
static int disk_is_readonly(int i){
    if(i < 0 || i >= g_ndisks) return 1;
    switch(g_disks[i].type){
    case DTYPE_NVME:   { extern int nvme_writable(int);
                         return !nvme_writable(g_disks[i].virtio_idx); }
    case DTYPE_AHCI:   { extern int ahci_is_atapi(int);
                         /* an optical drive is not an install target */
                         return ahci_is_atapi(g_disks[i].virtio_idx); }
    case DTYPE_VIRTIO: return 0;
    default:           return 0;      /* ATA */
    }
}

/* Scan both buses and populate g_disks[].
   Returns total number of disks found. */
static int disk_scan(void) {
    g_ndisks = 0;

    /* 1 — VirtIO */
    int nv = virtio_scan_drives();
    for (int i = 0; i < nv && g_ndisks < MAX_DISKS; i++) {
        g_disks[g_ndisks].type       = DTYPE_VIRTIO;
        g_disks[g_ndisks].virtio_idx = i;
        g_disks[g_ndisks].sectors    = virtio_drive_sectors(i);
        g_disks[g_ndisks].bus        = virtio_drive_bus(i);
        g_disks[g_ndisks].dev        = virtio_drive_dev(i);
        g_ndisks++;
    }

    /* 2 — NVMe, read-only (see disk_is_readonly above) */
    {
        extern int      nvme_count(void);
        extern uint64_t nvme_sectors(int);
        for(int i = 0; i < nvme_count() && g_ndisks < MAX_DISKS; i++){
            g_disks[g_ndisks].type       = DTYPE_NVME;
            g_disks[g_ndisks].virtio_idx = i;      /* namespace index */
            g_disks[g_ndisks].sectors    = nvme_sectors(i);
            g_disks[g_ndisks].bus        = 0;
            g_disks[g_ndisks].dev        = 0;
            g_ndisks++;
        }
    }

    /* 3 — AHCI.  Before legacy ATA, because on a machine where both
       answer, the AHCI registers are the real interface and the legacy
       ports are a compatibility shim that reaches at most two of the
       controller's ports. */
    {
        extern int      ahci_init(void);
        extern int      ahci_count(void);
        extern uint64_t ahci_sectors(int);
        extern int      ahci_is_atapi(int);
        ahci_init();
        for(int i = 0; i < ahci_count() && g_ndisks < MAX_DISKS; i++){
            if(ahci_is_atapi(i)) continue;      /* listed, not installable */
            g_disks[g_ndisks].type       = DTYPE_AHCI;
            g_disks[g_ndisks].virtio_idx = i;
            g_disks[g_ndisks].sectors    = ahci_sectors(i);
            g_disks[g_ndisks].bus        = 0;
            g_disks[g_ndisks].dev        = 0;
            g_ndisks++;
        }
    }

    /* 4 — legacy ATA / SATA in compatibility mode */
    ata_init();
    if (ata_detected() && g_ndisks < MAX_DISKS) {
        g_disks[g_ndisks].type       = DTYPE_ATA;
        g_disks[g_ndisks].virtio_idx = -1;
        g_disks[g_ndisks].sectors    = (uint64_t)ata_sectors();
        g_disks[g_ndisks].bus        = 0;
        g_disks[g_ndisks].dev        = 0;
        g_ndisks++;
    }

    return g_ndisks;
}

/* ── What can be done with each disk ─────────────────────────────────
   Until 0.8.2 this was one question with one answer: a GPT disk was
   refused, because the only installer there was begins by zeroing the
   first 64 sectors and the last 33. There are two installers now, and
   which one applies -- or whether neither does -- depends on the disk.

   The answer is worked out ONCE, after the scan, and cached. The picker
   below redraws on every keypress, and re-reading a partition table
   sixty times a second to decide what colour to paint a row is a way to
   make a disk sound unhealthy.

   havendos_install_additive() with dry_run is what answers it: the same
   code path the install itself takes, so a row that says there is room
   is a row the install agrees with. */
#define DMODE_WIPE     0   /* no GPT: the whole-disk installer, destructive */
#define DMODE_ADD      1   /* GPT with usable free space: install beside it */
#define DMODE_PREVIEW  2   /* ...but no write path to this bus yet          */
#define DMODE_NOROOM   3   /* GPT, and nowhere to put a partition           */
#define DMODE_SMALL    4   /* too small for either                          */
#define DMODE_DONE     5   /* HavenDOS is already on it -- not an error     */

static int        g_dmode[MAX_DISKS];
static inst_add_t g_dplan[MAX_DISKS];
static int        g_dplan_rc[MAX_DISKS];

/* defined below, beside the other GPT helpers */
int inst_disk_has_gpt(int i);

static void plan_disks(void)
{
    for(int i = 0; i < g_ndisks; i++){
        uint32_t mb = (uint32_t)(g_disks[i].sectors / 2048);
        g_dplan_rc[i] = INSTADD_E_DISK;
        memset(&g_dplan[i], 0, sizeof g_dplan[i]);

        if(!inst_disk_has_gpt(i)){
            g_dmode[i] = (mb < 15) ? DMODE_SMALL : DMODE_WIPE;
            continue;
        }
        /* A GPT disk. Ask the additive installer what it would do. */
        g_dplan_rc[i] = havendos_install_additive(i, 1, &g_dplan[i], 0);
        if(g_dplan_rc[i] == INSTADD_E_ALREADY)
            g_dmode[i] = DMODE_DONE;
        else if(g_dplan_rc[i] == INSTADD_OK)
            g_dmode[i] = disk_is_readonly(i) ? DMODE_PREVIEW : DMODE_ADD;
        else if(g_dplan_rc[i] == INSTADD_E_READONLY)
            g_dmode[i] = DMODE_PREVIEW;
        else
            g_dmode[i] = DMODE_NOROOM;
    }
}

/* LBAs on a 512 GB disk run past 1,000,000,000 and utoa() takes a
   uint32_t, which covers up to 2 TB. Past that the number printed would be
   wrong rather than missing, so it is clamped and marked instead: a wrong
   sector number on the screen that promises which sectors get written is
   worse than no number. */
/* ── The bus label, in one place ──────────────────────────────────
   Three screens used to work this out independently and two of them had
   never heard of NVMe or AHCI, so a drive the picker correctly listed as
   NVMe was announced as "(VirtIO)" on the confirmation screen -- the one
   screen whose whole job is to say what is about to be written and to
   which disk. Everything asks here now. */
static const char *bus_name(int drive){
    switch(g_disks[drive].type){
        case DTYPE_ATA:  return "IDE";
        case DTYPE_AHCI: return "SATA";
        case DTYPE_NVME: return "NVMe";
        default:         return "VirtIO";
    }
}
static vga_color_t bus_col(int drive){
    switch(g_disks[drive].type){
        case DTYPE_AHCI:
        case DTYPE_ATA:  return VGA_LIGHT_GREEN;
        case DTYPE_NVME: return VGA_YELLOW;
        default:         return VGA_LIGHT_CYAN;
    }
}
/* "(NVMe)" into a caller buffer of at least 10 bytes. */
static void bus_paren(int drive, char *out){
    const char *n = bus_name(drive); int i = 0;
    out[i++] = '(';
    while(*n) out[i++] = *n++;
    out[i++] = ')'; out[i] = 0;
}

static void lba_str(uint64_t v, char *buf)
{
    if(v > 0xFFFFFFFFull){ buf[0]='>'; buf[1]='4'; buf[2]='G'; buf[3]=0; return; }
    utoa((uint32_t)v, buf, 10);
}

/* Read/write through whichever bus owns disk index i */
int disk_read(int i, uint64_t lba, uint8_t *buf) {
    if (i < 0 || i >= g_ndisks) return 0;
    if (g_disks[i].type == DTYPE_NVME) {
        extern int nvme_read(int, uint64_t, uint32_t, void*);
        return nvme_read(g_disks[i].virtio_idx, lba, 1, buf) == 0;
    }
    if (g_disks[i].type == DTYPE_AHCI) {
        extern int ahci_read_sector(int, uint64_t, uint8_t*);
        return ahci_read_sector(g_disks[i].virtio_idx, lba, buf);
    }
    if (g_disks[i].type == DTYPE_VIRTIO)
        return virtio_drive_read(g_disks[i].virtio_idx, lba, buf);
    /* ATA */
    if (ata_lba48()) return ata_read_sector48(lba, buf);
    return ata_read_sector((uint32_t)lba, buf);
}

int disk_write(int i, uint64_t lba, const uint8_t *buf) {
    if (i < 0 || i >= g_ndisks) return 0;
    /* Every write in the installer funnels through here, so this one line
       is below every UI and every caller: a future code path cannot reach
       a disk with no write function by forgetting to ask. */
    if (disk_is_readonly(i)) return 0;
    if (g_disks[i].type == DTYPE_NVME) {
        extern int nvme_write(int, uint64_t, uint32_t, const void*);
        return nvme_write(g_disks[i].virtio_idx, lba, 1, buf) == 0;
    }
    if (g_disks[i].type == DTYPE_AHCI) {
        extern int ahci_write_sector(int, uint64_t, const uint8_t*);
        return ahci_write_sector(g_disks[i].virtio_idx, lba, buf);
    }
    if (g_disks[i].type == DTYPE_VIRTIO)
        return virtio_drive_write(g_disks[i].virtio_idx, lba, buf);
    if (ata_lba48()) return ata_write_sector48(lba, buf);
    return ata_write_sector((uint32_t)lba, buf);
}

uint64_t disk_sectors(int i) {
    if (i < 0 || i >= g_ndisks) return 0;
    return g_disks[i].sectors;
}

/* Expose to install.c via extern symbols */
int      inst_disk_count(void)               { return g_ndisks; }
/* ...and to the desktop installer, which used to run its own VirtIO-only scan
   and hand havendos_install_to_drive() a VirtIO index.  That index only ever
   matched a unified one while VirtIO was the only bus, so on an IDE machine
   the desktop app reported "No VirtIO drives found" next to a perfectly good
   disk the ISO installer could see. */
int      inst_disk_scan(void)                { return disk_scan(); }
int      inst_disk_is_ata(int i)             { return (i>=0 && i<g_ndisks) && g_disks[i].type==DTYPE_ATA; }
int      inst_disk_is_nvme(int i)            { return (i>=0 && i<g_ndisks) && g_disks[i].type==DTYPE_NVME; }
int      inst_disk_is_readonly(int i)        { return disk_is_readonly(i); }

/* Does this disk carry a GUID Partition Table?  Checked by reading LBA 1,
   so it works on any bus the scan found. */
#include "gpt.h"
static int gpt_rd(void *ctx, uint64_t lba, void *buf){
    int i = (int)(long)ctx;
    return disk_read(i, lba, (uint8_t*)buf) ? 0 : -1;
}
int inst_disk_has_gpt(int i){
    if(i < 0 || i >= g_ndisks) return 0;
    return gpt_present(gpt_rd, (void*)(long)i);
}
int inst_disk_gpt_parts(int i, gpt_part_t *out, int max){
    if(i < 0 || i >= g_ndisks) return 0;
    return gpt_scan(gpt_rd, (void*)(long)i, out, max);
}
uint8_t  inst_disk_bus(int i)                { return (i>=0 && i<g_ndisks) ? g_disks[i].bus : 0; }
uint8_t  inst_disk_dev(int i)                { return (i>=0 && i<g_ndisks) ? g_disks[i].dev : 0; }
int      inst_disk_read(int i, uint64_t lba, uint8_t *b)        { return disk_read(i,lba,b); }
int      inst_disk_write(int i, uint64_t lba, const uint8_t *b) { return disk_write(i,lba,b); }
uint64_t inst_disk_sectors(int i)            { return disk_sectors(i); }

/* ── Palette ─────────────────────────────────────────────────────── */
#define HDR_BG   VGA_BLUE
#define HDR_FG   VGA_WHITE
#define BODY_BG  VGA_BLACK
#define BODY_FG  VGA_LIGHT_GREY
#define ACC      VGA_LIGHT_CYAN
#define WARN     VGA_LIGHT_RED
#define OK_COL   VGA_LIGHT_GREEN
#define SEL_BG   VGA_CYAN
#define SEL_FG   VGA_BLACK

/* ── Helpers ─────────────────────────────────────────────────────── */
static void cls(void){
    for(int y=0;y<25;y++)
        for(int x=0;x<80;x++)
            vga_putchar_at(' ',x,y,BODY_FG,BODY_BG);
}

static void hdr(const char *title, int step, int total){
    for(int x=0;x<80;x++) vga_putchar_at(' ',x,0,HDR_FG,HDR_BG);
    vga_puts_at(" HavenDOS " HAVENDOS_VER " Installer",0,0,HDR_FG,HDR_BG);
    char sb[20]; int si=0;
    sb[si++]='S';sb[si++]='t';sb[si++]='e';sb[si++]='p';sb[si++]=' ';
    sb[si++]='0'+step; sb[si++]='/'; sb[si++]='0'+total; sb[si]=0;
    vga_puts_at(sb,72,0,VGA_LIGHT_CYAN,HDR_BG);
    for(int x=0;x<80;x++) vga_putchar_at('-',x,1,VGA_DARK_GREY,BODY_BG);
    vga_puts_at(title,2,1,ACC,BODY_BG);
}

static void footer(const char *hint){
    for(int x=0;x<80;x++) vga_putchar_at(' ',x,24,HDR_FG,HDR_BG);
    vga_puts_at(hint,2,24,VGA_LIGHT_CYAN,HDR_BG);
}

static void box(int x,int y,int w,int h){
    for(int i=x;i<x+w;i++){
        vga_putchar_at('-',i,y,VGA_DARK_GREY,BODY_BG);
        vga_putchar_at('-',i,y+h-1,VGA_DARK_GREY,BODY_BG);
    }
    for(int j=y+1;j<y+h-1;j++){
        vga_putchar_at('|',x,j,VGA_DARK_GREY,BODY_BG);
        vga_putchar_at('|',x+w-1,j,VGA_DARK_GREY,BODY_BG);
    }
}

static void puts_center(const char *s, int row, vga_color_t fg, vga_color_t bg){
    int len=(int)strlen(s);
    int x=(80-len)/2; if(x<0)x=0;
    vga_puts_at(s,x,row,fg,bg);
}

/* ── Progress callback ───────────────────────────────────────────── */
static int g_prog_row=0;
static void prog_cb(int step, int total, const char *msg){
    int bar_w=60;
    int filled=(step*bar_w)/total;
    for(int x=0;x<bar_w;x++)
        vga_putchar_at(x<filled?'#':'.',10+x,g_prog_row,
                       x<filled?OK_COL:VGA_DARK_GREY,BODY_BG);
    char pct[8]; utoa((uint32_t)(step*100/total),pct,10);
    int pl=(int)strlen(pct);
    vga_puts_at("   ",71,g_prog_row,BODY_FG,BODY_BG);
    vga_puts_at(pct,71,g_prog_row,ACC,BODY_BG);
    vga_putchar_at('%',71+pl,g_prog_row,ACC,BODY_BG);
    char padmsg[72]; int ml=(int)strlen(msg);
    for(int i=0;i<71;i++) padmsg[i]=(i<ml)?msg[i]:' ';
    padmsg[71]=0;
    vga_puts_at(padmsg,4,g_prog_row+1,BODY_FG,BODY_BG);
}

/* ── Screen 1: Welcome ───────────────────────────────────────────── */
static void screen_welcome(int has_virtio, int has_ata){
    cls(); hdr("Welcome",1,6);
    footer("Press ENTER to continue  |  ESC to reboot");

    box(10,3,60,7);
    puts_center("HavenDOS " HAVENDOS_VER,5,ACC,BODY_BG);
    puts_center("TechHaven Studios",6,VGA_DARK_GREY,BODY_BG);

    vga_puts_at("You have booted from the HavenDOS install ISO.",6,12,BODY_FG,BODY_BG);
    vga_puts_at("This ISO is install media - live desktop is not available.",4,13,BODY_FG,BODY_BG);
    vga_puts_at("The installer will:",6,15,BODY_FG,BODY_BG);
    vga_puts_at(". Partition and format a disk of your choice",8,16,VGA_LIGHT_GREY,BODY_BG);
    vga_puts_at(". Write the HavenDOS bootloader and kernel",8,17,VGA_LIGHT_GREY,BODY_BG);
    vga_puts_at(". Reboot into the installed system automatically",8,18,VGA_LIGHT_GREY,BODY_BG);

    /* Dynamic disk hint based on what was found */
    if(has_virtio && has_ata)
        vga_puts_at("VirtIO and ATA/SATA disks detected.",6,20,OK_COL,BODY_BG);
    else if(has_ata)
        vga_puts_at("ATA/SATA disk detected. Ready to install.",6,20,OK_COL,BODY_BG);
    else if(has_virtio)
        vga_puts_at("VirtIO disk detected. Ready to install.",6,20,OK_COL,BODY_BG);
    else
        vga_puts_at("WARNING: No disks found. Attach a disk and reboot.",6,20,WARN,BODY_BG);
}

/* ── Screen 2: Drive picker ─────────────────────────────────────── */
/* ── This disk already has HavenDOS on it ───────────────────────────
   Its own screen rather than a line of red text that disappears after
   three seconds. The first version reported this case as "no free space
   on this disk -- shrink a partition in Windows first", which is true
   (the gap became the HavenDOS partition) and reads as though the disk
   has been damaged. Someone went looking for a fault in a machine that
   had just worked. */
static void screen_already_installed(int drive)
{
    char b[12];
    cls(); hdr("Already Installed", 2, 6);
    footer("Press any key to go back");

    vga_puts_at("HavenDOS is already installed on disk",6,4,BODY_FG,BODY_BG);
    utoa((uint32_t)drive,b,10);
    vga_puts_at(b,43,4,ACC,BODY_BG);
    vga_putchar_at('.',44,4,BODY_FG,BODY_BG);

    vga_puts_at("Nothing is wrong with it. The free space this installer "
                "would have used",6,6,OK_COL,BODY_BG);
    vga_puts_at("is now the HavenDOS partition, which is why there is none "
                "left.",6,7,OK_COL,BODY_BG);

    box(10,9,60,8);
    vga_puts_at("To use it:      shut down, remove the install media,",
                12,10,BODY_FG,BODY_BG);
    vga_puts_at("                and boot the disk.",12,11,BODY_FG,BODY_BG);
    vga_puts_at("To upgrade it:  boot it and run `update`.",
                12,13,BODY_FG,BODY_BG);
    vga_puts_at("To start over:  delete the HavenDOS partition from the",
                12,15,BODY_FG,BODY_BG);
    vga_puts_at("                other operating system, then come back.",
                12,16,BODY_FG,BODY_BG);

    vga_puts_at("Installing a second copy is refused on purpose: two "
                "partitions",6,19,VGA_LIGHT_GREY,BODY_BG);
    vga_puts_at("labelled HAVENDOS would make the boot menu's "
                "`search --label` pick",6,20,VGA_LIGHT_GREY,BODY_BG);
    vga_puts_at("whichever it found first.",6,21,VGA_LIGHT_GREY,BODY_BG);
    keyboard_waitchar();
}

static int screen_drive_picker(int ndisks){
    int sel=0;

    while(1){
        cls(); hdr("Select Target Disk",2,6);
        footer("Up/Down=select  ENTER=confirm  ESC=cancel");

        vga_puts_at("Choose the disk to install HavenDOS on.",6,3,BODY_FG,BODY_BG);
        /* This used to say the selected disk would be COMPLETELY WIPED, for
           every disk, because that was the only thing the installer could
           do. It is now true of some disks and false of others, and a
           warning that is false half the time is worse than none: it is
           the Notes column, per row, that says which. */
        vga_puts_at("A disk with a partition table keeps it - HavenDOS goes "
                    "in the free space.",6,4,BODY_FG,BODY_BG);
        vga_puts_at("A disk with no partition table is WIPED. Read the Notes "
                    "column.",6,5,VGA_YELLOW,BODY_BG);

        vga_puts_at("  #  Size       Type     Bus  Dev  Notes",6,6,ACC,BODY_BG);
        for(int x=6;x<74;x++) vga_putchar_at('-',x,7,VGA_DARK_GREY,BODY_BG);

        for(int i=0;i<ndisks&&i<10;i++){
            uint64_t sects=disk_sectors(i);
            uint32_t mb=(uint32_t)(sects/2048);
            uint32_t gb_int=mb/1024, gb_frac=(mb%1024)*10/1024;

            int is_sel=(i==sel);
            vga_color_t fg=is_sel?SEL_FG:BODY_FG;
            vga_color_t bg=is_sel?SEL_BG:BODY_BG;

            for(int x=6;x<74;x++) vga_putchar_at(' ',x,8+i,fg,bg);
            vga_putchar_at(is_sel?'>':' ',6,8+i,is_sel?OK_COL:BODY_FG,bg);

            char ns[4]; utoa((uint32_t)i,ns,10);
            vga_puts_at(ns,8,8+i,fg,bg);

            /* Size */
            char szs[12];
            if(gb_int>0){
                utoa(gb_int,szs,10);
                int sl=(int)strlen(szs); szs[sl]='.'; sl++;
                utoa(gb_frac,szs+sl,10); sl++;
                szs[sl]='G'; szs[sl+1]='B'; szs[sl+2]=0;
            } else {
                utoa(mb,szs,10);
                int sl=(int)strlen(szs); szs[sl]='M'; szs[sl+1]='B'; szs[sl+2]=0;
            }
            int sl=(int)strlen(szs);
            while(sl<10){ szs[sl++]=' '; szs[sl]=0; }
            vga_puts_at(szs,12,8+i,fg,bg);

            /* Bus type label.  NVMe used to fall through to "VirtIO",
               which is not a cosmetic slip: it showed somebody's Windows
               drive under the wrong name on a screen whose next step erases
               it. */
            { char bn[10]; const char *nm = bus_name(i); int k = 0;
              while(nm[k]){ bn[k] = nm[k]; k++; }
              while(k < 8) bn[k++] = ' ';
              bn[k] = 0;
              vga_puts_at(bn,23,8+i,is_sel?SEL_FG:bus_col(i),bg); }

            /* Bus / dev numbers */
            char bs[4]; utoa(g_disks[i].bus,bs,10);
            vga_puts_at(bs,32,8+i,fg,bg);
            char ds[4]; utoa(g_disks[i].dev,ds,10);
            vga_puts_at(ds,37,8+i,fg,bg);

            /* Notes.  The two refusals are stated HERE, on the row, rather
               than after the user has picked the disk and typed YES.  An
               installer that walks someone all the way to the confirmation
               prompt and only then says no has taught them nothing except
               that it wastes their time -- and the 0.8 Beta changelog
               already records what "discovered at step 7 of 9" cost once. */
            switch(g_dmode[i]){
            case DMODE_ADD: {
                /* The size of the partition that would be created, from the
                   cached dry run -- not the size of the gap, and not a
                   guess: the number the install itself would use. */
                char fb[12];
                utoa((uint32_t)(g_dplan[i].part_sectors/2048), fb, 10);
                vga_puts_at("keeps this disk, uses",42,8+i,OK_COL,bg);
                vga_puts_at(fb,64,8+i,ACC,bg);
                vga_puts_at("MB",64+(int)strlen(fb)+1,8+i,OK_COL,bg);
                break; }
            case DMODE_PREVIEW:
                vga_puts_at("preview only - no write path",42,8+i,
                            VGA_YELLOW,bg);
                break;
            case DMODE_DONE:
                /* Not WARN. This disk is in the state the user was trying
                   to reach, and painting it the same red as a refusal is
                   what made a working install look like a broken disk. */
                vga_puts_at("HavenDOS already installed",42,8+i,OK_COL,bg);
                break;
            case DMODE_NOROOM:
                /* Why, not just no. "Refused" taught the user nothing; the
                   reason tells them whether shrinking a partition in
                   Windows would change the answer. */
                vga_puts_at(havendos_install_add_shortstr(g_dplan_rc[i]),
                            42,8+i,WARN,bg);
                break;
            case DMODE_SMALL:
                vga_puts_at("TOO SMALL (min 15MB)",42,8+i,WARN,bg);
                break;
            default:
                vga_puts_at("no partition table - WIPES disk",42,8+i,
                            VGA_YELLOW,bg);
                break;
            }
        }

        int hint_row=8+ndisks+1;
        if(hint_row>21) hint_row=21;
        vga_puts_at("HavenDOS requires at least 15MB, or 16MB of free space "
                    "beside another OS.",6,hint_row,VGA_DARK_GREY,BODY_BG);
        vga_puts_at("Picking a disk shows exactly what would be written "
                    "before anything is.",
                    6,hint_row+1,VGA_DARK_GREY,BODY_BG);

        int c=keyboard_waitchar();
        if(c==27) return -1;
        if(c==0x148&&sel>0) sel--;
        if(c==0x150&&sel<ndisks-1) sel++;
        if(c=='\n'||c=='\r'){
            switch(g_dmode[sel]){
            case DMODE_ADD:
            case DMODE_PREVIEW:
            case DMODE_WIPE:
                return sel;
            case DMODE_DONE:
                screen_already_installed(sel);
                break;
            case DMODE_NOROOM:
                vga_puts_at(havendos_install_add_strerror(g_dplan_rc[sel]),
                            6,hint_row+2,WARN,BODY_BG);
                vga_puts_at("Shrink a partition in Windows' Disk Management "
                            "to make room, then retry.",
                            6,hint_row+3,VGA_LIGHT_GREY,BODY_BG);
                sleep_ms(3000);
                break;
            default:
                vga_puts_at("Drive too small - minimum 15MB required.",
                            6,hint_row+2,WARN,BODY_BG);
                sleep_ms(1600);
                break;
            }
        }
    }
}

/* ── Screen 3a: the additive preview ────────────────────────────────
   The screen this whole release is for.

   The old confirmation screen described a fixed layout -- sector 0, the
   MBR, sectors 1..2047, the partition at 2048 -- because the layout was
   fixed. An additive install has no fixed layout: where the partition
   goes depends on where the free space is, and what gets written outside
   it is four sectors whose numbers depend on the table already there.

   So this screen does not describe the install in general terms. It
   prints the actual numbers, out of a dry run of the same function that
   will do the work, and it prints them BEFORE anything is written. If
   what appears here is wrong, nothing has happened yet. */
static int screen_additive_preview(int drive, int writable)
{
    const inst_add_t *pl = &g_dplan[drive];
    char b1[12], b2[12], b3[12];
    int row;

    cls(); hdr(writable ? "What will be written" : "What WOULD be written",
               3, 6);
    footer(writable ? "ENTER=continue  ESC=go back"
                    : "ESC=go back  (this disk cannot be written yet)");

    row = 3;
    vga_puts_at("Disk",6,row,BODY_FG,BODY_BG);
    utoa((uint32_t)drive,b1,10);
    vga_puts_at(b1,11,row,ACC,BODY_BG);
    { char bp[10]; bus_paren(drive,bp);
      vga_puts_at(bp,14,row,bus_col(drive),BODY_BG); }
    vga_puts_at("keeps its partition table and every partition on it.",
                26,row,OK_COL,BODY_BG);
    row += 2;

    /* 1 -- the new partition */
    vga_puts_at("A new partition, in free space that is already free:",
                6,row,ACC,BODY_BG); row++;
    lba_str(pl->part_first,b1); lba_str(pl->part_last,b2);
    utoa((uint32_t)(pl->part_sectors/2048),b3,10);
    vga_puts_at("sectors",8,row,VGA_LIGHT_GREY,BODY_BG);
    vga_puts_at(b1,16,row,BODY_FG,BODY_BG);
    vga_puts_at("to",17+(int)strlen(b1),row,VGA_LIGHT_GREY,BODY_BG);
    vga_puts_at(b2,20+(int)strlen(b1),row,BODY_FG,BODY_BG);
    vga_puts_at("(",21+(int)strlen(b1)+(int)strlen(b2),row,VGA_LIGHT_GREY,BODY_BG);
    vga_puts_at(b3,22+(int)strlen(b1)+(int)strlen(b2),row,ACC,BODY_BG);
    vga_puts_at("MB)",22+(int)strlen(b1)+(int)strlen(b2)+(int)strlen(b3),
                row,VGA_LIGHT_GREY,BODY_BG);
    row++;
    vga_puts_at("formatted FAT16, labelled HAVENDOS, holding the kernel",
                8,row,VGA_LIGHT_GREY,BODY_BG); row += 2;

    /* 2 -- THE FOUR SECTORS. The reason this screen exists. */
    vga_puts_at("Outside that partition, FOUR sectors are written:",
                6,row,ACC,BODY_BG); row++;
    {
        int col = 8;
        for(int i = 0; i < pl->n_outside && i < 4; i++){
            lba_str(pl->outside[i],b1);
            vga_puts_at(b1,col,row,BODY_FG,BODY_BG);
            col += (int)strlen(b1);
            if(i + 1 < pl->n_outside && i < 3){
                vga_puts_at(",",col,row,VGA_LIGHT_GREY,BODY_BG);
                col += 2;
            }
        }
    }
    row++;
    vga_puts_at("the two partition-table headers and one sector of each "
                "entry list.",8,row,VGA_LIGHT_GREY,BODY_BG); row++;
    vga_puts_at("No other sector outside the new partition is touched.",
                8,row,OK_COL,BODY_BG); row += 2;

    /* 3 -- the ESP */
    vga_puts_at("On the EFI System Partition, files are ADDED:",
                6,row,ACC,BODY_BG); row++;
    vga_puts_at("/EFI/HAVENDOS/grubx64.efi and grub.cfg, and "
                "/EFI/BOOT/BOOTX64.EFI",8,row,VGA_LIGHT_GREY,BODY_BG); row++;
    if(pl->esp.has_fallback){
        vga_puts_at("the BOOTX64.EFI already there is COPIED to",
                    8,row,VGA_YELLOW,BODY_BG);
        vga_puts_at(pl->esp.backup_name,50,row,ACC,BODY_BG);
        row++;
        vga_puts_at("first, and never overwritten before that copy is "
                    "verified.",8,row,VGA_LIGHT_GREY,BODY_BG);
        row++;
    }
    if(pl->esp.has_microsoft){
        vga_puts_at("Windows' own bootloader is there and is not written "
                    "to at all.",8,row,OK_COL,BODY_BG);
        row++;
        vga_puts_at("The boot menu will offer Windows as well as HavenDOS.",
                    8,row,OK_COL,BODY_BG);
        row++;
    }

    row = 21;
    if(!writable){
        vga_puts_at("THIS IS A PREVIEW ONLY. HavenDOS cannot write to this "
                    "disk yet, so",6,row,VGA_YELLOW,BODY_BG);
        vga_puts_at("nothing above will happen. Nothing has been written.",
                    6,row+1,VGA_YELLOW,BODY_BG);
        while(1){
            int k = keyboard_waitchar();
            if(k == 27 || k == '\n' || k == '\r') return 0;
        }
    }

    vga_puts_at("Nothing has been written yet. ENTER goes on to the "
                "confirmation.",6,row,VGA_LIGHT_GREY,BODY_BG);
    while(1){
        int k = keyboard_waitchar();
        if(k == 27) return 0;
        if(k == '\n' || k == '\r') return 1;
    }
}

/* ── Screen 3b: the additive confirmation ───────────────────────────── */
static int screen_additive_confirm(int drive)
{
    const inst_add_t *pl = &g_dplan[drive];
    char b1[12];

    cls(); hdr("Confirm", 3, 6);
    footer("Type YES and press ENTER to confirm  |  ESC to go back");

    vga_puts_at("HavenDOS will be installed BESIDE what is already on disk",
                6,4,BODY_FG,BODY_BG);
    utoa((uint32_t)drive,b1,10);
    vga_puts_at(b1,63,4,ACC,BODY_BG);
    vga_putchar_at('.',64,4,BODY_FG,BODY_BG);

    box(10,6,60,9);
    vga_puts_at("Nothing is deleted.",12,7,OK_COL,BODY_BG);
    vga_puts_at("No existing partition is moved, resized or reformatted.",
                12,8,OK_COL,BODY_BG);
    vga_puts_at("No file on the EFI partition is overwritten without a",
                12,9,OK_COL,BODY_BG);
    vga_puts_at("verified copy being taken first.",12,10,OK_COL,BODY_BG);
    for(int x=11;x<69;x++) vga_putchar_at('-',x,11,VGA_DARK_GREY,BODY_BG);
    vga_puts_at("What is written: one new partition in free space, four",
                12,12,BODY_FG,BODY_BG);
    vga_puts_at("sectors of the partition table, and new files on the",
                12,13,BODY_FG,BODY_BG);
    vga_puts_at("EFI partition. The previous screen listed them.",
                12,14,BODY_FG,BODY_BG);

    /* Honest, and placed where the old screen put its all-caps warning. A
       confirmation screen that promises safety and nothing else invites
       the one thing nobody should do here, which is not keep a backup. */
    vga_puts_at("This is still a write to a disk with your data on it.",
                6,17,VGA_YELLOW,BODY_BG);
    vga_puts_at("Back up anything you cannot lose before continuing.",
                6,18,VGA_YELLOW,BODY_BG);
    if(pl->esp.has_microsoft)
        vga_puts_at("Windows was found on this disk and is expected to keep "
                    "booting.",6,19,VGA_LIGHT_GREY,BODY_BG);

    vga_puts_at("Type YES to confirm: ",6,22,VGA_WHITE,BODY_BG);
    {
        char conf[8]=""; int ci=0;
        for(int x=27;x<34;x++) vga_putchar_at('_',x,22,VGA_DARK_GREY,BODY_BG);
        vga_set_cursor(27,22);
        while(1){
            int k=keyboard_waitchar();
            if(k==27) return 0;
            if(k=='\n'||k=='\r') break;
            if((k=='\b'||k==127)&&ci>0){
                ci--; conf[ci]=0;
                vga_putchar_at('_',27+ci,22,VGA_DARK_GREY,BODY_BG);
                vga_set_cursor(27+ci,22);
            } else if(ci<7){
                char uc=(k>='a'&&k<='z')?(char)(k-32):(char)k;
                if(uc>='A'&&uc<='Z'){
                    conf[ci++]=uc; conf[ci]=0;
                    vga_putchar_at(uc,26+ci,22,ACC,BODY_BG);
                    vga_set_cursor(27+ci,22);
                }
            }
        }
        return strcmp(conf,"YES")==0;
    }
}

/* ── ToS screen ─────────────────────────────────────────────────── */
/* ── Screen 3: Layout preview + confirm ─────────────────────────── */
static int screen_confirm(int drive, uint32_t mb){
    cls(); hdr("Partition Layout Preview",3,6);
    footer("Type YES and press ENTER to confirm  |  ESC to go back");

    char mbs[12];
    utoa(mb,mbs,10);

    vga_puts_at("The following will be written to Drive",6,3,BODY_FG,BODY_BG);
    char drv[4]; utoa((uint32_t)drive,drv,10);
    vga_puts_at(drv,45,3,ACC,BODY_BG);
    vga_putchar_at(':',46,3,BODY_FG,BODY_BG);

    { char bp[10]; bus_paren(drive,bp);
      vga_puts_at(bp,48,3,bus_col(drive),BODY_BG); }

    box(10,5,60,13);
    vga_puts_at("Sector 0          MBR + GRUB bootloader",12,6,BODY_FG,BODY_BG);
    vga_puts_at("Sectors 1-2047    GRUB core image",12,7,BODY_FG,BODY_BG);
    vga_puts_at("Sector 2048+      FAT16 partition (type 0x0E)",12,8,BODY_FG,BODY_BG);
    for(int x=11;x<69;x++) vga_putchar_at('-',x,9,VGA_DARK_GREY,BODY_BG);
    vga_puts_at("  /boot/grub/grub.cfg  GRUB config",12,10,VGA_LIGHT_GREY,BODY_BG);
    vga_puts_at("  /boot/havendos.elf   HavenDOS kernel",12,11,VGA_LIGHT_GREY,BODY_BG);
    vga_puts_at("  /havendos.txt        Version marker",12,12,VGA_DARK_GREY,BODY_BG);

    vga_puts_at("Total disk size: ",6,19,BODY_FG,BODY_BG);
    vga_puts_at(mbs,23,19,ACC,BODY_BG); vga_puts_at("MB",23+(int)strlen(mbs)+1,19,BODY_FG,BODY_BG);

    vga_puts_at("ALL DATA ON THIS DISK WILL BE PERMANENTLY ERASED.",15,21,WARN,BODY_BG);
    vga_puts_at("Type YES to confirm: ",6,22,VGA_WHITE,BODY_BG);

    char conf[8]=""; int ci=0;
    vga_set_cursor(27,22);
    for(int x=27;x<34;x++) vga_putchar_at('_',x,22,VGA_DARK_GREY,BODY_BG);
    vga_set_cursor(27,22);

    while(1){
        int k=keyboard_waitchar();
        if(k==27){ return 0; }
        if(k=='\n'||k=='\r') break;
        if((k=='\b'||k==127)&&ci>0){
            ci--; conf[ci]=0;
            /* the field starts at column 27, so the blank goes back where the
               character was, not one column to its left */
            vga_putchar_at('_',27+ci,22,VGA_DARK_GREY,BODY_BG);
            vga_set_cursor(27+ci,22);
        } else if(ci<7){
            char uc=(k>='a'&&k<='z')?(char)(k-32):(char)k;
            if(uc>='A'&&uc<='Z'){
                conf[ci++]=uc; conf[ci]=0;
                vga_putchar_at(uc,26+ci,22,ACC,BODY_BG);
                vga_set_cursor(27+ci,22);
            }
        }
    }
    return strcmp(conf,"YES")==0;
}

/* ── Screen 4: Progress ─────────────────────────────────────────── */
static void screen_progress(int drive){
    cls(); hdr("Installing...",4,6);
    footer("Do not power off the machine.");

    vga_puts_at("Installing HavenDOS " HAVENDOS_VER "...",25,3,BODY_FG,BODY_BG);
    char drv[4]; utoa((uint32_t)drive,drv,10);
    vga_puts_at("Target: Drive",6,4,VGA_DARK_GREY,BODY_BG);
    vga_puts_at(drv,20,4,ACC,BODY_BG);
    { char bp[10]; bus_paren(drive,bp);
      vga_puts_at(bp,22,4,bus_col(drive),BODY_BG); }

    g_prog_row=7;
    prog_cb(0,8,"Preparing...");
}

/* ── Screen 5: Done ─────────────────────────────────────────────── */
static void screen_done(void){
    cls(); hdr("Installation Complete",5,6);

    box(15,4,50,9);
    puts_center("HavenDOS " HAVENDOS_VER " installed successfully!",7,OK_COL,BODY_BG);
    puts_center("The system will reboot automatically.",9,BODY_FG,BODY_BG);
    puts_center("Remove the install ISO before rebooting.",11,VGA_YELLOW,BODY_BG);

    for(int x=0;x<80;x++) vga_putchar_at(' ',x,24,HDR_FG,HDR_BG);
    vga_puts_at("Rebooting in...",32,24,HDR_FG,HDR_BG);

    for(int t=5;t>=1;t--){
        char ts[4]; utoa((uint32_t)t,ts,10);
        vga_puts_at(ts,48,24,VGA_LIGHT_CYAN,HDR_BG);
        sleep_ms(1000);
    }
    __asm__ volatile(
        "1: inb $0x64, %%al\n"
        "testb $2, %%al\n"
        "jnz 1b\n"
        "movb $0xFE, %%al\n"
        "outb %%al, $0x64\n"
        ::: "eax"
    );
    for(;;) __asm__ volatile("cli; hlt");
}

/* ── Screen: no drives found ─────────────────────────────────────── */
static void screen_no_drives(void){
    cls(); hdr("No Disks Found",0,6);

    box(12,6,56,10);
    puts_center("No disks detected (NVMe, SATA, IDE or VirtIO).",9,WARN,BODY_BG);
    puts_center("HavenDOS requires a disk to install.",11,BODY_FG,BODY_BG);
    puts_center("In QEMU: attach a -drive or -cdrom disk.",13,BODY_FG,BODY_BG);
    puts_center("On real PC: ensure disk is connected and BIOS",13,BODY_FG,BODY_BG);
    puts_center("is set to AHCI or Legacy IDE mode.",14,BODY_FG,BODY_BG);

    footer("System halted. Attach a disk and reboot.");
    for(;;) __asm__ volatile("cli; hlt");
}

/* ── Screen: install error ───────────────────────────────────────── */
static void screen_error(int code){
    cls(); hdr("Install Failed",0,6);
    puts_center("Installation failed.",10,WARN,BODY_BG);
    char cs[8]; cs[0]='E'; utoa((uint32_t)(-code),cs+1,10);
    puts_center(cs,12,BODY_FG,BODY_BG);

    /* One line per code. This used to print "Check disk is writable and
       large enough (min 15MB)" for every failure there is, which on the
       most common one -- a disk too LARGE for FAT16 -- told the reader to
       go and check the opposite of the actual problem. */
    const char *why;
    switch(code){
        case -2:  why = "Disk is smaller than the 15MB minimum."; break;
        case -3:
        case -4:  why = "The disk refused a write. It may be read-only."; break;
        case -5:  why = "Formatting the partition failed."; break;
        case -8:  why = "This build carries no installable image."; break;
        case -13: why = "The disk reports itself as read-only."; break;
        case -14: why = "Disk has a GPT -- use the additive install.";  break;
        case -15: why = "No FAT16 geometry fits this partition size."; break;
        default:  why = "See the code above; dmesg has the detail.";    break;
    }
    puts_center(why,14,BODY_FG,BODY_BG);
    footer("Press any key to return to drive selection.");
    keyboard_waitchar();
}

/* ── Public entry point ──────────────────────────────────────────── */
void iso_install_wizard(void){
    int ndisks = disk_scan();
    /* Once, here, rather than inside the picker's redraw loop: the picker
       repaints on every keypress and this reads partition tables. */
    plan_disks();

    int has_virtio = 0, has_ata = 0;
    for(int i=0;i<ndisks;i++){
        if(g_disks[i].type==DTYPE_VIRTIO) has_virtio=1;
        if(g_disks[i].type==DTYPE_ATA)    has_ata=1;
    }

    if(ndisks==0){ screen_no_drives(); return; }

    while(1){
        screen_welcome(has_virtio, has_ata);
        /* Show disk count hint on welcome screen */
        if(ndisks==1){
            if(g_disks[0].type==DTYPE_ATA)
                vga_puts_at("1 ATA/SATA disk found - will be auto-selected.",6,22,VGA_LIGHT_GREEN,BODY_BG);
            else
                vga_puts_at("1 VirtIO disk found - will be auto-selected.",6,22,VGA_LIGHT_GREEN,BODY_BG);
        } else {
            char nbuf[4]; utoa((uint32_t)ndisks,nbuf,10);
            vga_puts_at(nbuf,6,22,VGA_LIGHT_CYAN,BODY_BG);
            vga_puts_at(" disks found - you will choose one.",8,22,BODY_FG,BODY_BG);
        }
        int c=keyboard_waitchar();
        if(c==27){
            __asm__ volatile(
                "1: inb $0x64, %%al\n"
                "testb $2, %%al\n"
                "jnz 1b\n"
                "movb $0xFE, %%al\n"
                "outb %%al, $0x64\n"
                ::: "eax"
            );
            for(;;) __asm__ volatile("cli; hlt");
        }

        /* Always show the drive picker — never auto-select.
           Auto-select caused USB sticks to be targeted instead of SATA.
           The user must always identify their disk from the list.     */
        int drive=screen_drive_picker(ndisks);
        if(drive<0) continue;

        /* Two installers, and which one runs is decided by what is on the
           disk -- never by a menu item the user might pick wrongly. A disk
           with a partition table gets the additive path; only a disk with
           no table at all reaches the one that wipes. */
        if(g_dmode[drive]==DMODE_PREVIEW){
            screen_additive_preview(drive, 0);
            continue;
        }

        if(g_dmode[drive]==DMODE_ADD){
            inst_add_t rep;
            int ret;

            if(!screen_additive_preview(drive, 1)) continue;
            if(!screen_additive_confirm(drive))    continue;

            screen_progress(drive);
            ret = havendos_install_additive(drive, 0, &rep, prog_cb);
            if(ret != INSTADD_OK){
                /* The additive codes are their own numbering and their own
                   messages; screen_error() speaks the whole-disk
                   installer's. Sharing one screen between them would mean
                   one of the two showing the wrong text for its code. */
                cls(); hdr("Installation Failed",5,6);
                footer("Press any key to return to the disk list");
                vga_puts_at("Nothing further was written.",6,4,BODY_FG,BODY_BG);
                vga_puts_at(havendos_install_add_strerror(ret),6,6,WARN,BODY_BG);
                if(ret==INSTADD_E_ESP)
                    vga_puts_at(esp_strerror(rep.esp_rc),6,8,WARN,BODY_BG);
                vga_puts_at("The partition table and every existing "
                            "partition are unchanged.",
                            6,10,VGA_LIGHT_GREY,BODY_BG);
                keyboard_waitchar();
                /* The disk has changed, so the cached plans have not. */
                plan_disks();
                continue;
            }
            plan_disks();
            screen_done();
            continue;
        }

        /* DMODE_WIPE: no partition table at all. */
        uint32_t mb=(uint32_t)(disk_sectors(drive)/2048);

        if(!screen_confirm(drive,mb)) continue;

        screen_progress(drive);
        int ret=havendos_install_to_drive(drive, prog_cb);

        if(ret!=0){
            screen_error(ret);
            continue;
        }

        screen_done();
    }
}
