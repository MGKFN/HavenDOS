#!/usr/bin/env python3
"""check_boot_log.py — fail the build if invented boot output comes back.

HavenDOS shipped three boot screens for a long time and two of them were
fiction.  The "verbose boot log" was a table of 24 string literals of which
four were real; it told every machine that ATA was absent, that FAT16 was on
a VirtIO partition, that the heap was 4 MB at 0x00200000 (a 256 KB static
array) and that the GDT had 256 descriptors (it has 3).  `dmesg` printed its
own copy with timestamps typed one millisecond apart that nothing measured.

That is all gone: the boot log is written by kernel/klog.c from values the
drivers have just read.  This script exists so it cannot come back quietly,
the same way make_version.py --check stops version literals drifting.

Two things are refused, both precise enough to have no false positives:

  1. A string literal shaped like a log timestamp -- "[   0.008] ..." -- in
     any kernel source.  Nothing should ever TYPE a timestamp; klog renders
     them from boot_ms().

  2. A table of log lines keyed by a status tag -- {"OK", ... or {"WARN", ...
     -- which is the exact shape of the array that was removed.

A line that genuinely needs either spells  boot-log-ok  in a comment on it.
"""
import os
import re
import sys

SCAN_DIRS = ("kernel", "drivers", "shell", "fs", "net")
OPT_OUT = "boot-log-ok"

# "[   0.008]" or "[0.008]" inside a string literal.
FAKE_STAMP = re.compile(r'"[^"\n]*\[\s*\d+\.\d+\s*\][^"\n]*"')
# The removed table's shape: a brace followed by a status tag string.
LOG_TABLE = re.compile(r'\{\s*"(OK|WARN|ERR|FAIL)"\s*,')


def scan(root="."):
    bad = []
    for d in SCAN_DIRS:
        path = os.path.join(root, d)
        if not os.path.isdir(path):
            continue
        for name in sorted(os.listdir(path)):
            if not name.endswith((".c", ".h")):
                continue
            f = os.path.join(path, name)
            for n, line in enumerate(open(f, encoding="utf-8", errors="replace"), 1):
                if OPT_OUT in line:
                    continue
                if FAKE_STAMP.search(line):
                    bad.append((f, n, "a typed log timestamp", line.strip()))
                if LOG_TABLE.search(line):
                    bad.append((f, n, "a table of log lines", line.strip()))
    return bad


def main():
    bad = scan()
    if not bad:
        print("check_boot_log: clean, no invented boot output")
        return 0
    print("check_boot_log: FAILED\n")
    for f, n, why, text in bad:
        print("  %s:%d  %s" % (f, n, why))
        print("      %s" % text[:100])
    print("""
The boot log is written by kernel/klog.c from values the drivers have just
read.  Call klog() with the real number instead of describing it, or mark the
line  boot-log-ok  if it genuinely is not boot output.""")
    return 1


if __name__ == "__main__":
    sys.exit(main())
