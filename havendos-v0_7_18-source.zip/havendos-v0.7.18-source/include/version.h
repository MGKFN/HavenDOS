#pragma once
/* ============================================================
   HavenDOS version — SINGLE SOURCE OF TRUTH
   ============================================================

   Before v0.7.18 the version was typed out by hand in ~50 places and they
   had drifted apart: a v0.7.17 build shipped screens reading v0.7.0, v0.7.4
   and v0.7.11, the ISO's GRUB menu said v0.7.11, isodir/version.txt said
   v0.7.11, and the installer wrote a grub.cfg whose menu entries said
   v0.7.4.

   That was not only cosmetic.  fs/update.c carried

       #define HAVENDOS_VERSION "0.5.9.14"

   and fed it to ver_cmp() against the version read off the update ISO.  So
   "same version already installed" could never fire, and an OLDER ISO
   compared as NEWER and was applied as an upgrade with no warning.

   Everything now derives from the three numbers below.  tools/make_version.py
   regenerates isodir/version.txt and the ISO grub.cfg from this file at build
   time, so a release is a one-line change here.

   HAVENDOS_VER_NUM  "0.7.18"   — bare, for comparison (update.c, manifests)
   HAVENDOS_VER      "v0.7.18"  — display form, what the user sees
   HAVENDOS_FULL     "HavenDOS v0.7.18"
*/

#define HAVENDOS_VER_MAJOR  0
#define HAVENDOS_VER_MINOR  7
#define HAVENDOS_VER_PATCH  18

#define HAVENDOS_VER_NUM    "0.7.18"
#define HAVENDOS_VER        "v" HAVENDOS_VER_NUM
#define HAVENDOS_NAME       "HavenDOS"
#define HAVENDOS_FULL       HAVENDOS_NAME " " HAVENDOS_VER
#define HAVENDOS_VENDOR     "TechHaven Studios"
